/** Very simple page-flow tracking used by the Writer status bar. */
export function estimatePageCount(pageEl, pageHeightPx = 1056) {
  return Math.max(1, Math.round(pageEl.scrollHeight / pageHeightPx));
}