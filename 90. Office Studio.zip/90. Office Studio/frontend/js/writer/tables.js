/** Table helpers for Writer (merge/split/add-row). */
export const WriterTables = {
  addRowAfter(table, tr) {
    const newRow = table.insertRow(tr.rowIndex + 1);
    for (let i = 0; i < tr.cells.length; i++) {
      const td = newRow.insertCell(i);
      td.innerHTML = '<br>';
    }
  },
  addColumnAfter(table, cell) {
    const idx = cell.cellIndex;
    for (const row of table.rows) {
      const newCell = row.insertCell(idx + 1);
      newCell.innerHTML = '<br>';
    }
  },
  removeRow(table, tr) { table.deleteRow(tr.rowIndex); },
};