/** Standalone find/replace helpers (used by WriterApp inline). */
export function findAll(root, query) {
  const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
  const hits = [];
  let node;
  while (node = walker.nextNode()) {
    let i = 0;
    while ((i = node.nodeValue.indexOf(query, i)) !== -1) {
      hits.push({ node, offset: i });
      i += query.length;
    }
  }
  return hits;
}