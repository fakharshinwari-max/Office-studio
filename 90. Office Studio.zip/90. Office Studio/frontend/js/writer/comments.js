/** Threaded comments for Writer. */
export class WriterComments {
  constructor(app) {
    this.app = app;
    this.comments = [];
    this.nextId = 1;
  }

  add(text) {
    const sel = window.getSelection();
    if (!sel.rangeCount) return;
    const range = sel.getRangeAt(0);
    const paraId = 'p' + this.nextId.toString().padStart(6, '0');
    const marker = document.createElement('span');
    marker.className = 'comment-marker';
    marker.dataset.commentId = String(this.nextId);
    marker.textContent = '💬';
    range.collapse(false);
    range.insertNode(marker);
    this.comments.push({
      id: this.nextId++, author: 'You', text,
      date: new Date().toISOString(),
      paraId, resolved: false, replies: [],
    });
    this._render();
    this.app._snapshot('add comment');
  }

  addReply(parentId, text) {
    const c = this.comments.find(x => x.id === parentId);
    if (!c) return;
    c.replies.push({ author: 'You', text, date: new Date().toISOString() });
    this._render();
    this.app._snapshot('reply comment');
  }

  resolve(id) {
    const c = this.comments.find(x => x.id === id);
    if (!c) return;
    c.resolved = !c.resolved;
    this._render();
    this.app._snapshot('resolve comment');
  }

  delete(id) {
    this.comments = this.comments.filter(c => c.id !== id);
    this.app.page.querySelectorAll(`[data-comment-id="${id}"]`).forEach(el => el.remove());
    this._render();
    this.app._snapshot('delete comment');
  }

  _render() {
    let panel = document.getElementById('commentsPane');
    if (!panel) {
      panel = document.createElement('aside');
      panel.id = 'commentsPane';
      panel.className = 'comments-pane';
      document.body.appendChild(panel);
    }
    panel.innerHTML = this.comments.map(c => `
      <div class="comment${c.resolved ? ' resolved' : ''}">
        <div class="comment-head"><strong>${escapeHtml(c.author)}</strong><span class="date">${new Date(c.date).toLocaleString()}</span></div>
        <div class="comment-body">${escapeHtml(c.text)}</div>
        ${c.replies.map(r => `<div class="comment-reply"><strong>${escapeHtml(r.author)}</strong>: ${escapeHtml(r.text)}</div>`).join('')}
        <div class="comment-actions">
          <button data-act="reply" data-id="${c.id}">Reply</button>
          <button data-act="resolve" data-id="${c.id}">${c.resolved ? 'Reopen' : 'Resolve'}</button>
          <button data-act="delete" data-id="${c.id}">Delete</button>
        </div>
      </div>`).join('') || '<div class="empty">No comments</div>';
    panel.querySelectorAll('button').forEach(b => {
      b.onclick = () => {
        const id = Number(b.dataset.id);
        if (b.dataset.act === 'reply') { const t = prompt('Reply:'); if (t) this.addReply(id, t); }
        else if (b.dataset.act === 'resolve') this.resolve(id);
        else if (b.dataset.act === 'delete') this.delete(id);
      };
    });
  }
}

function escapeHtml(s) {
  return String(s ?? '').replace(/[&<>"']/g, c => ({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' }[c]));
}