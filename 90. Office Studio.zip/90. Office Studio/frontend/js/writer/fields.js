/** Word-style fields (PAGE, NUMPAGES, DATE, TOC, SEQ, REF, etc.). */
export const WriterFields = {
  insert(app, name, args = '') {
    const span = document.createElement('span');
    span.dataset.field = name.toUpperCase();
    span.dataset.fieldArgs = args;
    span.className = 'field';
    span.textContent = '1';
    const sel = window.getSelection();
    if (sel.rangeCount) {
      const r = sel.getRangeAt(0);
      r.deleteContents();
      r.insertNode(span);
    } else app.page.appendChild(span);
    this.update(app);
  },

  update(app) {
    const fields = app.page.querySelectorAll('[data-field]');
    const now = new Date();
    const totalWords = (app.page.innerText || '').split(/\s+/).filter(Boolean).length;
    const totalPages = Math.max(1, Math.round(app.page.scrollHeight / 1056));
    for (const f of fields) {
      const name = f.dataset.field;
      switch (name) {
        case 'DATE':       f.textContent = now.toLocaleDateString(); break;
        case 'TIME':       f.textContent = now.toLocaleTimeString(); break;
        case 'CREATEDATE': f.textContent = app.createdAt ? new Date(app.createdAt).toLocaleDateString() : now.toLocaleDateString(); break;
        case 'SAVEDATE':   f.textContent = new Date().toLocaleDateString(); break;
        case 'PRINTDATE':  f.textContent = now.toLocaleDateString(); break;
        case 'NUMPAGES':   f.textContent = String(totalPages); break;
        case 'PAGE':       f.textContent = '1'; break;
        case 'NUMWORDS':   f.textContent = String(totalWords); break;
        case 'NUMCHARS':   f.textContent = String(app.page.innerText.length); break;
        case 'TITLE':      f.textContent = app.titleEl.value || ''; break;
        case 'AUTHOR':     f.textContent = 'You'; break;
        case 'FILENAME':   f.textContent = app.titleEl.value || ''; break;
        case 'SEQ': {
          const all = [...app.page.querySelectorAll('[data-field="SEQ"]')];
          f.textContent = String(all.indexOf(f) + 1);
          break;
        }
        case 'REF':      f.textContent = f.dataset.fieldArgs || '?'; break;
        case 'PAGEREF':  f.textContent = '1'; break;
      }
    }
  },

  insertTOC(app, levels = '1-3') {
    const toc = document.createElement('div');
    toc.dataset.toc = levels;
    toc.className = 'toc';
    const sel = window.getSelection();
    if (sel.rangeCount) {
      const r = sel.getRangeAt(0);
      r.deleteContents();
      r.insertNode(toc);
    } else app.page.appendChild(toc);
    this.updateTOC(app, toc, levels);
  },

  updateTOC(app, toc, levels = '1-3') {
    const [l1, l2] = (levels || '1-3').split('-').map(Number);
    const headings = [...app.page.querySelectorAll('h1,h2,h3,h4,h5,h6')].filter(h => {
      const lvl = Number(h.tagName.slice(1));
      return lvl >= l1 && lvl <= l2;
    });
    toc.innerHTML = headings.map(h => {
      const lvl = Number(h.tagName.slice(1)) - l1 + 1;
      return `<div class="toc-entry" style="padding-left:${(lvl - 1) * 18}px;margin:2px 0;">${escapeHtml(h.textContent)}</div>`;
    }).join('') || '<em>No headings found</em>';
  },
};

function escapeHtml(s) {
  return String(s ?? '').replace(/[&<>"']/g, c => ({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' }[c]));
}