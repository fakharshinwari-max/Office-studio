/** Track Changes engine for Writer. */
export class TrackChanges {
  constructor(app) {
    this.app = app;
    this.on = false;
    this.revisions = [];
    this.nextId = 1;
  }

  enable(on = true) { this.on = on; }

  recordInsert(range, text, author = 'You') {
    if (!this.on) return null;
    const rev = { id: this.nextId++, type: 'insert', text, author, date: new Date().toISOString() };
    this.revisions.push(rev);
    return rev;
  }

  recordDelete(range, text, author = 'You') {
    if (!this.on) return null;
    const rev = { id: this.nextId++, type: 'delete', text, author, date: new Date().toISOString() };
    this.revisions.push(rev);
    return rev;
  }

  markInsertion(text, author = 'You') {
    const span = document.createElement('span');
    span.className = 'rev-insert';
    span.dataset.revAuthor = author;
    span.dataset.revType = 'insert';
    span.textContent = text;
    this._insertAtCursor(span);
    const rev = this.recordInsert(null, text, author);
    if (rev) span.dataset.revId = String(rev.id);
    return span;
  }

  markDeletion(text, author = 'You') {
    const span = document.createElement('span');
    span.className = 'rev-delete';
    span.dataset.revAuthor = author;
    span.dataset.revType = 'delete';
    span.textContent = text;
    this._insertAtCursor(span);
    const rev = this.recordDelete(null, text, author);
    if (rev) span.dataset.revId = String(rev.id);
    return span;
  }

  _insertAtCursor(node) {
    const sel = window.getSelection();
    if (!sel.rangeCount) { this.app.page.appendChild(node); return; }
    const r = sel.getRangeAt(0);
    r.deleteContents();
    r.insertNode(node);
    r.setStartAfter(node);
    r.collapse(true);
    sel.removeAllRanges();
    sel.addRange(r);
  }

  acceptAll() {
    this.app.page.querySelectorAll('.rev-insert').forEach(el => {
      el.replaceWith(document.createTextNode(el.textContent));
    });
    this.app.page.querySelectorAll('.rev-delete').forEach(el => el.remove());
    this.revisions = [];
    this.app._snapshot('accept all changes');
  }

  rejectAll() {
    this.app.page.querySelectorAll('.rev-insert').forEach(el => el.remove());
    this.app.page.querySelectorAll('.rev-delete').forEach(el => {
      el.replaceWith(document.createTextNode(el.textContent));
    });
    this.revisions = [];
    this.app._snapshot('reject all changes');
  }

  setDisplayMode(mode) {
    this.app.page.classList.remove('rev-mode-all','rev-mode-simple','rev-mode-none','rev-mode-original');
    this.app.page.classList.add('rev-mode-' + mode);
    let style = document.getElementById('revModeStyle');
    if (!style) { style = document.createElement('style'); style.id = 'revModeStyle'; document.head.appendChild(style); }
    style.textContent = `
      .rev-mode-simple .rev-delete { display: none; }
      .rev-mode-simple .rev-insert { background: transparent; color: inherit; text-decoration: none; }
      .rev-mode-none .rev-delete { display: none; }
      .rev-mode-none .rev-insert { background: transparent; color: inherit; text-decoration: none; }
      .rev-mode-original .rev-insert { display: none; }
      .rev-mode-original .rev-delete { text-decoration: none; color: inherit; }
    `;
  }
}