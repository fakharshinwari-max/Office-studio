/**
 * Writer app: contenteditable editor with full Phase 1-4 features.
 * Adds: Track Changes, threaded comments, footnotes, TOC, fields, captions,
 * equations, watermark, mail merge.
 */
import { api } from '../core/api.js';
import { History } from '../core/history.js';
import { AutoSaver, storage } from '../core/storage.js';
import { Ribbon } from '../core/ribbon.js';
import { wordRibbon } from '../core/ribbon-config-word.js';
import { Shortcuts } from '../core/shortcuts.js';
import { Backstage } from '../core/backstage.js';
import { TellMe } from '../core/tellme.js';
import { showContextMenu, hideContextMenu } from '../core/context-menu.js';
import { KeyTips } from '../core/keytips.js';
import { openDialog, prompt2 } from '../core/dialogs.js';
import { TrackChanges } from './track-changes.js';
import { WriterComments } from './comments.js';
import { WriterFields } from './fields.js';
import { Collab } from '../core/collab.js';
import { Presence } from '../core/presence.js';

export class WriterApp {
  constructor({ ribbonHost, pageEl, titleEl }) {
    this.ribbonHost = ribbonHost;
    this.page = pageEl;
    this.titleEl = titleEl;
    this.history = new History();
    this.docId = new URLSearchParams(location.search).get('id');
    this.footnotes = [];
    this.watermark = null;
    this.createdAt = new Date().toISOString();

    this.status = {
      font: '', fontSize: '11',
      bold: false, italic: false, underline: false, strike: false,
      sub: false, sup: false,
      color: '#1f1f1f', highlight: '#ffff00',
    };

    this.trackChanges = new TrackChanges(this);
    this.comments = new WriterComments(this);
  }

  async init() {
    this._setupRibbon();
    this._setupStatusBar();
    this._setupShortcuts();
    this._setupContextMenu();
    this._setupAutosave();
    this._setupBackstage();
    this._setupTellMe();
    this._setupTrackChangesUI();
    this._setupCommentsUI();
    new KeyTips();
    this._bindSelectionEvents();

    if (this.docId) await this._loadDoc();
    else this.page.innerHTML = '<p><br></p>';

    this._lastHTML = this.page.innerHTML;
    this._updateStatus();
  }

  // ============ Ribbon ============
    _setupRibbon() {
    const self = this;
    const ctx = {
      get bold()      { try { return document.queryCommandState('bold'); } catch { return false; } },
      get italic()    { try { return document.queryCommandState('italic'); } catch { return false; } },
      get underline() { try { return document.queryCommandState('underline'); } catch { return false; } },
      get strike()    { try { return document.queryCommandState('strikeThrough'); } catch { return false; } },
      get hasTable()  { try { return !!self._selectionAncestor('table'); } catch { return false; } },
      font: this.status.font,
      fontSize: this.status.fontSize,
      color: this.status.color,
      highlight: this.status.highlight,
      cmd: (name, val) => self.command(name, val),
    };
    this.ribbon = new Ribbon({ host: this.ribbonHost, config: wordRibbon, context: ctx });
  }

  // ============ Command dispatcher ============
  command(name, val) {
    this.page.focus();
    switch (name) {
      case 'bold': this._exec('bold', null, val); return;
      case 'italic': this._exec('italic', null, val); return;
      case 'underline': this._exec('underline', null, val); return;
      case 'strike': this._exec('strikeThrough', null, val); return;
      case 'sub': this._exec('subscript', null, val); return;
      case 'sup': this._exec('superscript', null, val); return;
      case 'color': this._exec('foreColor', val); return;
      case 'highlight': this._exec('hiliteColor', val); return;
      case 'font': this._exec('fontName', val); return;
      case 'fontSize': this._execFontSize(val); return;
      case 'growFont': this._bumpFontSize(+1); return;
      case 'shrinkFont': this._bumpFontSize(-1); return;
      case 'align': this._exec({left:'justifyLeft',center:'justifyCenter',right:'justifyRight',justify:'justifyFull'}[val]); return;
      case 'bullets': this._exec('insertUnorderedList'); return;
      case 'numbering': this._exec('insertOrderedList'); return;
      case 'indent': this._exec('indent'); return;
      case 'outdent': this._exec('outdent'); return;
      case 'clearFormatting': this._exec('removeFormat'); return;
      case 'lineSpacing': this._setLineSpacing(val); return;
      case 'style': this._applyBlockTag(val); return;
      case 'insertTable': this._insertTable(val); return;
      case 'insertImage': this._insertImage(); return;
      case 'insertLink': this._insertLink(); return;
      case 'insertPageBreak': this._insertPageBreak(); return;
      case 'insertBlankPage': this._insertBlankPage(); return;
      case 'insertCover': this._insertCoverPage(); return;
      case 'insertPageNumber': this._insertPageNumber(); return;
      case 'insertDateTime': this._insertDateTime(); return;
      case 'insertSymbol': this._insertSymbol(); return;
      case 'setMargins': this.page.style.padding = `${val}px ${val}px`; return;
      case 'setOrientation': this.page.style.maxWidth = val === 'landscape' ? '1100px' : '816px'; return;
      case 'setPageSize': this.page.style.width = val === 'A4' ? '794px' : '816px'; return;
      case 'focusMode': document.body.classList.toggle('focus-mode'); return;
      case 'toggleRuler': document.querySelector('.ruler')?.classList.toggle('hidden'); return;
      case 'setZoom': this._setZoom(val); return;
      case 'zoomDialog': this._zoomDialog(); return;
      case 'find': this._showFind(); return;
      case 'replace': this._showReplace(); return;
      case 'selectAll': document.execCommand('selectAll'); return;
      case 'copy': document.execCommand('copy'); return;
      case 'cut': document.execCommand('cut'); return;
      case 'paste': this._paste(); return;
      case 'pasteText': this._pastePlain(); return;
      case 'formatPainter': this._formatPainter(); return;

      // Phase 4
      case 'trackChanges':
        this.trackChanges.enable(val);
        document.body.classList.toggle('tracking-on', !!val);
        break;
      case 'displayReview': this.trackChanges.setDisplayMode(val); break;
      case 'acceptAll': this.trackChanges.acceptAll(); break;
      case 'rejectAll': this.trackChanges.rejectAll(); break;
      case 'newComment': {
        const text = prompt('Comment:');
        if (text) this.comments.add(text);
        break;
      }
      case 'insertFootnote': {
        const text = prompt('Footnote text:');
        if (!text) break;
        const id = this.footnotes.length + 1;
        this.footnotes.push({ id, text });
        const span = document.createElement('sup');
        span.textContent = String(id);
        span.style.cssText = 'color:#2b579a;cursor:pointer;';
        span.dataset.footnote = String(id);
        this._insertNode(span);
        this._snapshot('insert footnote');
        break;
      }
      case 'insertTOC': WriterFields.insertTOC(this, '1-3'); break;
      case 'updateTOC':
        this.page.querySelectorAll('[data-toc]').forEach(t => WriterFields.updateTOC(this, t, t.dataset.toc));
        break;
      case 'insertFieldDialog': this._insertFieldDialog(); break;
      case 'insertCaption': {
        const text = prompt('Caption text:');
        if (!text) break;
        const p = document.createElement('p');
        p.style.cssText = 'text-align:center;color:#666;font-size:.9em;margin-top:4px;';
        p.textContent = `Figure ${this.page.querySelectorAll('img').length}: ${text}`;
        this.page.appendChild(p);
        this._snapshot('insert caption');
        break;
      }
      case 'insertEquation': {
        const latex = prompt('LaTeX (simple expressions like a/b):', 'a/b');
        if (!latex) break;
        const span = document.createElement('span');
        span.className = 'equation';
        span.dataset.latex = latex;
        span.style.cssText = 'font-family:serif;font-style:italic;padding:0 4px;';
        span.textContent = latex;
        this._insertNode(span);
        this._snapshot('insert equation');
        break;
      }
      case 'mailMergeStart': this._mailMergeWizard(); break;
      case 'watermarkDialog': this._watermarkDialog(); break;
      case 'updateFields': WriterFields.update(this); break;

      case 'undo': this.history.undo(); this._updateStatus(); return;
      case 'redo': this.history.redo(); this._updateStatus(); return;

      default:
        console.warn('Unhandled writer command:', name);
    }
    this._afterCommand();
  }

  _exec(cmd, arg, force) {
    if (['bold','italic','underline','strikeThrough','subscript','superscript'].includes(cmd)) {
      document.execCommand(cmd, false, force ?? null);
    } else {
      document.execCommand(cmd, false, arg ?? null);
    }
  }

  _execFontSize(pt) {
    const sizeMap = {'8':1,'9':2,'10':2,'11':3,'12':3,'14':4,'16':4,'18':5,'20':5,'22':6,'24':6,'26':6,'28':6,'36':7,'48':7,'72':7};
    document.execCommand('fontSize', false, sizeMap[String(pt)] || '3');
    this.page.querySelectorAll('font[size]').forEach(f => {
      const span = document.createElement('span');
      span.style.fontSize = (pt || 11) + 'pt';
      span.innerHTML = f.innerHTML;
      f.replaceWith(span);
    });
  }

  _bumpFontSize(d) {
    const cur = parseInt(this.status.fontSize || '11', 10) || 11;
    this._execFontSize(Math.max(8, Math.min(72, cur + d)));
  }

  _setLineSpacing(v) {
    const blocks = this._selectedBlocks();
    blocks.forEach(b => { b.style.lineHeight = v; });
    this._snapshot('line spacing');
  }

  _applyBlockTag(tag) {
    const sel = window.getSelection();
    if (!sel.rangeCount) return;
    const block = this._selectionAncestor(['p','h1','h2','h3','h4','h5','h6','blockquote','pre','li','div']) || this.page;
    const newEl = document.createElement(tag === 'p' ? 'p' :
      tag === 'h1' ? 'h1' : tag === 'h2' ? 'h2' : tag === 'h3' ? 'h3' :
      tag === 'blockquote' ? 'blockquote' : tag === 'code' ? 'code' : 'p');
    newEl.innerHTML = block.innerHTML || '<br>';
    block.replaceWith(newEl);
    const range = document.createRange();
    range.selectNodeContents(newEl);
    sel.removeAllRanges(); sel.addRange(range);
    this._snapshot('apply ' + tag);
  }

  _insertTable([rows, cols]) {
    const table = document.createElement('table');
    for (let i = 0; i < rows; i++) {
      const tr = document.createElement('tr');
      for (let j = 0; j < cols; j++) {
        const td = document.createElement('td');
        td.innerHTML = '<br>';
        tr.appendChild(td);
      }
      table.appendChild(tr);
    }
    this._insertNode(table);
    this._snapshot('insert table');
  }

  _insertImage() {
    const input = document.createElement('input');
    input.type = 'file'; input.accept = 'image/*';
    input.onchange = () => {
      const f = input.files[0]; if (!f) return;
      const reader = new FileReader();
      reader.onload = () => {
        const img = document.createElement('img');
        img.src = reader.result;
        img.style.maxWidth = '100%';
        this._insertNode(img);
        this._snapshot('insert image');
      };
      reader.readAsDataURL(f);
    };
    input.click();
  }

  async _insertLink() {
    const r = await prompt2({
      title: 'Insert Link', host: document.getElementById('dialogHost') || document.body,
      fields: [{ name: 'url', label: 'URL', value: 'https://' },
               { name: 'text', label: 'Display text', value: 'link' }],
    });
    if (!r || !r.url) return;
    const a = document.createElement('a');
    a.href = r.url; a.textContent = r.text || r.url; a.target = '_blank';
    this._insertNode(a);
    this._snapshot('insert link');
  }

  _insertPageBreak() {
    const div = document.createElement('div');
    div.style.pageBreakAfter = 'always';
    div.style.height = '0';
    this._insertNode(div);
    this._snapshot('page break');
  }

  _insertBlankPage() {
    const p = document.createElement('p');
    p.style.pageBreakAfter = 'always';
    p.innerHTML = '<br>';
    this.page.appendChild(p);
    const p2 = document.createElement('p'); p2.innerHTML = '<br>';
    this.page.appendChild(p2);
    this._snapshot('blank page');
  }

  _insertCoverPage() {
    const wrap = document.createElement('div');
    wrap.style.cssText = 'text-align:center; padding:80px 0; border-bottom:1px solid #ddd; margin-bottom:40px;';
    wrap.innerHTML = `<h1 style="font-size:28pt; margin-bottom:12px;">Document Title</h1>
      <p style="color:#666;">Author Name • ${new Date().toLocaleDateString()}</p>`;
    this.page.insertBefore(wrap, this.page.firstChild);
    this._snapshot('cover page');
  }

  _insertPageNumber() {
    const p = document.createElement('p');
    p.style.cssText = 'text-align:center; color:#999; font-size:10pt;';
    p.textContent = '— 1 —';
    this.page.appendChild(p);
    this._snapshot('page number');
  }

  _insertDateTime() {
    const p = document.createElement('p');
    p.textContent = new Date().toLocaleString();
    this._insertNode(p);
    this._snapshot('date time');
  }

  _insertSymbol() {
    const r = prompt('Symbol to insert:', '©');
    if (!r) return;
    const span = document.createElement('span');
    span.textContent = r;
    this._insertNode(span);
    this._snapshot('symbol');
  }

  _insertNode(node) {
    const sel = window.getSelection();
    if (!sel.rangeCount) { this.page.appendChild(node); return; }
    const range = sel.getRangeAt(0);
    range.deleteContents();
    range.insertNode(node);
    range.setStartAfter(node);
    range.collapse(true);
    sel.removeAllRanges(); sel.addRange(range);
  }

  async _paste() {
    try {
      const items = await navigator.clipboard.read();
      for (const item of items) {
        if (item.types.includes('text/html')) {
          const blob = await item.getType('text/html');
          const html = await blob.text();
          const clean = window.DOMPurify ? DOMPurify.sanitize(html) : html;
          document.execCommand('insertHTML', false, clean);
          this._snapshot('paste'); return;
        }
        if (item.types.includes('text/plain')) {
          const blob = await item.getType('text/plain');
          const text = await blob.text();
          document.execCommand('insertText', false, text);
          this._snapshot('paste'); return;
        }
      }
    } catch (e) {
      document.execCommand('paste');
    }
  }
  async _pastePlain() {
    try {
      const text = await navigator.clipboard.readText();
      document.execCommand('insertText', false, text);
      this._snapshot('paste text');
    } catch { document.execCommand('paste'); }
  }
  _formatPainter() {
    const sel = window.getSelection();
    if (!sel.rangeCount || sel.isCollapsed) return;
    const range = sel.getRangeAt(0);
    const container = range.commonAncestorContainer.nodeType === 1 ? range.commonAncestorContainer : range.commonAncestorContainer.parentElement;
    const style = container.style.cssText;
    const onClick = () => {
      const s2 = window.getSelection();
      if (!s2.rangeCount) return;
      const r2 = s2.getRangeAt(0);
      const c2 = r2.commonAncestorContainer.nodeType === 1 ? r2.commonAncestorContainer : r2.commonAncestorContainer.parentElement;
      c2.style.cssText = (c2.style.cssText || '') + ';' + style;
      document.removeEventListener('mouseup', onClick);
    };
    document.addEventListener('mouseup', onClick);
  }

  _selectionAncestor(tagName) {
    const sel = window.getSelection();
    if (!sel.rangeCount) return null;
    let node = sel.getRangeAt(0).commonAncestorContainer;
    if (node.nodeType === 3) node = node.parentElement;
    const tags = Array.isArray(tagName) ? tagName : [tagName];
    while (node && node !== this.page) {
      if (tags.includes(node.tagName.toLowerCase())) return node;
      node = node.parentElement;
    }
    return null;
  }

  _selectedBlocks() {
    const sel = window.getSelection();
    if (!sel.rangeCount) return [];
    const range = sel.getRangeAt(0);
    const blocks = new Set();
    const walker = document.createTreeWalker(this.page, NodeFilter.SHOW_ELEMENT, {
      acceptNode: (n) => ['P','H1','H2','H3','H4','H5','H6','LI','BLOCKQUOTE','PRE','DIV'].includes(n.tagName) ?
        NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_SKIP
    });
    let n;
    while (n = walker.nextNode()) if (range.intersectsNode(n)) blocks.add(n);
    return [...blocks];
  }

  // ============ Track changes UI ============
  _setupTrackChangesUI() {
    this.page.addEventListener('beforeinput', (e) => {
      if (!this.trackChanges.on) return;
      if (e.inputType === 'insertText' && e.data) {
        e.preventDefault();
        this.trackChanges.markInsertion(e.data, 'You');
        this._snapshot('tracked insert');
      }
    });
  }

  _setupCommentsUI() { /* comments pane is created lazily on first add */ }

  // ============ History snapshots ============
  _snapshot(label = 'edit') {
    const before = this._lastHTML ?? this.page.innerHTML;
    const after = this.page.innerHTML;
    if (before === after) { this._lastHTML = after; return; }
    const target = this.page;
    const cmd = {
      label,
      do: () => { target.innerHTML = after; this._updateStatus(); },
      undo: () => { target.innerHTML = before; this._updateStatus(); },
    };
    this.history.push(cmd);
    this._lastHTML = after;
    this.autosaver?.schedule();
    this._updateStatus();
  }

  _afterCommand() {
    this._snapshot('command');
    this._refreshStatus();
  }

  _refreshStatus() {
    this.status.bold = document.queryCommandState('bold');
    this.status.italic = document.queryCommandState('italic');
    this.status.underline = document.queryCommandState('underline');
    this.status.strike = document.queryCommandState('strikeThrough');
    this.ribbon.setContext({
      ...this.ribbon.ctx,
      bold: this.status.bold, italic: this.status.italic,
      underline: this.status.underline, strike: this.status.strike,
      hasTable: !!this._selectionAncestor('table'),
    });
  }

  // ============ Status bar ============
  _setupStatusBar() {
    this.wordCountEl = document.getElementById('wordCount');
    this.charCountEl = document.getElementById('charCount');
    this.pageInfoEl = document.getElementById('pageInfo');
    this.zoomRange = document.getElementById('zoomRange');
    this.zoomLabel = document.getElementById('zoomLabel');

    this.zoomRange?.addEventListener('input', (e) => this._setZoom(e.target.value));
    document.getElementById('zoomIn')?.addEventListener('click', () => this._setZoom(+this.zoomRange.value + 10));
    document.getElementById('zoomOut')?.addEventListener('click', () => this._setZoom(+this.zoomRange.value - 10));

    this.page.addEventListener('input', () => {
      this._updateStatus();
      if (!this._typing) {
        this._typing = setTimeout(() => {
          this._snapshot('typing');
          this._typing = null;
        }, 500);
      }
    });
  }

  _setZoom(v) {
    v = Math.max(50, Math.min(200, parseInt(v, 10) || 100));
    this.page.style.transform = `scale(${v / 100})`;
    this.page.style.transformOrigin = 'top center';
    if (this.zoomRange) this.zoomRange.value = v;
    if (this.zoomLabel) this.zoomLabel.textContent = v + '%';
  }

  _zoomDialog() {
    const host = document.getElementById('dialogHost');
    openDialog({
      host, title: 'Zoom',
      content: `<label>Zoom: <input type="number" id="_zoomVal" value="${this.zoomRange?.value || 100}" min="50" max="200"> %</label>`,
      buttons: [
        { label: 'Cancel' },
        { label: 'OK', primary: true, onClick: (body, close) => {
            const v = body.querySelector('#_zoomVal').value;
            this._setZoom(v); close();
          } },
      ],
    });
  }

  _updateStatus() {
    const text = this.page.innerText || '';
    const words = text.trim() ? text.trim().split(/\s+/).length : 0;
    if (this.wordCountEl) this.wordCountEl.textContent = `${words} word${words === 1 ? '' : 's'}`;
    if (this.charCountEl) this.charCountEl.textContent = `${text.length} characters`;
    const pages = Math.max(1, Math.round(this.page.scrollHeight / 1056));
    if (this.pageInfoEl) this.pageInfoEl.textContent = `Page 1 of ${pages}`;
  }

  // ============ Shortcuts ============
  _setupShortcuts() {
    const sc = new Shortcuts({
      'ctrl+b': () => this.command('bold'),
      'ctrl+i': () => this.command('italic'),
      'ctrl+u': () => this.command('underline'),
      'ctrl+s': (e) => { e.preventDefault(); this.saveNow(); },
      'ctrl+z': (e) => { e.preventDefault(); this.history.undo(); this._updateStatus(); },
      'ctrl+y': (e) => { e.preventDefault(); this.history.redo(); this._updateStatus(); },
      'ctrl+shift+z': () => { this.history.redo(); this._updateStatus(); },
      'ctrl+f': (e) => { e.preventDefault(); this._showFind(); },
      'ctrl+h': (e) => { e.preventDefault(); this._showReplace(); },
      'ctrl+enter': () => this.command('insertPageBreak'),
      'f9': () => { WriterFields.update(this); },
    });
    sc.bind();
  }

  // ============ Context menu ============
  _setupContextMenu() {
    const host = document.getElementById('contextMenu');
    this.page.addEventListener('contextmenu', (e) => {
      e.preventDefault();
      showContextMenu(host, e.clientX, e.clientY, [
        { label: 'Cut', shortcut: 'Ctrl+X', action: () => document.execCommand('cut') },
        { label: 'Copy', shortcut: 'Ctrl+C', action: () => document.execCommand('copy') },
        { label: 'Paste', shortcut: 'Ctrl+V', action: () => this._paste() },
        { sep: true },
        { label: 'Bold', shortcut: 'Ctrl+B', action: () => this.command('bold') },
        { label: 'Italic', shortcut: 'Ctrl+I', action: () => this.command('italic') },
        { label: 'Underline', shortcut: 'Ctrl+U', action: () => this.command('underline') },
        { sep: true },
        { label: 'Insert link…', action: () => this._insertLink() },
        { label: 'Insert table…', action: () => this.command('insertTable', [3,3]) },
        { label: 'New Comment', action: () => this.command('newComment') },
        { label: 'Insert Footnote', action: () => this.command('insertFootnote') },
      ]);
    });
    document.addEventListener('click', () => hideContextMenu(host));
  }

  // ============ Find / Replace ============
  _showFind() {
    const host = document.getElementById('dialogHost');
    openDialog({
      host, title: 'Find',
      content: `<label>Find: <input id="_findTxt" type="text" style="width:100%;margin-top:6px;padding:6px;border:1px solid var(--border);border-radius:4px;"></label>
                <div id="_findResults" style="margin-top:12px; font-size:12px; color: var(--text-muted);"></div>`,
      buttons: [
        { label: 'Close' },
        { label: 'Find next', primary: true, close: false, onClick: (body) => {
            const q = body.querySelector('#_findTxt').value;
            if (!q) return false;
            this._findNext(q, body);
            return false;
          }},
      ],
    });
  }

  _findNext(q, body) {
    const text = this.page.innerText;
    const idx = text.toLowerCase().indexOf(q.toLowerCase());
    if (idx < 0) { body.querySelector('#_findResults').textContent = 'No matches.'; return; }
    let acc = 0, found = null, foundOffset = 0;
    const walker = document.createTreeWalker(this.page, NodeFilter.SHOW_TEXT);
    let node;
    while (node = walker.nextNode()) {
      const len = node.nodeValue.length;
      if (acc + len > idx) { found = node; foundOffset = idx - acc; break; }
      acc += len;
    }
    if (!found) return;
    const r = document.createRange();
    r.setStart(found, foundOffset);
    r.setEnd(found, foundOffset + q.length);
    window.getSelection().removeAllRanges();
    window.getSelection().addRange(r);
    body.querySelector('#_findResults').textContent = `Match at position ${idx}.`;
  }

  _showReplace() {
    const host = document.getElementById('dialogHost');
    openDialog({
      host, title: 'Find and Replace',
      content: `
        <label>Find: <input id="_frFind" style="width:100%;padding:6px;margin-top:4px;border:1px solid var(--border);border-radius:4px;"></label>
        <label style="display:block;margin-top:8px;">Replace with: <input id="_frRepl" style="width:100%;padding:6px;margin-top:4px;border:1px solid var(--border);border-radius:4px;"></label>
        <label style="display:block;margin-top:8px;"><input type="checkbox" id="_frAll"> Replace all</label>`,
      buttons: [
        { label: 'Close' },
        { label: 'Replace', primary: true, close: false, onClick: (body) => {
            const f = body.querySelector('#_frFind').value;
            const r = body.querySelector('#_frRepl').value;
            const all = body.querySelector('#_frAll').checked;
            if (!f) return false;
            const html = this.page.innerHTML;
            if (all) this.page.innerHTML = html.split(f).join(r);
            else this.page.innerHTML = html.replace(f, r);
            this._snapshot('replace');
            return false;
          }},
      ],
    });
  }

  // ============ Phase 4 dialogs ============
  _insertFieldDialog() {
    const host = document.getElementById('dialogHost');
    const wrap = document.createElement('div');
    const fields = ['PAGE','NUMPAGES','DATE','TIME','CREATEDATE','SAVEDATE','TITLE','AUTHOR','FILENAME','NUMWORDS','NUMCHARS','SEQ','REF'];
    wrap.innerHTML = `
      <label>Field: <select id="_fdName">${fields.map(f => `<option>${f}</option>`).join('')}</select></label>
      <label style="display:block;margin-top:8px;">Args (optional): <input id="_fdArgs" style="width:100%;padding:4px;"></label>`;
    openDialog({
      host, title: 'Insert Field', content: wrap,
      buttons: [
        { label: 'Cancel' },
        { label: 'Insert', primary: true, onClick: (body, close) => {
            const name = body.querySelector('#_fdName').value;
            const args = body.querySelector('#_fdArgs').value;
            WriterFields.insert(this, name, args);
            this._snapshot('insert field');
            close();
          } },
      ],
    });
  }

  _mailMergeWizard() {
    const host = document.getElementById('dialogHost');
    const wrap = document.createElement('div');
    wrap.innerHTML = `
      <div>Paste CSV rows (one per record, first row = column headers):</div>
      <textarea id="_mmCsv" rows="6" style="width:100%;padding:6px;border:1px solid var(--border);border-radius:4px;"></textarea>
      <div style="margin-top:8px;">Your document should contain placeholders like {{Name}}, {{Company}}.</div>
      <div id="_mmOut" style="margin-top:8px;color:var(--text-muted);"></div>`;
    openDialog({
      host, title: 'Mail Merge', content: wrap,
      buttons: [
        { label: 'Cancel' },
        { label: 'Merge', primary: true, close: false, onClick: (body) => {
            const csv = body.querySelector('#_mmCsv').value.trim();
            if (!csv) return false;
            const rows = parseCsv(csv);
            const html = rows.map(rec => {
              let s = this.page.innerHTML;
              for (const [k, v] of Object.entries(rec)) {
                s = s.split(`{{${k}}}`).join(escapeHtml(v));
              }
              return s;
            }).join('<div style="page-break-after:always;"></div>');
            this.page.innerHTML = html;
            this._snapshot('mail merge');
            body.querySelector('#_mmOut').textContent = `Merged ${rows.length} records.`;
            return false;
          } },
      ],
    });
  }

  _watermarkDialog() {
    prompt2({
      title: 'Watermark', host: document.getElementById('dialogHost'),
      fields: [{ name: 'text', label: 'Text', value: 'DRAFT' },
               { name: 'color', label: 'Color', value: '#C0C0C0' }],
    }).then(r => {
      if (!r?.text) return;
      this.watermark = { text: r.text, color: r.color };
      let wm = this.page.querySelector('.watermark');
      if (!wm) { wm = document.createElement('div'); wm.className = 'watermark'; this.page.prepend(wm); }
      wm.style.cssText = `position:absolute; top:40%; left:50%; transform:translate(-50%,-50%) rotate(-30deg); font-size:120px; color:${r.color}; opacity:.25; pointer-events:none; white-space:nowrap; z-index:0;`;
      wm.textContent = r.text;
      this._snapshot('watermark');
    });
  }

  // ============ Autosave + Persistence ============
  _setupAutosave() {
    this.autosaver = new AutoSaver({
      getId: () => this.docId,
      getModel: () => this._serialize(),
      save: async (id, model) => { if (id) await api.updateDoc(id, this.titleEl.value, model); },
    });
    this.autosaver.onStatus(s => {
      const el = document.getElementById('saveStatus');
      if (el) el.textContent = s;
    });
  }

  async saveNow() {
    const model = this._serialize();
    if (!this.docId) {
      try {
        const created = await api.createDoc('word', this.titleEl.value, model);
        this.docId = created.id;
        history.replaceState(null, '', `?id=${this.docId}`);
      } catch (e) { console.warn('save failed (offline?)', e); }
    } else {
      try { await api.updateDoc(this.docId, this.titleEl.value, model); }
      catch (e) { console.warn('save failed', e); }
    }
    await storage.put(this.docId || 'draft-word', model);
  }

  _serialize() {
    const blocks = [];
    for (const child of this.page.children) blocks.push(this._serializeBlock(child));
    return {
      meta: { title: this.titleEl.value, author: 'You' },
      pageSetup: { size: 'Letter', orientation: 'portrait',
                   marginTop: 96, marginBottom: 96, marginLeft: 96, marginRight: 96 },
      styles: {}, blocks, headers: {}, footers: {},
      comments: this.comments.comments,
      revisions: this.trackChanges.revisions,
      footnotes: this.footnotes,
      watermark: this.watermark,
      schemaVersion: 4,
    };
  }

  _serializeBlock(el) {
    const tag = el.tagName.toLowerCase();
    if (tag === 'table') {
      const rows = [...el.rows].map(r => [...r.cells].map(c => c.innerText));
      return { type: 'table', rows, attrs: {} };
    }
    if (tag.match(/^h[1-6]$/)) {
      return { type: 'heading', runs: this._serializeRuns(el), attrs: { level: parseInt(tag[1], 10) } };
    }
    if (tag === 'img') {
      return { type: 'image', attrs: { src: el.src, width: 4 } };
    }
    return { type: 'paragraph', runs: this._serializeRuns(el), attrs: { style: 'Normal' } };
  }

  _serializeRuns(el) {
    const runs = [];
    const walk = (node, attrs) => {
      if (node.nodeType === 3) {
        if (node.nodeValue) runs.push({ text: node.nodeValue, attrs: { ...attrs } });
        return;
      }
      if (node.nodeType !== 1) return;
      const a = { ...attrs };
      const style = node.style;
      if (style.fontWeight === 'bold' || node.tagName === 'B' || node.tagName === 'STRONG') a.bold = true;
      if (style.fontStyle === 'italic' || node.tagName === 'I' || node.tagName === 'EM') a.italic = true;
      if (style.textDecoration.includes('underline') || node.tagName === 'U') a.underline = true;
      if (style.textDecoration.includes('line-through') || node.tagName === 'S') a.strike = true;
      if (node.tagName === 'SUB') a.sub = true;
      if (node.tagName === 'SUP') a.sup = true;
      if (style.color) a.color = style.color;
      if (style.fontFamily) a.font = style.fontFamily.replace(/["']/g,'');
      if (style.fontSize) a.size = parseFloat(style.fontSize);
      for (const c of node.childNodes) walk(c, a);
    };
    walk(el, {});
    return runs;
  }

  async _loadDoc() {
    try {
      const doc = await api.getDoc(this.docId);
      this.titleEl.value = doc.name || 'Untitled';
      this._renderModel(doc.data);
      this.footnotes = doc.data.footnotes || [];
      this.watermark = doc.data.watermark || null;
      this.comments.comments = doc.data.comments || [];
      this.trackChanges.revisions = doc.data.revisions || [];
      this._lastHTML = this.page.innerHTML;
    } catch (e) {
      const j = await storage.get(this.docId);
      if (j?.data) { this._renderModel(j.data); this._lastHTML = this.page.innerHTML; }
      else { this.page.innerHTML = '<p><br></p>'; }
    }
  }

  _renderModel(model) {
    const html = [];
    for (const b of (model.blocks || [])) html.push(this._renderBlock(b));
    this.page.innerHTML = html.join('') || '<p><br></p>';
  }

  _renderBlock(b) {
    if (b.type === 'table') {
      const rows = (b.rows || []).map(r => `<tr>${r.map(c => `<td>${escapeHtml(c)}</td>`).join('')}</tr>`).join('');
      return `<table>${rows}</table>`;
    }
    if (b.type === 'heading') {
      const lv = b.attrs?.level || 1;
      return `<h${lv}>${this._renderRuns(b.runs)}</h${lv}>`;
    }
    if (b.type === 'image') {
      return `<p><img src="${escapeHtml(b.attrs?.src || '')}" style="max-width:100%"></p>`;
    }
    return `<p>${this._renderRuns(b.runs)}</p>`;
  }

  _renderRuns(runs) {
    return (runs || []).map(r => {
      let t = escapeHtml(r.text || '');
      const a = r.attrs || {};
      if (a.bold) t = `<strong>${t}</strong>`;
      if (a.italic) t = `<em>${t}</em>`;
      if (a.underline) t = `<u>${t}</u>`;
      if (a.strike) t = `<s>${t}</s>`;
      if (a.sub) t = `<sub>${t}</sub>`;
      if (a.sup) t = `<sup>${t}</sup>`;
      const styles = [];
      if (a.color) styles.push(`color:${a.color}`);
      if (a.font) styles.push(`font-family:${a.font}`);
      if (a.size) styles.push(`font-size:${a.size}pt`);
      return styles.length ? `<span style="${styles.join(';')}">${t}</span>` : t;
    }).join('');
  }

  // ============ Backstage ============
  _setupBackstage() {
    const host = document.getElementById('backstage');
    this.backstage = new Backstage({
      host,
      title: () => this.titleEl.value,
      onNew: () => { this.page.innerHTML = '<p><br></p>'; this.history.clear(); },
      onOpenFile: () => this._importFile(),
      onSave: () => this.saveNow(),
      onExport: async (fmt) => {
        const blob = await api.exportDoc('word', fmt, this._serialize(), this.titleEl.value || 'document');
        await api.downloadBlob(blob, `${this.titleEl.value || 'document'}.${fmt}`);
      },
    });
    window.addEventListener('ribbon:backstage', () => this.backstage.open('home'));
    document.getElementById('exportBtn')?.addEventListener('click', () => this.backstage.open('export'));
  }

  async _importFile() {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.docx,.doc,.rtf,.odt,.txt,.md';
    input.onchange = async () => {
      const f = input.files[0]; if (!f) return;
      try {
        const ext = f.name.toLowerCase().split('.').pop();
        let model;
        if (['doc','rtf','odt'].includes(ext)) {
          const res = await api.importLegacy(f);
          model = res.model;
        } else {
          const res = await api.importFile('word', f);
          model = res.model;
        }
        this._renderModel(model);
        this.titleEl.value = f.name.replace(/\.[^.]+$/, '');
        this._snapshot('import');
      } catch (e) { alert('Import failed: ' + e.message); }
    };
    input.click();
  }
      // Real-time collaboration (only if docId exists and server enables it)
    if (this.docId) {
      this.presence = new Presence();
      this.collab = new Collab({
        docId: this.docId,
        onPeers: (peers) => this.presence.update(peers),
        onCursor: (cid, cursor) => this.presence.showCursor(cid, cursor, null),
        onOp: (msg) => {
          // Placeholder: full op-based sync is future work; this is a safe log.
          console.log('[collab] op received', msg.op);
        },
      });
      this.collab.connect();

      // Broadcast our cursor position to peers
      this.page.addEventListener('mousemove', (e) => {
        this.collab?.sendCursor({ x: e.clientX, y: e.clientY });
      });
    }
  _setupTellMe() {
    new TellMe({
      ribbonConfig: wordRibbon,
      host: document.getElementById('tellMeResults'),
      onRun: (cmd) => this.command(cmd.id, cmd.value),
    });
  }

  _bindSelectionEvents() {
    document.addEventListener('selectionchange', () => this._refreshStatus());
    this.page.addEventListener('keydown', (e) => {
      if (e.key === 'Tab') {
        e.preventDefault();
        document.execCommand(e.shiftKey ? 'outdent' : 'indent');
      }
    });
  }
}

function escapeHtml(s) {
  return String(s ?? '').replace(/[&<>"']/g, c => ({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' }[c]));
}

function parseCsv(text) {
  const lines = text.split(/\r?\n/).filter(l => l.trim());
  if (!lines.length) return [];
  const headers = lines[0].split(',').map(h => h.trim());
  return lines.slice(1).map(line => {
    const cells = line.split(',').map(c => c.trim());
    const rec = {};
    headers.forEach((h, i) => rec[h] = cells[i] || '');
    return rec;
  });
}