/**
 * Formatting helpers used by Writer. Currently thin — most formatting
 * happens through WriterApp.command().
 */
export const WriterFormatting = {
  ptToPx(pt) { return pt * 96 / 72; },
  pxToPt(px) { return px * 72 / 96; },
};