/** Image helpers for Writer. */
export const WriterImages = {
  resize(img, width) { img.width = width; img.style.height = 'auto'; },
  crop(img, { left = 0, top = 0, right = 0, bottom = 0 } = {}) {
    img.style.clipPath = `inset(${top}px ${right}px ${bottom}px ${left}px)`;
  },
};