/** Slides object factories with alt text and grid helpers. */
export const SlidesObjects = {
  text({ x = 100, y = 100, w = 400, h = 100, text = 'Text', fontSize = 24, color = '#1f1f1f', bold = false, italic = false } = {}) {
    return { type: 'text', x, y, w, h, rot: 0, props: { text, fontSize, color, bold, italic } };
  },
  shape({ x = 100, y = 100, w = 200, h = 100, shape = 'rect', fill = '#dfe9f7' } = {}) {
    return { type: 'shape', x, y, w, h, rot: 0, props: { shape, fill } };
  },
  image({ x = 100, y = 100, w = 300, h = 200, src = '' } = {}) {
    return { type: 'image', x, y, w, h, rot: 0, props: { src } };
  },
  chart({ x = 200, y = 150, w = 640, h = 400, spec = null } = {}) {
    return { type: 'chart', x, y, w, h, rot: 0, props: { chart: spec || {
      type: 'column', categories: ['Q1','Q2','Q3','Q4'],
      series: [{ name: 'Series 1', values: [1,2,3,4] }],
    } } };
  },
  table({ x = 200, y = 200, w = 600, h = 200, rows = null } = {}) {
    return { type: 'table', x, y, w, h, rot: 0, props: { rows: rows || [['A','B','C'],['1','2','3'],['4','5','6']] } };
  },
  diagram({ x = 200, y = 250, w = 700, h = 220, kind = 'process', nodes = null } = {}) {
    return { type: 'diagram', x, y, w, h, rot: 0, props: { diagram: { kind, nodes: nodes || ['Step 1','Step 2','Step 3'] } } };
  },
  group({ x = 0, y = 0, children = [] } = {}) {
    return { type: 'group', x, y, children };
  },
};