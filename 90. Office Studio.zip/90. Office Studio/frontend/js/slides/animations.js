/** Animation definitions used by the ribbon + timeline pane. */
export const SlidesAnimations = {
  entrance: ['appear', 'fade', 'fly-in', 'float-in', 'wipe', 'zoom', 'spin'],
  emphasis: ['pulse', 'spin', 'grow'],
  exit:     ['disappear', 'fade-out', 'fly-out'],
  motionPaths: ['arc', 'line', 'circle'],
};