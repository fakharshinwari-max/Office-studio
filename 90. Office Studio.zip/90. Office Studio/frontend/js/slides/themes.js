/** Slide themes — color + font sets. */
export const SlidesThemes = {
  office:  { bg: '#ffffff', fg: '#1f1f1f', accent: '#2b579a', headingFont: 'Calibri, Segoe UI, sans-serif', bodyFont: 'Calibri, Segoe UI, sans-serif' },
  dark:    { bg: '#1f1f1f', fg: '#f3f3f3', accent: '#4a90e2', headingFont: 'Segoe UI, sans-serif', bodyFont: 'Segoe UI, sans-serif' },
  vibrant: { bg: '#fdf6ec', fg: '#2b1b03', accent: '#d24726', headingFont: 'Georgia, serif', bodyFont: 'Segoe UI, sans-serif' },
  minimal: { bg: '#fafafa', fg: '#222222', accent: '#217346', headingFont: 'Inter, sans-serif', bodyFont: 'Inter, sans-serif' },
  bold:    { bg: '#0a1128', fg: '#ffffff', accent: '#f2c94c', headingFont: 'Impact, Arial, sans-serif', bodyFont: 'Arial, sans-serif' },
  pastel:  { bg: '#fef7ff', fg: '#4a3a52', accent: '#b57edc', headingFont: 'Georgia, serif', bodyFont: 'Segoe UI, sans-serif' },
};