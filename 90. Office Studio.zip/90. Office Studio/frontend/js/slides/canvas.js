/**
 * Slides app — Phase 3.
 * Adds: masters/layouts, themes, sections, sorter view, notes master,
 * group/ungroup, align/distribute, snap-to-grid, smart guides,
 * animations with timeline pane, transitions, morph, charts, tables,
 * SmartArt-style diagrams, presenter view + annotate + laser, rehearse timings,
 * real OOXML export/import round-trip.
 */
import { api } from '../core/api.js';
import { History } from '../core/history.js';
import { AutoSaver, storage } from '../core/storage.js';
import { Ribbon } from '../core/ribbon.js';
import { pptRibbon } from '../core/ribbon-config-ppt.js';
import { Shortcuts } from '../core/shortcuts.js';
import { Backstage } from '../core/backstage.js';
import { TellMe } from '../core/tellme.js';
import { showContextMenu } from '../core/context-menu.js';
import { openDialog, prompt2 } from '../core/dialogs.js';
import { SlidesObjects } from './objects.js';
import { SlidesThemes } from './themes.js';
import { SlidesAnimations } from './animations.js';
import { SlidesPresenter } from './presenter.js';

const GRID_SNAP = 8;            // px snap increment
const SMART_GUIDE_DIST = 6;     // px distance to snap to another object
const MIN_OBJ = 20;

export class SlidesApp {
  constructor({ canvasEl, panelEl, ribbonHost, titleEl }) {
    this.canvasEl = canvasEl;
    this.panelEl = panelEl;
    this.ribbonHost = ribbonHost;
    this.titleEl = titleEl;
    this.history = new History();
    this.docId = new URLSearchParams(location.search).get('id');

    this.size = { w: 1280, h: 720 };
    this.theme = 'office';
    this.master = { layouts: defaultLayouts() };
    this.sections = [];
    this.slides = [emptySlide('title-content')];
    this.current = 0;
    this.selected = [];   // object ids (multi-select via Ctrl)
    this.clipboard = null;

    this.snapToGrid = true;
    this.snapToObjects = true;

    this._charts = new Map();   // objectId -> Chart instance

    this.presenter = new SlidesPresenter(this);
  }

  // =========== Lifecycle ===========
  async init() {
    this._setupRibbon();
    this._setupShortcuts();
    this._setupContextMenu();
    this._setupAutosave();
    this._setupBackstage();
    this._setupTellMe();
    this._setupCanvasDragDrop();
    this._setupNotesEditor();

    if (this.docId) await this._loadDoc();

    this._applyTheme();
    this._render();
    document.addEventListener('keydown', (e) => this._onGlobalKey(e));
  }

  // =========== Theme & master ===========
  _applyTheme() {
    const t = SlidesThemes[this.theme] || SlidesThemes.office;
    this.canvasEl.style.background = t.bg;
    this.canvasEl.style.color = t.fg;
    this._renderCurrentThemeVars(t);
  }
  _renderCurrentThemeVars(t) {
    this._themeVars = t;
  }

  setLayout(layoutName) {
    const slide = this.slides[this.current];
    slide.layout = layoutName;
    // Populate placeholders for that layout
    slide.objects = (this.master.layouts.find(l => l.name === layoutName)?.placeholders || [])
      .map(ph => ({
        id: 'o' + rand(),
        type: 'text',
        x: ph.x, y: ph.y, w: ph.w, h: ph.h,
        rot: 0,
        placeholder: ph.type,
        props: { text: ph.defaultText || '', fontSize: ph.fontSize || 24, color: this._themeVars.fg },
      }));
    this._snapshot('set layout');
    this._render();
  }
  openMasterView() {
    // Phase 3: open a modal that lets the user edit the placeholder boxes for the current layout
    this._showMasterEditor();
  }

  _showMasterEditor() {
    const host = document.getElementById('dialogHost');
    const wrap = document.createElement('div');
    const current = this.slides[this.current].layout;
    wrap.innerHTML = `
      <label>Current layout:
        <select id="_mvLayout" style="width:100%;padding:6px;border:1px solid var(--border);border-radius:4px;">
          ${this.master.layouts.map(l => `<option ${l.name===current?'selected':''}>${l.name}</option>`).join('')}
        </select>
      </label>
      <div style="margin-top:12px;color:var(--text-muted);font-size:12px;">
        Placeholders are edited directly on the slide after applying this layout.
      </div>`;
    openDialog({
      host, title: 'Slide Master — layouts', content: wrap,
      buttons: [
        { label: 'Cancel' },
        { label: 'Apply', primary: true, onClick: (body) => {
            const layout = body.querySelector('#_mvLayout').value;
            this.setLayout(layout);
          } },
      ],
    });
  }

  // =========== Rendering ===========
  _render() {
    this._renderThumbnails();
    this._renderCanvas();
    this._renderNotes();
    this._updateStatus();
    this._renderCharts();
  }

  _renderThumbnails() {
    this.panelEl.innerHTML = '';
    let sectionIdx = 0;
    const sections = this.sections.length ? this.sections : [{ name: '', slides: this.slides.map((_, i) => i) }];
    for (const sec of sections) {
      const h = document.createElement('div');
      h.className = 'slide-section';
      h.textContent = sec.name || 'Slides';
      if (this.sections.length) this.panelEl.appendChild(h);

      for (const i of sec.slides) {
        const s = this.slides[i];
        if (!s) continue;
        const t = document.createElement('div');
        t.className = 'slide-thumb' + (i === this.current ? ' active' : '');
        t.innerHTML = `<span class="num">${i + 1}</span>`;
        t.onclick = () => { this.current = i; this.selected = []; this._render(); };
        t.ondblclick = () => this.presenter.from(i);
        t.oncontextmenu = (e) => this._thumbContextMenu(e, i);
        const preview = document.createElement('div');
        preview.style.cssText = 'position:absolute;inset:0;overflow:hidden;padding:6px;font-size:7px;color:#333;';
        for (const o of s.objects) preview.appendChild(this._thumbObject(o));
        t.appendChild(preview);
        this.panelEl.appendChild(t);
      }
    }
  }

  _thumbObject(o) {
    const d = document.createElement('div');
    d.style.cssText = `position:absolute;left:${(o.x/this.size.w)*100}%;top:${(o.y/this.size.h)*100}%;width:${(o.w/this.size.w)*100}%;height:${(o.h/this.size.h)*100}%;overflow:hidden;`;
    if (o.type === 'text') d.textContent = (o.props?.text || '').slice(0, 40);
    if (o.type === 'shape') d.style.background = o.props?.fill || '#dfe9f7';
    if (o.type === 'chart') d.style.background = '#eef3fa';
    return d;
  }

  _renderCanvas() {
    this.canvasEl.innerHTML = '';
    const slide = this.slides[this.current];
    for (const o of slide.objects) {
      const el = this._buildObjectEl(o);
      this.canvasEl.appendChild(el);
    }
    this._renderSelectionOverlay();
  }

  _buildObjectEl(o) {
    const el = document.createElement('div');
    el.className = 'slide-object ' + o.type + (this.selected.includes(o.id) ? ' selected' : '');
    el.dataset.id = o.id;
    Object.assign(el.style, {
      left: (o.x / this.size.w * 100) + '%',
      top: (o.y / this.size.h * 100) + '%',
      width: (o.w / this.size.w * 100) + '%',
      height: (o.h / this.size.h * 100) + '%',
      transform: o.rot ? `rotate(${o.rot}deg)` : '',
    });
    if (o.type === 'text') {
      el.textContent = o.props?.text || '';
      if (o.props?.fontSize) el.style.fontSize = (o.props.fontSize / this.size.w * 100) + 'vw';
      if (o.props?.color) el.style.color = o.props.color;
      if (o.props?.bold) el.style.fontWeight = '600';
      if (o.props?.italic) el.style.fontStyle = 'italic';
      if (o.props?.underline) el.style.textDecoration = 'underline';
      el.contentEditable = 'false';
      el.ondblclick = () => this._editTextInline(o, el);
    }
    if (o.type === 'shape') {
      el.style.background = o.props?.fill || '#dfe9f7';
      if (o.props?.border) el.style.border = o.props.border;
      el.style.borderRadius = o.props?.radius ? o.props.radius + 'px' : '2px';
    }
    if (o.type === 'image') {
      const img = document.createElement('img');
      img.src = o.props.src;
      img.style.cssText = 'width:100%;height:100%;object-fit:contain;pointer-events:none;';
      el.appendChild(img);
    }
    if (o.type === 'chart') {
      const c = document.createElement('canvas');
      c.className = 'slide-chart-canvas';
      c.style.cssText = 'width:100%;height:100%;';
      c.dataset.chartFor = o.id;
      el.appendChild(c);
      // Chart instance is created after DOM insertion in _renderCharts
    }
    if (o.type === 'table') {
      const tbl = document.createElement('table');
      tbl.style.cssText = 'width:100%;height:100%;border-collapse:collapse;font-size:11px;';
      for (const row of o.props?.rows || []) {
        const tr = document.createElement('tr');
        for (const cell of row) {
          const td = document.createElement('td');
          td.textContent = cell;
          td.style.cssText = 'border:1px solid #bbb;padding:3px 6px;';
          tr.appendChild(td);
        }
        tbl.appendChild(tr);
      }
      el.appendChild(tbl);
    }
    if (o.type === 'diagram') {
      this._renderDiagram(el, o);
    }

    el.onmousedown = (e) => this._onObjectMouseDown(e, o, el);
    el.oncontextmenu = (e) => this._objectContextMenu(e, o);
    return el;
  }

  _renderDiagram(el, o) {
    const d = o.props?.diagram;
    if (!d) return;
    el.style.position = 'absolute';
    if (d.kind === 'process') {
      const stepW = 100 / Math.max(d.nodes.length, 1);
      el.innerHTML = d.nodes.map((n, i) =>
        `<div style="position:absolute;left:${i*stepW}%;top:0;width:${stepW}%;height:100%;background:#dfe9f7;border:1px solid #2b579a;display:flex;align-items:center;justify-content:center;font-size:12px;text-align:center;padding:4px;">${escapeHtml(n)}</div>`
      ).join('');
    } else if (d.kind === 'cycle') {
      const radius = 35;
      el.innerHTML = d.nodes.map((n, i) => {
        const angle = 2 * Math.PI * i / d.nodes.length;
        const x = 50 + radius * Math.cos(angle);
        const y = 50 + radius * Math.sin(angle);
        return `<div style="position:absolute;left:${x}%;top:${y}%;transform:translate(-50%,-50%);width:24%;height:24%;background:#dfe9f7;border:1px solid #2b579a;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:11px;text-align:center;">${escapeHtml(n)}</div>`;
      }).join('');
    } else if (d.kind === 'hierarchy') {
      const [top, ...children] = d.nodes;
      el.innerHTML = `<div style="position:absolute;left:25%;top:0;width:50%;height:30%;background:#dfe9f7;border:1px solid #2b579a;display:flex;align-items:center;justify-content:center;font-size:12px;">${escapeHtml(top)}</div>` +
        children.map((n, i) => {
          const cw = 100 / children.length;
          return `<div style="position:absolute;left:${i*cw}%;top:70%;width:${cw - 1}%;height:30%;background:#eef3fa;border:1px solid #2b579a;display:flex;align-items:center;justify-content:center;font-size:11px;text-align:center;">${escapeHtml(n)}</div>`;
        }).join('');
    }
  }

  _renderSelectionOverlay() {
    // Remove any existing overlay
    this.canvasEl.querySelectorAll('.selection-handles').forEach(n => n.remove());
    if (!this.selected.length) return;
    const obj = this.slides[this.current].objects.find(o => o.id === this.selected[0]);
    if (!obj) return;
    const el = this.canvasEl.querySelector(`[data-id="${obj.id}"]`);
    if (!el) return;
    for (const pos of ['nw','ne','sw','se']) {
      const h = document.createElement('div');
      h.className = 'handle ' + pos;
      h.dataset.handle = pos;
      el.appendChild(h);
    }
  }

  _renderCharts() {
    if (!window.Chart) {
      // Lazy-load Chart.js
      const s = document.createElement('script');
      s.src = 'https://cdn.jsdelivr.net/npm/chart.js@4.4.3/dist/chart.umd.min.js';
      s.onload = () => this._renderCharts();
      document.head.appendChild(s);
      return;
    }
    const slide = this.slides[this.current];
    for (const o of slide.objects) {
      if (o.type !== 'chart') continue;
      const canvas = this.canvasEl.querySelector(`canvas[data-chart-for="${o.id}"]`);
      if (!canvas) continue;
      const spec = o.props?.chart || {};
      try {
        const prev = this._charts.get(o.id);
        if (prev) prev.destroy();
        const chart = new Chart(canvas, {
          type: mapChartType(spec.type || 'column'),
          data: {
            labels: spec.categories || [],
            datasets: (spec.series || []).map((s, i) => ({
              label: s.name || `Series ${i+1}`,
              data: s.values || [],
              backgroundColor: s.color || themeChartColor(i),
              borderColor: s.color || themeChartColor(i),
              borderWidth: 2,
            })),
          },
          options: { responsive: true, maintainAspectRatio: false, animation: false },
        });
        this._charts.set(o.id, chart);
      } catch (e) { console.warn('chart render', e); }
    }
  }

  _renderNotes() {
    const el = document.getElementById('notesArea');
    if (el) el.value = this.slides[this.current].notes || '';
  }
  _setupNotesEditor() {
    const el = document.getElementById('notesArea');
    if (!el) return;
    el.addEventListener('input', () => {
      this.slides[this.current].notes = el.value;
      this._snapshotDebounced('notes');
    });
  }

  _snapshotDebounced(label) {
    clearTimeout(this._snapT);
    this._snapT = setTimeout(() => this._snapshot(label), 400);
  }

  // =========== Object manipulation ===========
  _onObjectMouseDown(e, obj, el) {
    if (e.button !== 0) return;
    e.stopPropagation();
    const ctrl = e.ctrlKey || e.metaKey;
    if (ctrl) {
      this.selected = this.selected.includes(obj.id)
        ? this.selected.filter(x => x !== obj.id)
        : [...this.selected, obj.id];
    } else if (!this.selected.includes(obj.id)) {
      this.selected = [obj.id];
    }
    this._render();

    // Determine if this is a resize
    const rect = this.canvasEl.getBoundingClientRect();
    const scaleX = this.size.w / rect.width;
    const scaleY = this.size.h / rect.height;
    const isResize = e.target.classList.contains('handle');
    const handle = isResize ? e.target.dataset.handle : null;
    const startX = e.clientX, startY = e.clientY;
    const snap = this.selected.length === 1 ? this.slides[this.current].objects.find(o => o.id === this.selected[0]) : null;
    const ox = snap?.x ?? 0, oy = snap?.y ?? 0, ow = snap?.w ?? 0, oh = snap?.h ?? 0;

    const moveHandler = (mv) => {
      const dx = (mv.clientX - startX) * scaleX;
      const dy = (mv.clientY - startY) * scaleY;
      const targets = this.slides[this.current].objects.filter(o => this.selected.includes(o.id));
      for (const o of targets) {
        const base = this._mousedownOriginals?.[o.id] || (this._mousedownOriginals = this._mousedownOriginals || {}, this._mousedownOriginals[o.id] = { x: o.x, y: o.y, w: o.w, h: o.h });
      }
      if (isResize && snap) {
        this._resizeObject(snap, handle, dx, dy, { ow, oh, ox, oy });
      } else {
        for (const o of targets) {
          const orig = this._mousedownOriginals[o.id];
          if (!orig) continue;
          o.x = orig.x + dx;
          o.y = orig.y + dy;
        }
        if (this.snapToObjects) this._applySmartGuides(targets);
        if (this.snapToGrid) for (const o of targets) { o.x = Math.round(o.x / GRID_SNAP) * GRID_SNAP; o.y = Math.round(o.y / GRID_SNAP) * GRID_SNAP; }
      }
      this._render();
    };
    const upHandler = () => {
      document.removeEventListener('mousemove', moveHandler);
      document.removeEventListener('mouseup', upHandler);
      this._mousedownOriginals = null;
      this._clearSmartGuides();
      this._snapshot('move/resize');
      this.autosaver?.schedule();
    };
    document.addEventListener('mousemove', moveHandler);
    document.addEventListener('mouseup', upHandler);
  }

  _resizeObject(o, handle, dx, dy, orig) {
    const min = MIN_OBJ;
    if (handle.includes('e')) o.w = Math.max(min, orig.ow + dx);
    if (handle.includes('s')) o.h = Math.max(min, orig.oh + dy);
    if (handle.includes('w')) { o.x = orig.ox + dx; o.w = Math.max(min, orig.ow - dx); }
    if (handle.includes('n')) { o.y = orig.oy + dy; o.h = Math.max(min, orig.oh - dy); }
  }

  _applySmartGuides(targets) {
    // Simple: if a target's left/center/right align with another object, snap.
    const all = this.slides[this.current].objects;
    for (const t of targets) {
      const tXs = [t.x, t.x + t.w / 2, t.x + t.w];
      const tYs = [t.y, t.y + t.h / 2, t.y + t.h];
      for (const other of all) {
        if (targets.includes(other)) continue;
        const oXs = [other.x, other.x + other.w / 2, other.x + other.w];
        const oYs = [other.y, other.y + other.h / 2, other.y + other.h];
        for (const tx of tXs) for (const ox of oXs) if (Math.abs(tx - ox) < SMART_GUIDE_DIST) { t.x += ox - tx; break; }
        for (const ty of tYs) for (const oy of oYs) if (Math.abs(ty - oy) < SMART_GUIDE_DIST) { t.y += oy - ty; break; }
      }
    }
  }
  _clearSmartGuides() { /* No persistent guides drawn in Phase 3 */ }

  _editTextInline(o, el) {
    el.contentEditable = 'true';
    el.focus();
    const onBlur = () => {
      o.props = o.props || {};
      o.props.text = el.textContent;
      el.contentEditable = 'false';
      el.removeEventListener('blur', onBlur);
      this._snapshot('edit text');
    };
    el.addEventListener('blur', onBlur);
  }

  // =========== Object creation ===========
  addText(initial = 'Click to edit') {
    const w = 500, h = 100;
    this._addObject(SlidesObjects.text({
      x: Math.round((this.size.w - w) / 2),
      y: Math.round((this.size.h - h) / 2),
      w, h, text: initial,
    }));
  }
  addShape(kind) {
    const w = 240, h = 140;
    this._addObject(SlidesObjects.shape({
      x: Math.round((this.size.w - w) / 2),
      y: Math.round((this.size.h - h) / 2),
      w, h, shape: kind,
    }));
  }
  addImage() {
    const input = document.createElement('input');
    input.type = 'file'; input.accept = 'image/*';
    input.onchange = () => {
      const f = input.files[0]; if (!f) return;
      const reader = new FileReader();
      reader.onload = () => {
        const img = new Image();
        img.onload = () => {
          const maxW = 500;
          const w = Math.min(maxW, img.width);
          const h = img.height * (w / img.width);
          this._addObject(SlidesObjects.image({
            x: 200, y: 200, w, h, src: reader.result,
          }));
        };
        img.src = reader.result;
      };
      reader.readAsDataURL(f);
    };
    input.click();
  }
  addTable(rows = 3, cols = 3) {
    const data = Array.from({ length: rows }, (_, i) =>
      Array.from({ length: cols }, (_, j) => `${(i * cols + j + 1)}`));
    this._addObject({
      type: 'table', x: 200, y: 200, w: 600, h: 200, rot: 0,
      props: { rows: data },
    });
  }
  addChart(type = 'column') {
    this._addObject({
      type: 'chart', x: 200, y: 150, w: 640, h: 400, rot: 0,
      props: {
        chart: {
          type,
          title: 'Chart Title',
          categories: ['Q1', 'Q2', 'Q3', 'Q4'],
          series: [{ name: 'Series 1', values: [12, 19, 8, 15] }],
        },
      },
    });
  }
  addDiagram(kind = 'process') {
    const nodes = kind === 'hierarchy'
      ? ['CEO', 'Sales', 'Marketing', 'Engineering']
      : kind === 'cycle'
        ? ['Plan', 'Do', 'Check', 'Act']
        : ['Step 1', 'Step 2', 'Step 3'];
    this._addObject({
      type: 'diagram', x: 200, y: 250, w: 700, h: 220, rot: 0,
      props: { diagram: { kind, nodes } },
    });
  }
  _addObject(o) {
    o.id = o.id || ('o' + rand());
    this.slides[this.current].objects.push(o);
    this.selected = [o.id];
    this._snapshot('add ' + o.type);
    this._render();
  }

  // =========== Group / align / distribute ===========
  group() {
    if (this.selected.length < 2) return;
    const slide = this.slides[this.current];
    const group = { id: 'g' + rand(), type: 'group', children: [] };
    slide.objects = slide.objects.filter(o => {
      if (this.selected.includes(o.id)) { group.children.push(o); return false; }
      return true;
    });
    slide.objects.push(group);
    this.selected = [group.id];
    this._snapshot('group');
    this._render();
  }
  ungroup() {
    if (this.selected.length !== 1) return;
    const slide = this.slides[this.current];
    const group = slide.objects.find(o => o.id === this.selected[0] && o.type === 'group');
    if (!group) return;
    slide.objects = slide.objects.filter(o => o !== group).concat(group.children);
    this.selected = group.children.map(c => c.id);
    this._snapshot('ungroup');
    this._render();
  }
  align(edge) {
    if (!this.selected.length) return;
    const objs = this.slides[this.current].objects.filter(o => this.selected.includes(o.id));
    if (!objs.length) return;
    const lefts = objs.map(o => o.x);
    const rights = objs.map(o => o.x + o.w);
    const tops = objs.map(o => o.y);
    const bots = objs.map(o => o.y + o.h);
    const L = Math.min(...lefts), R = Math.max(...rights);
    const T = Math.min(...tops), B = Math.max(...bots);
    const cx = (L + R) / 2, cy = (T + B) / 2;
    for (const o of objs) {
      if (edge === 'left') o.x = L;
      if (edge === 'right') o.x = R - o.w;
      if (edge === 'top') o.y = T;
      if (edge === 'bottom') o.y = B - o.h;
      if (edge === 'centerH') o.x = Math.round(cx - o.w / 2);
      if (edge === 'centerV') o.y = Math.round(cy - o.h / 2);
    }
    this._snapshot('align');
    this._render();
  }
  distribute(axis) {
    if (this.selected.length < 3) return;
    const objs = this.slides[this.current].objects.filter(o => this.selected.includes(o.id));
    objs.sort((a, b) => axis === 'h' ? a.x - b.x : a.y - b.y);
    const first = objs[0], last = objs[objs.length - 1];
    const span = axis === 'h' ? (last.x + last.w) - first.x : (last.y + last.h) - first.y;
    const totalObj = objs.reduce((acc, o) => acc + (axis === 'h' ? o.w : o.h), 0);
    const gap = (span - totalObj) / (objs.length - 1);
    let cursor = axis === 'h' ? first.x : first.y;
    for (const o of objs) {
      if (axis === 'h') { o.x = Math.round(cursor); cursor += o.w + gap; }
      else { o.y = Math.round(cursor); cursor += o.h + gap; }
    }
    this._snapshot('distribute');
    this._render();
  }

  // =========== Slide operations ===========
  newSlide() {
    this.slides.push(emptySlide('title-content'));
    this.current = this.slides.length - 1;
    this.selected = [];
    this._snapshot('new slide');
    this._render();
  }
  duplicateSlide(i = this.current) {
    const copy = JSON.parse(JSON.stringify(this.slides[i]));
    copy.objects.forEach(o => o.id = o.id + '_' + rand());
    this.slides.splice(i + 1, 0, copy);
    this.current = i + 1;
    this._snapshot('duplicate slide');
    this._render();
  }
  deleteSlide(i = this.current) {
    if (this.slides.length <= 1) return;
    this.slides.splice(i, 1);
    this.current = Math.max(0, this.current - 1);
    this._snapshot('delete slide');
    this._render();
  }
  hideSlide(i = this.current) {
    this.slides[i].hidden = !this.slides[i].hidden;
    this._snapshot('hide slide');
    this._render();
  }

  // =========== Sections ===========
  addSection() {
    this.sections.push({ name: `Section ${this.sections.length + 1}`, slides: [this.current] });
    this._snapshot('add section');
    this._render();
  }
  renameSection(idx) {
    prompt2({
      title: 'Rename Section', host: document.getElementById('dialogHost'),
      fields: [{ name: 'name', label: 'Name', value: this.sections[idx].name }],
    }).then(r => { if (r?.name) { this.sections[idx].name = r.name; this._snapshot('rename section'); this._render(); } });
  }

  // =========== Animations ===========
  applyAnimation(kind, start = 'onClick', duration = 0.5) {
    if (!this.selected.length) return;
    for (const o of this.slides[this.current].objects) {
      if (!this.selected.includes(o.id)) continue;
      o.anim = o.anim || [];
      o.anim.push({ type: kind, start, duration, delay: 0 });
    }
    this._snapshot('animation');
    this._openAnimationPane();
  }
  clearAnimations() {
    for (const o of this.slides[this.current].objects) {
      if (!this.selected.includes(o.id)) continue;
      o.anim = [];
    }
    this._snapshot('clear animations');
    this._openAnimationPane();
  }
  _openAnimationPane() {
    const host = document.getElementById('dialogHost');
    const wrap = document.createElement('div');
    const objs = this.slides[this.current].objects;
    wrap.innerHTML = `
      <div style="max-height:300px;overflow:auto;">
        ${objs.map(o => `
          <div style="border-bottom:1px solid var(--border);padding:8px 0;">
            <strong>${o.type} ${o.id.slice(0,6)}</strong>
            <div class="anim-list" data-id="${o.id}">
              ${(o.anim || []).map((a, i) => `<div style="display:flex;gap:8px;align-items:center;">
                <span>${a.type}</span> <small>${a.start}</small>
                <button class="anim-del" data-obj="${o.id}" data-i="${i}">×</button>
              </div>`).join('') || '<small style="color:var(--text-muted);">No animations</small>'}
            </div>
          </div>
        `).join('')}
      </div>`;
    openDialog({ host, title: 'Animation Pane', content: wrap, buttons: [{ label: 'Close' }] });
    setTimeout(() => {
      wrap.querySelectorAll('.anim-del').forEach(b => {
        b.onclick = () => {
          const obj = objs.find(o => o.id === b.dataset.obj);
          obj.anim.splice(Number(b.dataset.i), 1);
          this._snapshot('delete animation');
          this._openAnimationPane();
        };
      });
    }, 0);
  }

  // =========== Transitions ===========
  setTransition(name) {
    this.slides[this.current].transition = { name, duration: 700, onClick: true };
    this._snapshot('transition');
  }

  // =========== Presenter ===========
  present(start = 'beginning') {
    this.presenter.start(start);
  }

  // =========== Ribbon ===========
  _setupRibbon() {
    const ctx = {
      color: '#1f1f1f',
      cmd: (name, val) => this.command(name, val),
    };
    this.ribbon = new Ribbon({ host: this.ribbonHost, config: pptRibbon, context: ctx });
  }

  command(name, val) {
    switch (name) {
      case 'newSlide': this.newSlide(); break;
      case 'duplicateSlide': this.duplicateSlide(); break;
      case 'deleteSlide': this.deleteSlide(); break;
      case 'hideSlide': this.hideSlide(); break;
      case 'addShape': this.addShape(val || 'rect'); break;
      case 'addText': this.addText(); break;
      case 'insertTable': this.addTable(val?.rows || 3, val?.cols || 3); break;
      case 'insertImage': this.addImage(); break;
      case 'insertChart': this.addChart(val || 'column'); break;
      case 'insertDiagram': this.addDiagram(val || 'process'); break;
      case 'theme': this.theme = val; this._applyTheme(); this._snapshot('theme'); break;
      case 'setSize': this._setSize(val); break;
      case 'transition': this.setTransition(val); break;
      case 'anim': this.applyAnimation(val); break;
      case 'present': this.present(val); break;
      case 'view': this._switchView(val); break;
      case 'setLayout': this.setLayout(val); break;
      case 'resetLayout': this._resetLayout(); break;
      case 'slideMaster': this.openMasterView(); break;
      case 'addSection': this.addSection(); break;
      case 'group': this.group(); break;
      case 'ungroup': this.ungroup(); break;
      case 'align': this.align(val); break;
      case 'distribute': this.distribute(val); break;
      case 'bold': this._toggleTextStyle('bold', val); break;
      case 'italic': this._toggleTextStyle('italic', val); break;
      case 'underline': this._toggleTextStyle('underline', val); break;
      case 'color': this._setTextColor(val); break;
      case 'alignText': this._setTextAlign(val); break;
      case 'find': this._findDialog(); break;
      case 'selectAll': this.selected = this.slides[this.current].objects.map(o => o.id); this._render(); break;
      case 'undo': this.history.undo(); this._render(); break;
      case 'redo': this.history.redo(); this._render(); break;
      case 'transitionMorph': this.setTransition('morph'); break;
      case 'rehearse': this._rehearseTimings(); break;
      case 'sorterView': this._switchView('sorter'); break;
      case 'notesView': this._switchView('notes'); break;
      case 'designer': this._showDesigner(); break;
      case 'presenterCoach': this._openPresenterCoach(); break;
      default: console.warn('Unhandled slides command:', name);
    }
    this.autosaver?.schedule();
  }

  _setSize(aspect) {
    if (aspect === '4:3') this.size = { w: 1024, h: 768 };
    else if (aspect === '16:9') this.size = { w: 1280, h: 720 };
    else if (aspect === 'custom') {
      prompt2({
        title: 'Custom Slide Size', host: document.getElementById('dialogHost'),
        fields: [
          { name: 'w', label: 'Width (in)', value: '13.333' },
          { name: 'h', label: 'Height (in)', value: '7.5' },
        ],
      }).then(r => {
        if (!r) return;
        this.size = { w: Number(r.w) * 96, h: Number(r.h) * 96 };
        this.canvasEl.style.aspectRatio = `${this.size.w} / ${this.size.h}`;
        this._render();
      });
      return;
    }
    this.canvasEl.style.aspectRatio = `${this.size.w} / ${this.size.h}`;
    this._render();
  }
  _resetLayout() {
    this.slides[this.current].objects = [];
    this._snapshot('reset layout');
    this._render();
  }
  _toggleTextStyle(key, on) {
    const objs = this.slides[this.current].objects.filter(o => this.selected.includes(o.id));
    for (const o of objs) { o.props = o.props || {}; o.props[key] = on; }
    this._snapshot('style ' + key);
    this._render();
  }
  _setTextColor(color) {
    const objs = this.slides[this.current].objects.filter(o => this.selected.includes(o.id));
    for (const o of objs) { o.props = o.props || {}; o.props.color = color; }
    this._snapshot('color');
    this._render();
  }
  _setTextAlign(align) {
    const objs = this.slides[this.current].objects.filter(o => this.selected.includes(o.id));
    for (const o of objs) { o.props = o.props || {}; o.props.align = align; }
    this._snapshot('align text');
    this._render();
  }
  _switchView(name) {
    document.body.classList.remove('view-sorter', 'view-notes', 'view-normal');
    if (name === 'sorter') document.body.classList.add('view-sorter');
    else if (name === 'notes') document.body.classList.add('view-notes');
    else document.body.classList.add('view-normal');
  }

  // =========== Designer / Presenter Coach ===========
  _showDesigner() {
    const host = document.getElementById('dialogHost');
    const wrap = document.createElement('div');
    const templates = [
      { id: 'title-and-content', label: 'Title & Content', preview: 'Title on top; bullet content below.' },
      { id: 'two-column', label: 'Two Columns', preview: 'Two text columns side by side.' },
      { id: 'big-picture', label: 'Big Picture', preview: 'Large image on right, text on left.' },
      { id: 'quote', label: 'Big Quote', preview: 'Centered quote with attribution.' },
    ];
    wrap.innerHTML = templates.map(t => `
      <div class="designer-card" data-id="${t.id}" style="border:1px solid var(--border);padding:10px;border-radius:6px;margin-bottom:8px;cursor:pointer;">
        <strong>${t.label}</strong><div style="font-size:12px;color:var(--text-muted);">${t.preview}</div>
      </div>`).join('');
    openDialog({ host, title: 'Design Ideas', content: wrap, buttons: [{ label: 'Close' }] });
    setTimeout(() => {
      wrap.querySelectorAll('.designer-card').forEach(card => {
        card.onclick = () => {
          this._applyDesignIdea(card.dataset.id);
        };
      });
    }, 0);
  }
  _applyDesignIdea(id) {
    const slide = this.slides[this.current];
    slide.objects = [];
    const t = this._themeVars;
    if (id === 'title-and-content') {
      slide.objects.push({
        id: 'o' + rand(), type: 'text', x: 80, y: 60, w: this.size.w - 160, h: 100, rot: 0,
        props: { text: 'Title', fontSize: 40, color: t.fg, bold: true },
      });
      slide.objects.push({
        id: 'o' + rand(), type: 'text', x: 80, y: 200, w: this.size.w - 160, h: this.size.h - 300, rot: 0,
        props: { text: '• First point\n• Second point\n• Third point', fontSize: 22, color: t.fg },
      });
    } else if (id === 'two-column') {
      slide.objects.push({
        id: 'o' + rand(), type: 'text', x: 60, y: 60, w: this.size.w - 120, h: 80, rot: 0,
        props: { text: 'Headline', fontSize: 32, color: t.fg, bold: true },
      });
      slide.objects.push({
        id: 'o' + rand(), type: 'text', x: 60, y: 180, w: (this.size.w - 160) / 2, h: 400, rot: 0,
        props: { text: 'Left column body.', fontSize: 18, color: t.fg },
      });
      slide.objects.push({
        id: 'o' + rand(), type: 'text', x: this.size.w / 2 + 20, y: 180, w: (this.size.w - 160) / 2, h: 400, rot: 0,
        props: { text: 'Right column body.', fontSize: 18, color: t.fg },
      });
    } else if (id === 'big-picture') {
      slide.objects.push({
        id: 'o' + rand(), type: 'text', x: 60, y: 260, w: 500, h: 200, rot: 0,
        props: { text: 'Headline\nSubhead', fontSize: 32, color: t.fg, bold: true },
      });
      slide.objects.push({
        id: 'o' + rand(), type: 'shape', x: this.size.w - 620, y: 100, w: 520, h: 520, rot: 0,
        props: { shape: 'rect', fill: t.accent },
      });
    } else if (id === 'quote') {
      slide.objects.push({
        id: 'o' + rand(), type: 'text', x: 120, y: 200, w: this.size.w - 240, h: 260, rot: 0,
        props: { text: '“The best way to predict the future is to invent it.”', fontSize: 36, color: t.fg, italic: true, align: 'center' },
      });
      slide.objects.push({
        id: 'o' + rand(), type: 'text', x: 120, y: 500, w: this.size.w - 240, h: 60, rot: 0,
        props: { text: '— Alan Kay', fontSize: 20, color: t.fg, align: 'center' },
      });
    }
    this._snapshot('design idea');
    this._render();
  }

  _openPresenterCoach() {
    const host = document.getElementById('dialogHost');
    const wrap = document.createElement('div');
    wrap.innerHTML = `
      <label>Transcript:<br>
        <textarea id="_pcText" rows="8" style="width:100%;padding:6px;border:1px solid var(--border);border-radius:4px;"></textarea>
      </label>
      <label style="display:block;margin-top:8px;">Duration (seconds):
        <input id="_pcDur" type="number" value="180" style="width:100px;padding:4px;">
      </label>
      <div id="_pcOut" style="margin-top:12px;"></div>`;
    openDialog({
      host, title: 'Presenter Coach', content: wrap,
      buttons: [
        { label: 'Close' },
        { label: 'Analyze', primary: true, close: false, onClick: async (body) => {
            const transcript = body.querySelector('#_pcText').value;
            const duration = Number(body.querySelector('#_pcDur').value) || 180;
            try {
              const res = await api._fetch('/api/slides/presenter-coach', {
                method: 'POST', body: JSON.stringify({ transcript, durationSec: duration, slideCount: this.slides.length }),
              });
              const data = await res.json();
              body.querySelector('#_pcOut').innerHTML = `
                <div><strong>${data.words}</strong> words · <strong>${data.wordsPerMinute}</strong> wpm · Pace: <strong>${data.paceAssessment}</strong></div>
                <ul>${data.recommendations.map(r => `<li>${r}</li>`).join('')}</ul>
                ${Object.keys(data.fillers).length ? `<div>Fillers: ${Object.entries(data.fillers).map(([k,v]) => `${k}×${v}`).join(', ')}</div>` : ''}
                ${Object.keys(data.repeatedAdjacent).length ? `<div>Repeated words: ${Object.entries(data.repeatedAdjacent).map(([k,v]) => `${k}×${v}`).join(', ')}</div>` : ''}
              `;
            } catch (e) {
              body.querySelector('#_pcOut').textContent = 'Error: ' + e.message;
            }
            return false;
          } },
      ],
    });
  }

  _rehearseTimings() {
    const start = Date.now();
    const timings = [];
    let idx = 0;
    const host = document.getElementById('dialogHost');
    const wrap = document.createElement('div');
    wrap.innerHTML = `
      <div>Rehearse Timings</div>
      <div id="_rtNow" style="font-size:32px;font-weight:600;margin:12px 0;">00:00</div>
      <div style="color:var(--text-muted);font-size:12px;">Slide <span id="_rtSlide">1</span> / ${this.slides.length}</div>
      <div style="margin-top:12px;">Total: <span id="_rtTotal">00:00</span></div>`;
    openDialog({
      host, title: 'Rehearse Timings', content: wrap,
      buttons: [
        { label: 'Stop', onClick: () => {
            timings.push(Date.now() - start);
            this.slides.forEach((s, i) => { s.timing = timings[i] || 0; });
            this._snapshot('rehearse');
          } },
        { label: 'Next Slide', primary: true, close: false, onClick: (body) => {
            timings.push(Date.now() - start);
            if (idx < this.slides.length - 1) {
              idx++;
              body.querySelector('#_rtSlide').textContent = idx + 1;
            }
            return false;
          } },
      ],
    });
    const upd = setInterval(() => {
      const t = Math.floor((Date.now() - start) / 1000);
      const fmt = s => `${String(Math.floor(s/60)).padStart(2,'0')}:${String(s%60).padStart(2,'0')}`;
      const el = document.getElementById('_rtNow');
      if (el) el.textContent = fmt(t);
      const tot = document.getElementById('_rtTotal');
      if (tot) tot.textContent = fmt(t);
    }, 250);
    setTimeout(() => clearInterval(upd), 60 * 60 * 1000);
  }

  _findDialog() {
    const host = document.getElementById('dialogHost');
    prompt2({
      title: 'Find', host,
      fields: [{ name: 'q', label: 'Find text', value: '' }],
    }).then(r => {
      if (!r || !r.q) return;
      const q = r.q.toLowerCase();
      for (let i = 0; i < this.slides.length; i++) {
        for (const o of this.slides[i].objects) {
          if ((o.props?.text || '').toLowerCase().includes(q)) {
            this.current = i; this.selected = [o.id]; this._render(); return;
          }
        }
      }
      alert('Not found');
    });
  }

  // =========== Context menus ===========
  _setupContextMenu() { /* handled inline */ }
  _objectContextMenu(e, obj) {
    e.preventDefault(); e.stopPropagation();
    const host = document.getElementById('contextMenu');
    const multi = this.selected.length > 1;
    showContextMenu(host, e.clientX, e.clientY, [
      { label: 'Cut', action: () => this._cutSelected() },
      { label: 'Copy', action: () => this._copySelected() },
      { label: 'Paste', action: () => this._paste() },
      { label: 'Duplicate', shortcut: 'Ctrl+D', action: () => this._duplicateSelected() },
      { sep: true },
      { label: 'Bring to Front', action: () => this._zorder('front') },
      { label: 'Send to Back', action: () => this._zorder('back') },
      { label: 'Bring Forward', action: () => this._zorder('forward') },
      { label: 'Send Backward', action: () => this._zorder('backward') },
      { sep: true },
      ...(multi ? [
        { label: 'Group', action: () => this.group() },
        { label: 'Align Left', action: () => this.align('left') },
        { label: 'Align Center', action: () => this.align('centerH') },
        { label: 'Align Right', action: () => this.align('right') },
        { label: 'Distribute Horizontally', action: () => this.distribute('h') },
        { label: 'Distribute Vertically', action: () => this.distribute('v') },
      ] : [
        { label: 'Edit Text', action: () => { const el = this.canvasEl.querySelector(`[data-id="${obj.id}"]`); if (el) this._editTextInline(obj, el); } },
        { label: 'Edit Data', action: () => this._editChartData(obj) },
        { label: 'Alt Text…', action: () => this._editAltText(obj) },
        { label: 'Animation…', action: () => this._openAnimationPane() },
      ]),
    ]);
  }
  _thumbContextMenu(e, i) {
    e.preventDefault();
    const host = document.getElementById('contextMenu');
    showContextMenu(host, e.clientX, e.clientY, [
      { label: 'New Slide', action: () => { this.current = i; this.newSlide(); } },
      { label: 'Duplicate Slide', action: () => this.duplicateSlide(i) },
      { label: 'Delete Slide', action: () => this.deleteSlide(i) },
      { label: this.slides[i].hidden ? 'Show Slide' : 'Hide Slide', action: () => this.hideSlide(i) },
      { sep: true },
      { label: 'Add Section', action: () => { this.current = i; this.addSection(); } },
      { label: 'Reset Layout', action: () => { this.current = i; this._resetLayout(); } },
    ]);
  }
  _cutSelected() { this._copySelected(); this._deleteSelected(); }
  _copySelected() {
    this.clipboard = JSON.parse(JSON.stringify(
      this.slides[this.current].objects.filter(o => this.selected.includes(o.id))
    ));
  }
  _paste() {
    if (!this.clipboard?.length) return;
    const slide = this.slides[this.current];
    for (const c of this.clipboard) {
      const copy = JSON.parse(JSON.stringify(c));
      copy.id = 'o' + rand();
      copy.x += 20; copy.y += 20;
      slide.objects.push(copy);
    }
    this.selected = slide.objects.slice(-this.clipboard.length).map(o => o.id);
    this._snapshot('paste');
    this._render();
  }
  _duplicateSelected() {
    const slide = this.slides[this.current];
    const dups = [];
    for (const o of slide.objects.filter(o => this.selected.includes(o.id))) {
      const c = JSON.parse(JSON.stringify(o));
      c.id = 'o' + rand();
      c.x += 20; c.y += 20;
      slide.objects.push(c);
      dups.push(c.id);
    }
    this.selected = dups;
    this._snapshot('duplicate');
    this._render();
  }
  _deleteSelected() {
    if (!this.selected.length) return;
    const slide = this.slides[this.current];
    slide.objects = slide.objects.filter(o => !this.selected.includes(o.id));
    this.selected = [];
    this._snapshot('delete');
    this._render();
  }
  _zorder(dir) {
    const slide = this.slides[this.current];
    for (const id of this.selected) {
      const idx = slide.objects.findIndex(o => o.id === id);
      if (idx < 0) continue;
      const [o] = slide.objects.splice(idx, 1);
      if (dir === 'front') slide.objects.push(o);
      else if (dir === 'back') slide.objects.unshift(o);
      else if (dir === 'forward') slide.objects.splice(Math.min(idx + 1, slide.objects.length), 0, o);
      else if (dir === 'backward') slide.objects.splice(Math.max(idx - 1, 0), 0, o);
    }
    this._snapshot('zorder');
    this._render();
  }
  _editAltText(obj) {
    prompt2({
      title: 'Alt Text', host: document.getElementById('dialogHost'),
      fields: [{ name: 'alt', label: 'Alt text', value: obj.props?.altText || '' }],
    }).then(r => {
      if (!r) return;
      obj.props = obj.props || {};
      obj.props.altText = r.alt;
      this._snapshot('alt text');
    });
  }
  async _editChartData(obj) {
    const spec = obj.props.chart || {};
    const host = document.getElementById('dialogHost');
    const wrap = document.createElement('div');
    const categories = [...(spec.categories || [])];
    const series = (spec.series || []).map(s => ({ ...s }));
    wrap.innerHTML = `<div id="_ceGrid"></div>`;
    const renderGrid = () => {
      const g = wrap.querySelector('#_ceGrid');
      g.innerHTML = `
        <table style="width:100%;border-collapse:collapse;">
          <tr><th style="border:1px solid var(--border);padding:4px;"></th>
            ${categories.map((c,i) => `<th style="border:1px solid var(--border);padding:4px;"><input data-cat="${i}" value="${escapeHtml(c)}" style="width:60px;"></th>`).join('')}
          </tr>
          ${series.map((s, si) => `
            <tr>
              <td style="border:1px solid var(--border);padding:4px;"><input data-name="${si}" value="${escapeHtml(s.name)}" style="width:80px;"></td>
              ${s.values.map((v, vi) => `<td style="border:1px solid var(--border);padding:4px;"><input type="number" data-si="${si}" data-vi="${vi}" value="${v}" style="width:60px;"></td>`).join('')}
            </tr>`).join('')}
        </table>
        <button id="_ceAddRow" style="margin-top:8px;">+ Row</button>
        <button id="_ceAddCol">+ Column</button>`;
      g.querySelectorAll('[data-cat]').forEach(inp => inp.oninput = () => categories[Number(inp.dataset.cat)] = inp.value);
      g.querySelectorAll('[data-name]').forEach(inp => inp.oninput = () => series[Number(inp.dataset.name)].name = inp.value);
      g.querySelectorAll('[data-si]').forEach(inp => inp.oninput = () => series[Number(inp.dataset.si)].values[Number(inp.dataset.vi)] = Number(inp.value));
      g.querySelector('#_ceAddRow').onclick = () => { series.push({ name: `Series ${series.length+1}`, values: categories.map(() => 0) }); renderGrid(); };
      g.querySelector('#_ceAddCol').onclick = () => { categories.push('New'); series.forEach(s => s.values.push(0)); renderGrid(); };
    };
    renderGrid();
    openDialog({
      host, title: 'Edit Data', content: wrap,
      buttons: [
        { label: 'Cancel' },
        { label: 'Apply', primary: true, onClick: () => {
            obj.props.chart = { type: spec.type, title: spec.title, categories, series };
            this._snapshot('edit chart data');
            this._render();
          } },
      ],
    });
  }

  // =========== Drag-and-drop file open ===========
  _setupCanvasDragDrop() {
    document.addEventListener('dragover', (e) => { e.preventDefault(); });
    document.addEventListener('drop', async (e) => {
      e.preventDefault();
      const f = e.dataTransfer.files[0];
      if (!f) return;
      const ext = f.name.toLowerCase().split('.').pop();
      if (ext === 'png' || ext === 'jpg' || ext === 'jpeg' || ext === 'gif' || ext === 'webp') {
        const reader = new FileReader();
        reader.onload = () => {
          const img = new Image();
          img.onload = () => {
            const w = Math.min(600, img.width);
            const h = img.height * (w / img.width);
            this._addObject({ id: 'o' + rand(), type: 'image', x: 200, y: 200, w, h, rot: 0, props: { src: reader.result } });
          };
          img.src = reader.result;
        };
        reader.readAsDataURL(f);
      } else if (ext === 'pptx') {
        try {
          const { model } = await api.importFile('slides', f);
          this.slides = model.slides;
          if (model.size) this.size = { w: model.size.w * 96, h: model.size.h * 96 };
          this.current = 0;
          this._render();
        } catch (err) { alert('Import failed: ' + err.message); }
      }
    });
  }

  // =========== Global keys ===========
  _onGlobalKey(e) {
    // Delete key
    if (e.key === 'Delete' && this.selected.length && document.activeElement === document.body) {
      this._deleteSelected();
      e.preventDefault();
    }
    // Escape clears selection
    if (e.key === 'Escape') { this.selected = []; this._render(); }
  }

  // =========== Autosave / persistence ===========
  _setupAutosave() {
    this.autosaver = new AutoSaver({
      getId: () => this.docId,
      getModel: () => this._serialize(),
      save: async (id, model) => { if (id) await api.updateDoc(id, this.titleEl.value, model); },
    });
    this.autosaver.onStatus(s => {
      const el = document.getElementById('saveStatus'); if (el) el.textContent = s;
    });
  }
  async saveNow() {
    const model = this._serialize();
    if (!this.docId) {
      try {
        const c = await api.createDoc('slides', this.titleEl.value, model);
        this.docId = c.id; history.replaceState(null, '', `?id=${this.docId}`);
      } catch (e) { console.warn(e); }
    } else {
      try { await api.updateDoc(this.docId, this.titleEl.value, model); } catch {}
    }
    await storage.put(this.docId || 'draft-slides', model);
  }
  _serialize() {
    return {
      meta: { title: this.titleEl.value },
      size: { w: this.size.w / 96, h: this.size.h / 96 },
      theme: this.theme,
      master: this.master,
      sections: this.sections,
      slides: this.slides,
      schemaVersion: 3,
    };
  }
  async _loadDoc() {
    try {
      const d = await api.getDoc(this.docId);
      this.titleEl.value = d.name || 'Untitled';
      if (d.data) {
        if (d.data.size) this.size = { w: d.data.size.w * 96, h: d.data.size.h * 96 };
        if (d.data.theme) this.theme = d.data.theme;
        if (d.data.master) this.master = d.data.master;
        if (d.data.sections) this.sections = d.data.sections;
        if (d.data.slides) this.slides = d.data.slides;
      }
    } catch {
      const j = await storage.get(this.docId);
      if (j?.data) {
        if (j.data.slides) this.slides = j.data.slides;
        if (j.data.size) this.size = { w: j.data.size.w * 96, h: j.data.size.h * 96 };
        if (j.data.theme) this.theme = j.data.theme;
      }
    }
  }

  // =========== Snapshot / undo ===========
  _snapshot(label) {
    const before = JSON.stringify(this.slides);
    const beforeSections = JSON.stringify(this.sections);
    setTimeout(() => {
      const after = JSON.stringify(this.slides);
      const afterSections = JSON.stringify(this.sections);
      if (before === after && beforeSections === afterSections) return;
      const self = this;
      this.history.push({
        label,
        do: () => { self.slides = JSON.parse(after); self.sections = JSON.parse(afterSections); self._render(); },
        undo: () => { self.slides = JSON.parse(before); self.sections = JSON.parse(beforeSections); self._render(); },
      });
      this.autosaver?.schedule();
    }, 0);
  }

  // =========== Shortcuts ===========
  _setupShortcuts() {
    const sc = new Shortcuts({
      'ctrl+s': (e) => { e.preventDefault(); this.saveNow(); },
      'ctrl+z': (e) => { e.preventDefault(); this.history.undo(); this._render(); },
      'ctrl+y': (e) => { e.preventDefault(); this.history.redo(); this._render(); },
      'ctrl+d': (e) => { e.preventDefault(); this._duplicateSelected(); },
      'ctrl+g': (e) => { e.preventDefault(); this.group(); },
      'ctrl+shift+g': (e) => { e.preventDefault(); this.ungroup(); },
      'delete': () => this._deleteSelected(),
      'f5': () => this.present('beginning'),
      'shift+f5': () => this.present('current'),
      'ctrl+m': (e) => { e.preventDefault(); this.newSlide(); },
      'ctrl+n': (e) => { e.preventDefault(); this.newSlide(); },
    });
    sc.bind();
  }

  // =========== Backstage / Tell Me ===========
  _setupBackstage() {
    const host = document.getElementById('backstage');
    this.backstage = new Backstage({
      host,
      title: () => this.titleEl.value,
      onSave: () => this.saveNow(),
      onExport: async (fmt) => {
        const blob = await api.exportDoc('slides', fmt, this._serialize(), this.titleEl.value || 'presentation');
        await api.downloadBlob(blob, `${this.titleEl.value || 'presentation'}.${fmt}`);
      },
    });
    window.addEventListener('ribbon:backstage', () => this.backstage.open('home'));
    document.getElementById('exportBtn')?.addEventListener('click', () => this.backstage.open('export'));
  }
  _setupTellMe() {
    new TellMe({
      ribbonConfig: pptRibbon,
      host: document.getElementById('tellMeResults') || document.body,
      onRun: (cmd) => this.command(cmd.id, cmd.value),
    });
  }

  // =========== Status bar ===========
  _updateStatus() {
    const el = document.getElementById('slideInfo');
    if (el) el.textContent = `Slide ${this.current + 1} of ${this.slides.length}`;
  }
}

// =========== helpers ===========
function rand() { return Math.random().toString(36).slice(2, 8); }
function escapeHtml(s) { return String(s ?? '').replace(/[&<>"']/g, c => ({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' }[c])); }
function mapChartType(t) { return { column: 'bar', bar: 'bar', line: 'line', pie: 'pie', scatter: 'scatter', area: 'line', doughnut: 'doughnut' }[t] || 'bar'; }
function themeChartColor(i) {
  const palette = ['#2b579a', '#217346', '#d24726', '#f2c94c', '#6f42c1', '#17a2b8'];
  return palette[i % palette.length];
}
function emptySlide(layout = 'blank') {
  return { layout, background: null, objects: [], notes: '', transition: null, hidden: false };
}
function defaultLayouts() {
  return [
    { name: 'title',        placeholders: [{ type: 'title', x: 80, y: 240, w: 1120, h: 100, defaultText: 'Click to add title', fontSize: 44 },
                                           { type: 'subtitle', x: 80, y: 360, w: 1120, h: 60, defaultText: 'Subtitle', fontSize: 24 }] },
    { name: 'title-content', placeholders: [{ type: 'title', x: 80, y: 60, w: 1120, h: 100, defaultText: 'Title', fontSize: 40 },
                                             { type: 'body',  x: 80, y: 200, w: 1120, h: 460, defaultText: '• First point\n• Second point', fontSize: 22 }] },
    { name: 'two-content',  placeholders: [{ type: 'title', x: 80, y: 60, w: 1120, h: 100, defaultText: 'Title', fontSize: 40 },
                                            { type: 'body',  x: 80, y: 200, w: 540, h: 460, defaultText: 'Left', fontSize: 22 },
                                            { type: 'body',  x: 660, y: 200, w: 540, h: 460, defaultText: 'Right', fontSize: 22 }] },
    { name: 'section-header', placeholders: [{ type: 'title', x: 80, y: 300, w: 1120, h: 100, defaultText: 'Section Title', fontSize: 44 }] },
    { name: 'blank',        placeholders: [] },
  ];
}

// =========== Also expose SlidesThemes / SlidesAnimations for reuse ===========