/**
 * Presenter engine: fullscreen + presenter view with notes, timer, next-slide
 * preview, laser pointer, pen/highlighter, black screen, and annotation.
 */
export class SlidesPresenter {
  constructor(app) {
    this.app = app;
    this.current = 0;
    this.black = false;
    this.tool = null;       // 'laser' | 'pen' | 'highlighter' | 'eraser'
    this.annotations = {};  // slideIndex -> [ {x,y,color,width} ]
    this.startTime = 0;
    this.timerHandle = null;
  }

  start(mode = 'beginning') {
    this.current = mode === 'current' ? this.app.current : 0;
    this._openFullscreen();
  }

  _openFullscreen() {
    const overlay = document.createElement('div');
    overlay.className = 'presenter-overlay';
    overlay.innerHTML = `
      <div class="presenter-slide" id="_pSlide"></div>
      <div class="presenter-view hidden" id="_pView">
        <div class="pv-main">
          <div class="pv-current" id="_pvCurrent"></div>
          <div class="pv-controls">
            <button data-tool="laser" title="Laser pointer">🔴</button>
            <button data-tool="pen" title="Pen">✏️</button>
            <button data-tool="highlighter" title="Highlighter">🖍</button>
            <button data-tool="eraser" title="Eraser">🧽</button>
            <button id="_pvBlack">◼ Black</button>
            <button id="_pvEnd">End Show</button>
          </div>
        </div>
        <div class="pv-side">
          <div class="pv-next" id="_pvNext"></div>
          <div class="pv-notes" id="_pvNotes"></div>
          <div class="pv-timer" id="_pvTimer">00:00</div>
        </div>
      </div>
      <div class="presenter-tools" id="_pTools">
        <button id="_pPrev">◀ Prev</button>
        <button id="_pNext">Next ▶</button>
        <button id="_pPresenterToggle">Presenter view</button>
        <button id="_pAnnotate">Annotate</button>
        <button id="_pBlack">Black</button>
        <button id="_pExit">Exit (Esc)</button>
      </div>`;
    document.body.appendChild(overlay);
    this.overlay = overlay;
    this._renderSlide();
    this._bind(overlay);
    this.startTime = Date.now();
    this._startTimer();
  }

  _renderSlide() {
    const slide = this.app.slides[this.current];
    const host = document.getElementById('_pSlide');
    host.style.background = this.app._themeVars?.bg || '#fff';
    host.innerHTML = '';
    this._renderObjectsTo(host, slide);

    const pvCurrent = document.getElementById('_pvCurrent');
    if (pvCurrent) { pvCurrent.innerHTML = ''; this._renderObjectsTo(pvCurrent, slide); pvCurrent.style.background = this.app._themeVars?.bg || '#fff'; }

    const pvNext = document.getElementById('_pvNext');
    if (pvNext) {
      pvNext.innerHTML = '';
      const nextSlide = this.app.slides[this.current + 1];
      if (nextSlide) this._renderObjectsTo(pvNext, nextSlide);
      else pvNext.innerHTML = '<div style="color:#aaa;padding:12px;">End of presentation</div>';
      pvNext.style.background = this.app._themeVars?.bg || '#fff';
    }

    const notes = document.getElementById('_pvNotes');
    if (notes) notes.textContent = slide.notes || '(no notes)';

    // Annotation layer
    this._renderAnnotations();
  }

  _renderObjectsTo(host, slide) {
    for (const o of slide.objects) {
      const el = document.createElement('div');
      Object.assign(el.style, {
        position: 'absolute',
        left: (o.x / this.app.size.w * 100) + '%',
        top: (o.y / this.app.size.h * 100) + '%',
        width: (o.w / this.app.size.w * 100) + '%',
        height: (o.h / this.app.size.h * 100) + '%',
        transform: o.rot ? `rotate(${o.rot}deg)` : '',
      });
      if (o.type === 'text') {
        el.textContent = o.props?.text || '';
        el.style.color = o.props?.color || '#1f1f1f';
        el.style.fontSize = (o.props?.fontSize || 24) + 'px';
        if (o.props?.bold) el.style.fontWeight = '600';
        if (o.props?.italic) el.style.fontStyle = 'italic';
      } else if (o.type === 'shape') {
        el.style.background = o.props?.fill || '#dfe9f7';
      } else if (o.type === 'image') {
        const img = document.createElement('img');
        img.src = o.props.src;
        img.style.cssText = 'width:100%;height:100%;object-fit:contain;';
        el.appendChild(img);
      } else if (o.type === 'table') {
        const tbl = document.createElement('table');
        tbl.style.cssText = 'width:100%;height:100%;border-collapse:collapse;font-size:12px;';
        for (const row of o.props?.rows || []) {
          const tr = document.createElement('tr');
          for (const cell of row) {
            const td = document.createElement('td');
            td.textContent = cell;
            td.style.cssText = 'border:1px solid #bbb;padding:2px 4px;';
            tr.appendChild(td);
          }
          tbl.appendChild(tr);
        }
        el.appendChild(tbl);
      } else if (o.type === 'chart') {
        el.innerHTML = `<div style="width:100%;height:100%;background:#eef3fa;border:1px solid #c7d7ee;display:flex;align-items:center;justify-content:center;font-size:12px;">Chart: ${o.props?.chart?.type || 'column'}</div>`;
      } else if (o.type === 'diagram') {
        const d = o.props?.diagram;
        el.innerHTML = (d?.nodes || []).join(' → ');
      }
      host.appendChild(el);
    }
  }

  _renderAnnotations() {
    // Draw annotations overlay for this slide
    let layer = document.getElementById('_pAnnotLayer');
    if (!layer) {
      layer = document.createElement('div');
      layer.id = '_pAnnotLayer';
      layer.style.cssText = 'position:absolute;inset:0;pointer-events:none;';
      const slideHost = document.getElementById('_pSlide');
      if (slideHost) slideHost.appendChild(layer);
    }
    layer.innerHTML = '';
    const strokes = this.annotations[this.current] || [];
    for (const s of strokes) {
      const dot = document.createElement('div');
      dot.style.cssText = `position:absolute;left:${s.x}px;top:${s.y}px;width:${s.width}px;height:${s.width}px;border-radius:50%;background:${s.color};transform:translate(-50%,-50%);`;
      layer.appendChild(dot);
    }
  }

  _bind(overlay) {
    document.getElementById('_pPrev').onclick = () => this.prev();
    document.getElementById('_pNext').onclick = () => this.next();
    document.getElementById('_pExit').onclick = () => this.stop();
    document.getElementById('_pBlack').onclick = () => this.toggleBlack();
    document.getElementById('_pPresenterToggle').onclick = () => document.getElementById('_pView')?.classList.toggle('hidden');
    document.getElementById('_pAnnotate').onclick = () => this._cycleTool();

    overlay.querySelectorAll('[data-tool]').forEach(b => {
      b.onclick = () => { this.tool = b.dataset.tool; };
    });
    document.getElementById('_pvBlack').onclick = () => this.toggleBlack();
    document.getElementById('_pvEnd').onclick = () => this.stop();

    // Laser/pen drawing
    const slideHost = document.getElementById('_pSlide');
    slideHost.style.pointerEvents = 'auto';
    slideHost.style.cursor = 'crosshair';

    let drawing = false;
    slideHost.addEventListener('mousedown', (e) => {
      if (!this.tool) return;
      drawing = true;
      this._addAnnotationPoint(e);
    });
    slideHost.addEventListener('mousemove', (e) => {
      if (!drawing) return;
      this._addAnnotationPoint(e);
    });
    slideHost.addEventListener('mouseup', () => { drawing = false; });

    // Keyboard nav
    this._keyHandler = (e) => {
      if (e.key === 'Escape') this.stop();
      else if (e.key === 'ArrowRight' || e.key === ' ') this.next();
      else if (e.key === 'ArrowLeft') this.prev();
      else if (e.key.toLowerCase() === 'b') this.toggleBlack();
      else if (e.key.toLowerCase() === 'l') this.tool = 'laser';
      else if (e.key.toLowerCase() === 'p') this.tool = 'pen';
      else if (e.key.toLowerCase() === 'e') this.tool = 'eraser';
    };
    document.addEventListener('keydown', this._keyHandler);
  }

  _cycleTool() {
    const seq = [null, 'laser', 'pen', 'highlighter', 'eraser'];
    const idx = seq.indexOf(this.tool);
    this.tool = seq[(idx + 1) % seq.length];
    alert(`Tool: ${this.tool || 'off'}`);
  }

  _addAnnotationPoint(e) {
    const host = document.getElementById('_pSlide');
    const rect = host.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    const color = this.tool === 'laser' ? '#ff3b30' : this.tool === 'pen' ? '#1f1f1f' : this.tool === 'highlighter' ? 'rgba(255,235,59,.5)' : '#ffffff';
    const width = this.tool === 'laser' ? 8 : this.tool === 'highlighter' ? 24 : 3;
    if (this.tool === 'eraser') {
      this.annotations[this.current] = [];
    } else {
      this.annotations[this.current] = this.annotations[this.current] || [];
      this.annotations[this.current].push({ x, y, color, width });
    }
    this._renderAnnotations();
  }

  next() {
    if (this.current < this.app.slides.length - 1) {
      this.current++;
      this._renderSlide();
    }
  }
  prev() {
    if (this.current > 0) {
      this.current--;
      this._renderSlide();
    }
  }
  toggleBlack() {
    this.black = !this.black;
    const slide = document.getElementById('_pSlide');
    if (slide) slide.style.visibility = this.black ? 'hidden' : 'visible';
  }
  stop() {
    clearInterval(this.timerHandle);
    document.removeEventListener('keydown', this._keyHandler);
    this.overlay.remove();
  }
  _startTimer() {
    this.timerHandle = setInterval(() => {
      const elapsed = Math.floor((Date.now() - this.startTime) / 1000);
      const m = String(Math.floor(elapsed / 60)).padStart(2, '0');
      const s = String(elapsed % 60).padStart(2, '0');
      const el = document.getElementById('_pvTimer');
      if (el) el.textContent = `${m}:${s}`;
    }, 500);
  }
}