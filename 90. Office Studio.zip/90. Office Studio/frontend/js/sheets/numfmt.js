/**
 * Excel number-format engine.
 * Supports up to 4 sections positive;negative;zero;text, conditions, colors,
 * digit placeholders, thousands separators, percent, scientific, fractions,
 * literals, dates, times, and the `@` text token.
 */
const SECTIONS_RE = /("[^"]*"|[^;])+/g;

export function numberFormat(value, code = 'General') {
  if (value == null || value === '') return '';
  if (!code || code === 'General') return general(value);

  const sections = splitSections(code);
  if (typeof value === 'string' && !isNumericString(value)) {
    const sec = sections[3] ?? '@';
    return applyTextSection(value, sec);
  }

  const n = typeof value === 'number' ? value : Number(value);
  if (isNaN(n)) return String(value);

  let sec;
  if (n > 0)      sec = sections[0];
  else if (n < 0) sec = sections[1] ?? sections[0];
  else            sec = sections[2] ?? sections[0];

  sec = stripColorAndCondition(sec, n);
  return applySection(n, sec);
}

export function parseFormat(code) {
  const sections = splitSections(code);
  return {
    positive: sections[0],
    negative: sections[1],
    zero: sections[2],
    text: sections[3],
  };
}

// ---------- internals ----------
function general(v) {
  if (typeof v === 'string') return v;
  const n = Number(v);
  if (Number.isInteger(n)) return String(n);
  return parseFloat(n.toPrecision(15)).toString();
}
function isNumericString(s) { return s !== '' && !isNaN(Number(s)); }

function splitSections(code) {
  const out = []; let cur = '', inQ = false;
  for (const ch of code) {
    if (ch === '"') { inQ = !inQ; cur += ch; }
    else if (ch === '\\') { cur += ch; /* keep escape next char */ }
    else if (ch === ';' && !inQ) { out.push(cur); cur = ''; }
    else cur += ch;
  }
  out.push(cur);
  return out;
}

function stripColorAndCondition(sec, n) {
  // [Red], [>100]
  sec = sec.replace(/\[[^\]]*\]/g, (m) => {
    const inner = m.slice(1, -1);
    if (/^(Red|Blue|Green|Yellow|Magenta|Cyan|White|Black|Color\d+)$/i.test(inner)) return '';
    if (/^[<>=!]/i.test(inner)) return ''; // condition — applied by caller
    return m;
  });
  return sec;
}

function applyTextSection(text, sec) {
  return sec.includes('@') ? sec.replace(/@/g, text) : text;
}

function applySection(num, sec) {
  if (!sec) return general(num);

  // Is this a date/time format?
  const isDate = /[ymdhs]/i.test(sec.replace(/"[^"]*"/g, '')) && !/[#0]/.test(sec.replace(/[ymdhs]/gi, ''));
  if (isDate) return formatDate(num, sec);

  const percent = /%/.test(sec);
  if (percent) num *= 100;
  const sci = /e[+-]/i.test(sec);
  if (sci) return num.toExponential(2);

  const fraction = sec.match(/(#|\?|\d+)\s*\/\s*(#|\?|\d+)/);
  if (fraction) return formatFraction(num, fraction);

  // Determine decimals from the placeholder part before any literal text
  const numericPart = extractNumericPlaceholder(sec);
  const decimals = (numericPart.split('.')[1] || '').replace(/[^0#?]/g, '').length;
  const thousand = /[#0],[#0]/.test(numericPart);

  let out = Math.abs(num).toFixed(decimals);
  if (thousand) out = out.replace(/\B(?=(\d{3})+(?!\d))/g, ',');
  // Strip leading zeros for '#' placeholders? (kept simple)
  const prefix = extractPrefix(sec, numericPart);
  const suffix = extractSuffix(sec, numericPart);
  if (num < 0 && !/^-/.test(prefix)) prefix = '-' + prefix;

  return prefix + out + suffix;
}

function extractNumericPlaceholder(sec) {
  // Strip literals, colors, escapes
  let s = sec.replace(/"[^"]*"/g, '');
  s = s.replace(/\[[^\]]*\]/g, '');
  const m = s.match(/[#0?][#0?,.]*/);
  return m ? m[0] : '0';
}
function extractPrefix(sec, numeric) {
  const idx = sec.indexOf(numeric);
  if (idx < 0) return '';
  return sec.slice(0, idx).replace(/"[^"]*"/g, m => m.slice(1, -1)).replace(/\\(.)/g, '$1');
}
function extractSuffix(sec, numeric) {
  const idx = sec.indexOf(numeric);
  if (idx < 0) return '';
  let s = sec.slice(idx + numeric.length);
  s = s.replace(/"[^"]*"/g, m => m.slice(1, -1)).replace(/\\(.)/g, '$1');
  if (/%/.test(s)) return s;   // percent sign already accounted for
  return s;
}

function formatFraction(num, m) {
  const denom = m[2];
  if (denom === '?') return approximateFraction(num);
  const d = parseInt(denom, 10);
  const whole = Math.trunc(num);
  const rem = Math.abs(num - whole);
  const n = Math.round(rem * d);
  return whole === 0 ? `${n}/${d}` : `${whole} ${n}/${d}`;
}
function approximateFraction(x) {
  const eps = 1e-6; let h1 = 1, h2 = 0, k1 = 0, k2 = 1, b = x;
  do {
    const a = Math.floor(b);
    [h1, h2] = [a * h1 + h2, h1];
    [k1, k2] = [a * k1 + k2, k1];
    b = 1 / (b - a);
  } while (Math.abs(x - h1 / k1) > x * eps && k1 < 1e6);
  return `${h1}/${k1}`;
}

// ---------- date/time ----------
function formatDate(serial, code) {
  const EXCEL_EPOCH = Date.UTC(1899, 11, 30);
  const ms = EXCEL_EPOCH + serial * 86400000;
  const d = new Date(ms);
  const lower = code.toLowerCase();

  const monthsLong  = ['January','February','March','April','May','June','July','August','September','October','November','December'];
  const monthsShort = monthsLong.map(m => m.slice(0, 3));
  const daysLong  = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
  const daysShort = daysLong.map(x => x.slice(0, 3));

  let out = '';
  let i = 0;
  while (i < code.length) {
    const ch = code[i];
    if (ch === '"') { let j = i + 1; while (j < code.length && code[j] !== '"') out += code[j++]; i = j + 1; continue; }
    if (ch === '\\') { out += code[i+1] || ''; i += 2; continue; }
    const rest = code.slice(i).toLowerCase();
    if (rest.startsWith('yyyy')) { out += d.getUTCFullYear(); i += 4; continue; }
    if (rest.startsWith('yy'))   { out += String(d.getUTCFullYear()).slice(-2); i += 2; continue; }
    if (rest.startsWith('mmmmm')){ out += monthsLong[d.getUTCMonth()][0]; i += 5; continue; }
    if (rest.startsWith('mmmm')) { out += monthsLong[d.getUTCMonth()]; i += 4; continue; }
    if (rest.startsWith('mmm'))  { out += monthsShort[d.getUTCMonth()]; i += 3; continue; }
    if (rest.startsWith('mm'))   {
      // mm is minutes when surrounded by h/s
      const prev = code[i-1] || '';
      const next = code[i+2] || '';
      const minutes = /[hH]/.test(prev) || /[sS]/.test(next);
      out += minutes ? String(d.getUTCMinutes()).padStart(2, '0') : String(d.getUTCMonth() + 1).padStart(2, '0');
      i += 2; continue;
    }
    if (rest.startsWith('m')) {
      const prev = code[i-1] || '';
      const next = code[i+1] || '';
      const minutes = /[hH]/.test(prev) || /[sS]/.test(next);
      out += minutes ? String(d.getUTCMinutes()) : String(d.getUTCMonth() + 1);
      i += 1; continue;
    }
    if (rest.startsWith('dddd')) { out += daysLong[d.getUTCDay()]; i += 4; continue; }
    if (rest.startsWith('ddd'))  { out += daysShort[d.getUTCDay()]; i += 3; continue; }
    if (rest.startsWith('dd'))   { out += String(d.getUTCDate()).padStart(2, '0'); i += 2; continue; }
    if (rest.startsWith('d'))    { out += String(d.getUTCDate()); i += 1; continue; }
    if (rest.startsWith('hh'))   { out += String(d.getUTCHours()).padStart(2, '0'); i += 2; continue; }
    if (rest.startsWith('h'))    { out += String(d.getUTCHours()); i += 1; continue; }
    if (rest.startsWith('ss'))   { out += String(d.getUTCSeconds()).padStart(2, '0'); i += 2; continue; }
    if (rest.startsWith('s'))    { out += String(d.getUTCSeconds()); i += 1; continue; }
    if (rest.startsWith('am/pm') || rest.startsWith('a/p')) {
      const isPM = d.getUTCHours() >= 12;
      out += rest.startsWith('a/p') ? (isPM ? 'P' : 'A') : (isPM ? 'PM' : 'AM');
      i += rest.startsWith('a/p') ? 3 : 5; continue;
    }
    out += ch; i++;
  }
  return out;
}