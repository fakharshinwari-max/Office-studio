/** Selection helper utilities for Sheets (kept minimal — most logic in grid.js). */
export const SheetsSelection = {
  bounds(sel) {
    return {
      r0: Math.min(sel.start.r, sel.end.r), r1: Math.max(sel.start.r, sel.end.r),
      c0: Math.min(sel.start.c, sel.end.c), c1: Math.max(sel.start.c, sel.end.c),
    };
  },
};