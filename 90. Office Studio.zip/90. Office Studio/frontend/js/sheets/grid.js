/**
 * Sheets app — Phase 4 complete.
 */
import { api } from '../core/api.js';
import { History } from '../core/history.js';
import { AutoSaver, storage } from '../core/storage.js';
import { Ribbon } from '../core/ribbon.js';
import { excelRibbon } from '../core/ribbon-config-excel.js';
import { Shortcuts } from '../core/shortcuts.js';
import { Backstage } from '../core/backstage.js';
import { TellMe } from '../core/tellme.js';
import { showContextMenu, hideContextMenu } from '../core/context-menu.js';
import { openDialog, prompt2 } from '../core/dialogs.js';
import { FormulaEngine, ERR } from './formula-engine.js';
import { numberFormat } from './numfmt.js';
import { PivotEngine } from './pivot-engine.js';
import { WhatIf } from './what-if.js';

const ROW_H = 22;
const COL_W = 96;
const HEADER_W = 44;
const HEADER_H = 22;
const AUTOSCROLL_EDGE = 24;

export class SheetsApp {
  constructor({ canvas, ribbonHost, titleEl }) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d', { alpha: false });
    this.ribbonHost = ribbonHost;
    this.titleEl = titleEl;
    this.history = new History();
    this.docId = new URLSearchParams(location.search).get('id');
    this.scrollX = 0;
    this.scrollY = 0;
    this.dpr = window.devicePixelRatio || 1;

    this.sheets = [{
      name: 'Sheet1', cells: {}, colWidths: {}, rowHeights: {}, merges: [],
      frozen: {}, cf: [], validations: [], charts: [], hyperlinks: {}, comments: {},
      namedRanges: [], tables: [],
    }];
    this.activeSheet = 0;
    this.selection = { start: { r: 0, c: 0 }, end: { r: 0, c: 0 }, anchor: { r: 0, c: 0 } };
    this.editor = document.getElementById('cellEditor');
    this.formulaInput = document.getElementById('formulaInput');
    this.nameBox = document.getElementById('nameBox');

    this.showFormulas = false;
    this.gridlinesVisible = true;
    this.filterOn = false;
    this.filterValues = {};
    this.charts = [];
    this._scenarios = [];

    this.engine = new FormulaEngine(this._getCells(), this.sheets);
    this.engine.setNamedRanges(this._getNamedRanges());
    this.engine.setTables(this._getTables());
  }

  async init() {
    this._resize();
    this._setupRibbon();
    this._setupSheetTabs();
    this._setupStatusbar();
    this._setupShortcuts();
    this._setupContextMenu();
    this._setupAutosave();
    this._setupBackstage();
    this._setupTellMe();
    this._bindEvents();
    this._setupFormulaAutocomplete();
    if (this.docId) await this._loadDoc();
    this._draw();
    this._updateSelectionStats();
    this._updateFormulaBar();
    this._updateSheetTabs();
  }

  _getCells() { return this.sheets[this.activeSheet].cells; }
  _getSheets() { return this.sheets; }
  _getNamedRanges() {
    const out = {};
    for (const s of this.sheets) for (const nr of (s.namedRanges || [])) out[nr.name] = nr.refersTo;
    return out;
  }
  _getTables() {
    const out = {};
    for (const s of this.sheets) for (const t of (s.tables || [])) out[t.name] = t;
    return out;
  }

  _resize() {
    const parent = this.canvas.parentElement;
    const w = parent.clientWidth, h = parent.clientHeight;
    this.canvas.width = w * this.dpr;
    this.canvas.height = h * this.dpr;
    this.canvas.style.width = w + 'px';
    this.canvas.style.height = h + 'px';
    this.ctx.setTransform(this.dpr, 0, 0, this.dpr, 0, 0);
    this.viewW = w; this.viewH = h;
  }

  _draw() {
    const ctx = this.ctx;
    const surface = css('--surface') || '#fff';
    const surface3 = css('--surface-3') || '#efefef';
    const border = css('--border') || '#e1e1e1';
    const textColor = css('--text') || '#1f1f1f';

    ctx.fillStyle = surface;
    ctx.fillRect(0, 0, this.viewW, this.viewH);

    const sheet = this.sheets[this.activeSheet];
    const cells = sheet.cells;

    ctx.fillStyle = surface3;
    ctx.fillRect(0, 0, this.viewW, HEADER_H);
    ctx.fillRect(0, 0, HEADER_W, this.viewH);

    ctx.strokeStyle = border;
    ctx.lineWidth = 1;

    const firstCol = Math.max(0, Math.floor(this.scrollX / COL_W));
    const lastCol = firstCol + Math.ceil((this.viewW - HEADER_W) / COL_W) + 1;
    const firstRow = Math.max(0, Math.floor(this.scrollY / ROW_H));
    const lastRow = firstRow + Math.ceil((this.viewH - HEADER_H) / ROW_H) + 1;

    ctx.font = '11px system-ui';
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.fillStyle = textColor;
    let x = HEADER_W - this.scrollX;
    for (let c = firstCol; c <= lastCol; c++) {
      ctx.strokeRect(Math.floor(x) + 0.5, 0, COL_W, HEADER_H);
      ctx.fillText(colName(c), x + COL_W / 2, HEADER_H / 2);
      x += COL_W;
    }
    let y = HEADER_H - this.scrollY;
    for (let r = firstRow; r <= lastRow; r++) {
      ctx.strokeRect(0, Math.floor(y) + 0.5, HEADER_W, ROW_H);
      ctx.fillText(String(r + 1), HEADER_W / 2, y + ROW_H / 2);
      y += ROW_H;
    }

    const cf = sheet.cf || [];
    ctx.font = '13px Calibri, Carlito, system-ui';
    ctx.textAlign = 'left'; ctx.textBaseline = 'middle';

    for (let r = firstRow; r <= lastRow; r++) {
      if (this._rowFiltered(r)) continue;
      for (let c = firstCol; c <= lastCol; c++) {
        const cx = HEADER_W + c * COL_W - this.scrollX;
        const cy = HEADER_H + r * ROW_H - this.scrollY;
        if (this.gridlinesVisible) ctx.strokeRect(Math.floor(cx) + 0.5, Math.floor(cy) + 0.5, COL_W, ROW_H);

        const ref = colName(c) + (r + 1);
        const cell = cells[ref];
        const cfOverride = evaluateCF(cf, this.engine, cells, r, c);

        const fill = cfOverride?.fill || cell?.s?.fill;
        if (fill) {
          ctx.save();
          ctx.fillStyle = fill;
          ctx.fillRect(cx + 1, cy + 1, COL_W - 1, ROW_H - 1);
          ctx.restore();
        }

        if (!cell && !cfOverride) continue;

        let txt = '';
        if (this.showFormulas && cell?.f) txt = cell.f;
        else txt = String(this.engine.getDisplayValue(ref) ?? '');

        const color = cfOverride?.color || cell?.s?.color || textColor;
        const val = this.engine.getValue(ref);
        const align = cfOverride?.align || cell?.s?.align || (typeof val === 'number' ? 'right' : 'left');

        ctx.fillStyle = color;
        ctx.save();
        ctx.beginPath();
        ctx.rect(cx + 1, cy + 1, COL_W - 2, ROW_H - 2);
        ctx.clip();
        const textX = align === 'right' ? cx + COL_W - 4
                    : align === 'center' ? cx + COL_W / 2
                    : cx + 4;
        if (align === 'right') ctx.textAlign = 'right';
        else if (align === 'center') ctx.textAlign = 'center';
        else ctx.textAlign = 'left';
        ctx.fillText(txt, textX, cy + ROW_H / 2);
        ctx.restore();

        // Error indicator
        if (typeof val === 'string' && val.startsWith('#') && val !== '#') {
          ctx.fillStyle = '#217346';
          ctx.beginPath();
          ctx.moveTo(cx + COL_W - 8, cy + 1);
          ctx.lineTo(cx + COL_W - 1, cy + 1);
          ctx.lineTo(cx + COL_W - 1, cy + 8);
          ctx.closePath();
          ctx.fill();
        }

        // Sparkline
        if (cell?.sparkline) {
          drawSparkline(ctx, cx + 4, cy + 2, COL_W - 8, ROW_H - 4, cell.sparkline);
        }
      }
    }

    const frozen = sheet.frozen || {};
    if (frozen.r != null) {
      const fy = HEADER_H + frozen.r * ROW_H - this.scrollY;
      ctx.strokeStyle = '#217346'; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.moveTo(HEADER_W, fy); ctx.lineTo(this.viewW, fy); ctx.stroke();
      ctx.lineWidth = 1; ctx.strokeStyle = border;
    }

    const { start, end } = this.selection;
    const r0 = Math.min(start.r, end.r), r1 = Math.max(start.r, end.r);
    const c0 = Math.min(start.c, end.c), c1 = Math.max(start.c, end.c);
    const sx = HEADER_W + c0 * COL_W - this.scrollX;
    const sy = HEADER_H + r0 * ROW_H - this.scrollY;
    const sw = (c1 - c0 + 1) * COL_W;
    const sh = (r1 - r0 + 1) * ROW_H;
    ctx.strokeStyle = '#217346'; ctx.lineWidth = 2;
    ctx.strokeRect(sx + 0.5, sy + 0.5, sw, sh);
    ctx.fillStyle = '#217346';
    ctx.fillRect(sx + sw - 3, sy + sh - 3, 6, 6);

    ctx.fillStyle = 'rgba(33,115,70,.15)';
    ctx.fillRect(sx, 0, sw, HEADER_H);
    ctx.fillRect(0, sy, HEADER_W, sh);
    ctx.strokeStyle = '#217346';
    ctx.strokeRect(sx, 0, sw, HEADER_H);
    ctx.strokeRect(0, sy, HEADER_W, sh);
  }

  _rowFiltered(r) {
    if (!this.filterOn) return false;
    for (const key in this.filterValues) {
      const colIndex = colIdx(key);
      const allowed = this.filterValues[key];
      if (!allowed) continue;
      const val = String(this.engine.getValue(colName(colIndex) + (r + 1)));
      if (!allowed.has(val)) return true;
    }
    return false;
  }

  _bindEvents() {
    window.addEventListener('resize', () => { this._resize(); this._draw(); });
    this.canvas.parentElement.addEventListener('scroll', () => {
      this.scrollX = this.canvas.parentElement.scrollLeft;
      this.scrollY = this.canvas.parentElement.scrollTop;
      this._draw();
    });

    let dragging = false;
    let draggingHandle = false;
    const cellFromEvent = (e) => {
      const rect = this.canvas.getBoundingClientRect();
      const x = e.clientX - rect.left + this.scrollX - HEADER_W;
      const y = e.clientY - rect.top + this.scrollY - HEADER_H;
      return { r: Math.max(0, Math.floor(y / ROW_H)), c: Math.max(0, Math.floor(x / COL_W)) };
    };

    this.canvas.addEventListener('mousedown', (e) => {
      const cell = cellFromEvent(e);
      const { r1, c1 } = this._selectionBounds();
      const hx = HEADER_W + (c1 + 1) * COL_W - this.scrollX - 3;
      const hy = HEADER_H + (r1 + 1) * ROW_H - this.scrollY - 3;
      const rect = this.canvas.getBoundingClientRect();
      const ex = e.clientX - rect.left, ey = e.clientY - rect.top;
      if (Math.abs(ex - hx) < 6 && Math.abs(ey - hy) < 6) { draggingHandle = true; return; }
      this.selection.start = cell;
      this.selection.end = cell;
      this.selection.anchor = cell;
      dragging = true;
      this._commitEditor();
      this._draw();
      this._updateFormulaBar();
      this._updateSelectionStats();
    });
    this.canvas.addEventListener('mousemove', (e) => {
      if (!dragging && !draggingHandle) return;
      const cell = cellFromEvent(e);
      if (dragging) { this.selection.end = cell; this._autoScroll(e); }
      else if (draggingHandle) this.selection.end = cell;
      this._draw();
      this._updateSelectionStats();
    });
    this.canvas.addEventListener('mouseup', async () => {
      if (draggingHandle) { draggingHandle = false; await this._fillSeries(); }
      dragging = false;
    });
    this.canvas.addEventListener('dblclick', (e) => {
      const cell = cellFromEvent(e);
      this._startEdit(cell.r, cell.c, null, true);
    });
    this.canvas.addEventListener('keydown', (e) => this._onKeyDown(e));
    this.canvas.addEventListener('contextmenu', (e) => this._gridContextMenu(e));

    this.formulaInput.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') { this._commitEditor(true); e.preventDefault(); }
      if (e.key === 'Escape') { this.formulaInput.value = ''; this._updateFormulaBar(); this._hideAutocomplete(); }
      if (e.key === 'ArrowDown') { e.preventDefault(); this._moveAutocomplete(1); }
      if (e.key === 'ArrowUp')   { e.preventDefault(); this._moveAutocomplete(-1); }
      if (e.key === 'Tab')       { e.preventDefault(); this._acceptAutocomplete(); }
    });
    this.formulaInput.addEventListener('input', () => this._showAutocomplete(this.formulaInput.value));
    this.formulaInput.addEventListener('focus', () => {
      const ref = this._currentRef();
      const cell = this._getCells()[ref] || {};
      this.formulaInput.value = cell.f || (cell.v != null ? String(cell.v) : '');
    });

    this.nameBox.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        const v = this.nameBox.value.trim();
        const m = v.match(/^([A-Z]+)(\d+)$/i);
        if (m) {
          const c = colIdx(m[1].toUpperCase());
          const r = parseInt(m[2], 10) - 1;
          this.selection.start = this.selection.end = { r, c };
          this._ensureVisible({ r, c });
          this._draw();
          this._updateFormulaBar();
        }
      }
    });
  }

  _autoScroll(e) {
    const rect = this.canvas.getBoundingClientRect();
    const x = e.clientX - rect.left, y = e.clientY - rect.top;
    const el = this.canvas.parentElement;
    if (x < AUTOSCROLL_EDGE) el.scrollLeft -= (AUTOSCROLL_EDGE - x);
    if (x > rect.width - AUTOSCROLL_EDGE) el.scrollLeft += (x - (rect.width - AUTOSCROLL_EDGE));
    if (y < AUTOSCROLL_EDGE) el.scrollTop -= (AUTOSCROLL_EDGE - y);
    if (y > rect.height - AUTOSCROLL_EDGE) el.scrollTop += (y - (rect.height - AUTOSCROLL_EDGE));
  }

  async _fillSeries() {
    const { r0, r1, c0, c1 } = this._selectionBounds();
    const cells = this._getCells();
    const undo = [];
    for (let c = c0; c <= c1; c++) {
      const sourceRefs = [];
      for (let r = r0; r < r1; r++) {
        const ref = colName(c) + (r + 1);
        if (cells[ref]) sourceRefs.push(cells[ref]);
      }
      if (!sourceRefs.length) continue;
      const series = inferSeries(sourceRefs.map(x => x.v));
      for (let r = r0; r < r1; r++) {
        const ref = colName(c) + (r + 1);
        undo.push({ ref, prev: cells[ref] ? { ...cells[ref] } : null });
        if (series.kind === 'number') cells[ref] = { v: series.start + series.step * (r - r0) };
        else if (series.kind === 'date') cells[ref] = { v: series.start + series.step * (r - r0), s: { numfmt: 'yyyy-mm-dd' } };
        else if (series.kind === 'text') cells[ref] = { v: series.values[(r - r0) % series.values.length] };
      }
    }
    this._snapshot('fill series', () => undo.forEach(({ ref, prev }) => { if (prev) cells[ref] = prev; else delete cells[ref]; }));
    this.engine.setCells(cells);
    this._draw();
  }

  _onKeyDown(e) {
    if (this.editor && !this.editor.classList.contains('hidden')) return;
    const sel = this.selection;
    const key = e.key;
    let handled = true;

    if (key === 'ArrowUp')         sel.end = { r: Math.max(0, sel.end.r - 1), c: sel.end.c };
    else if (key === 'ArrowDown')  sel.end = { r: sel.end.r + 1, c: sel.end.c };
    else if (key === 'ArrowLeft')  sel.end = { r: sel.end.r, c: Math.max(0, sel.end.c - 1) };
    else if (key === 'ArrowRight') sel.end = { r: sel.end.r, c: sel.end.c + 1 };
    else if (key === 'Tab')        sel.end = { r: sel.end.r, c: sel.end.c + (e.shiftKey ? -1 : 1) };
    else if (key === 'Home')       sel.end = { r: sel.end.r, c: 0 };
    else if (key === 'End')        sel.end = { r: sel.end.r, c: Math.max(0, this._usedRange().c1) };
    else if (key === 'PageDown')   sel.end = { r: sel.end.r + Math.floor(this.viewH / ROW_H), c: sel.end.c };
    else if (key === 'PageUp')     sel.end = { r: Math.max(0, sel.end.r - Math.floor(this.viewH / ROW_H)), c: sel.end.c };
    else if (key === 'Enter')      { this._commitEditor(); sel.end = { r: sel.end.r + (e.shiftKey ? -1 : 1), c: sel.end.c }; }
    else if (key === 'Escape')     { this._commitEditor(); }
    else if (key === 'F2')         { this._startEdit(sel.end.r, sel.end.c, null, true); return; }
    else if (key === 'Delete' || key === 'Backspace') { this.command('clearContents'); return; }
    else if (key.length === 1 && !e.ctrlKey && !e.metaKey && !e.altKey) { this._startEdit(sel.end.r, sel.end.c, key, false); return; }
    else handled = false;

    if (handled) {
      e.preventDefault();
      this.selection.start = sel.end;
      this._ensureVisible(sel.end);
      this._draw();
      this._updateFormulaBar();
      this._updateSelectionStats();
    }
  }

  _ensureVisible(cell) {
    const parent = this.canvas.parentElement;
    const cw = parent.clientWidth - HEADER_W;
    const ch = parent.clientHeight - HEADER_H;
    const cx = cell.c * COL_W - this.scrollX;
    const cy = cell.r * ROW_H - this.scrollY;
    if (cx < 0) parent.scrollLeft += cx - 4;
    else if (cx + COL_W > cw) parent.scrollLeft += (cx + COL_W - cw + 4);
    if (cy < 0) parent.scrollTop += cy - 4;
    else if (cy + ROW_H > ch) parent.scrollTop += (cy + ROW_H - ch + 4);
  }

  _usedRange() {
    let r1 = 0, c1 = 0;
    for (const ref in this._getCells()) {
      const m = ref.match(/^([A-Z]+)(\d+)$/);
      if (!m) continue;
      r1 = Math.max(r1, parseInt(m[2], 10) - 1);
      c1 = Math.max(c1, colIdx(m[1]));
    }
    return { r1, c1 };
  }

  _currentRef() { return colName(this.selection.end.c) + (this.selection.end.r + 1); }

  _selectionBounds() {
    const { start, end } = this.selection;
    return {
      r0: Math.min(start.r, end.r), r1: Math.max(start.r, end.r),
      c0: Math.min(start.c, end.c), c1: Math.max(start.c, end.c),
    };
  }

  _startEdit(r, c, initialChar, selectAll = false) {
    const ref = colName(c) + (r + 1);
    const cell = this._getCells()[ref] || {};
    const x = HEADER_W + c * COL_W - this.scrollX;
    const y = HEADER_H + r * ROW_H - this.scrollY;
    const ed = this.editor;
    ed.style.left = x + 'px'; ed.style.top = y + 'px';
    ed.style.width = COL_W + 'px'; ed.style.height = ROW_H + 'px';
    ed.classList.remove('hidden');
    ed.value = selectAll ? (cell.v ?? '') : (initialChar ?? (cell.v != null ? String(cell.v) : ''));
    ed.focus();
    if (selectAll) ed.select();
    else ed.setSelectionRange(ed.value.length, ed.value.length);

    ed.onkeydown = (e) => {
      if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); this._commitEditor(); this.selection.end.r += 1; this.selection.start = this.selection.end; this._draw(); }
      else if (e.key === 'Escape') { e.preventDefault(); this._cancelEditor(); }
      else if (e.key === 'Tab') { e.preventDefault(); this._commitEditor(); this.selection.end.c += 1; this.selection.start = this.selection.end; this._draw(); }
    };
  }

  _commitEditor() {
    const ed = this.editor;
    if (ed.classList.contains('hidden')) return;
    const val = ed.value;
    ed.classList.add('hidden');
    const ref = this._currentRef();
    const cells = this._getCells();
    const prev = cells[ref] ? { ...cells[ref] } : null;

    if (val === '') delete cells[ref];
    else if (val.startsWith('=')) cells[ref] = { f: val };
    else {
      const num = Number(val);
      cells[ref] = isNaN(num) ? { v: val } : { v: num };
    }
    this._snapshot('edit cell', () => { if (prev) cells[ref] = prev; else delete cells[ref]; });
    this.engine.setCells(cells);
    this._draw();
    this._updateFormulaBar();
    this._updateSelectionStats();
  }

  _cancelEditor() { this.editor.classList.add('hidden'); }

  _setupFormulaAutocomplete() {
    let box = document.getElementById('formulaAutocomplete');
    if (!box) {
      box = document.createElement('div');
      box.id = 'formulaAutocomplete';
      box.className = 'formula-autocomplete hidden';
      document.body.appendChild(box);
    }
    this.autocompleteBox = box;
    this.autocompleteIndex = 0;
    this.autocompleteItems = [];
  }

  _showAutocomplete(value) {
    const fnMatch = value.match(/=?([A-Z][A-Z0-9.]*)$/i);
    if (!fnMatch) { this._hideAutocomplete(); return; }
    const prefix = fnMatch[1].toUpperCase();
    const fns = (window.__FUNCTIONS__ || []).filter(n => n.startsWith(prefix)).slice(0, 8);
    if (!fns.length) { this._hideAutocomplete(); return; }
    this.autocompleteItems = fns;
    this.autocompleteIndex = 0;
    const box = this.autocompleteBox;
    box.innerHTML = fns.map((n, i) => `<div class="fn-item ${i === 0 ? 'active' : ''}" data-fn="${n}">${n}</div>`).join('');
    const rect = this.formulaInput.getBoundingClientRect();
    box.style.left = rect.left + 'px';
    box.style.top = (rect.bottom + 2) + 'px';
    box.style.width = Math.max(220, rect.width) + 'px';
    box.classList.remove('hidden');
    box.querySelectorAll('.fn-item').forEach(el => {
      el.onclick = () => { this._insertFn(el.dataset.fn); this._hideAutocomplete(); };
    });
  }

  _hideAutocomplete() { if (this.autocompleteBox) this.autocompleteBox.classList.add('hidden'); }
  _moveAutocomplete(dir) {
    if (!this.autocompleteItems.length) return;
    this.autocompleteIndex = (this.autocompleteIndex + dir + this.autocompleteItems.length) % this.autocompleteItems.length;
    this.autocompleteBox.querySelectorAll('.fn-item').forEach((el, i) => el.classList.toggle('active', i === this.autocompleteIndex));
  }
  _acceptAutocomplete() {
    if (!this.autocompleteItems.length) return;
    this._insertFn(this.autocompleteItems[this.autocompleteIndex]);
    this._hideAutocomplete();
  }
  _insertFn(fn) {
    this.formulaInput.value = this.formulaInput.value.replace(/([A-Z][A-Z0-9.]*)$/i, fn + '(');
    this.formulaInput.focus();
  }

  _updateFormulaBar() {
    const ref = this._currentRef();
    this.nameBox.value = ref;
    const cell = this._getCells()[ref];
    this.formulaInput.value = cell ? (cell.f || (cell.v != null ? String(cell.v) : '')) : '';
    this.ribbon.setContext({
      bold: !!cell?.s?.bold, italic: !!cell?.s?.italic, underline: !!cell?.s?.underline,
      fill: cell?.s?.fill || '#ffffff',
      color: cell?.s?.color || '#1f1f1f',
      numfmt: cell?.s?.numfmt || 'General',
      align: cell?.s?.align || 'left',
      wrap: !!cell?.s?.wrap,
    });
  }

  _updateSelectionStats() {
    const { r0, r1, c0, c1 } = this._selectionBounds();
    let sum = 0, cnt = 0, min = Infinity, max = -Infinity;
    for (let r = r0; r <= r1; r++) for (let c = c0; c <= c1; c++) {
      const ref = colName(c) + (r + 1);
      const v = this.engine.getValue(ref);
      if (typeof v === 'number' && !isNaN(v)) {
        sum += v; cnt++; if (v < min) min = v; if (v > max) max = v;
      }
    }
    const stats = document.getElementById('selectionStats');
    if (cnt > 0) stats.textContent = `Average: ${(sum/cnt).toFixed(2)}   Count: ${cnt}   Sum: ${sum.toFixed(2)}   Min: ${min}   Max: ${max}`;
    else stats.textContent = '';
  }

  _snapshot(label, undoOverride) {
    const cells = this._getCells();
    const before = JSON.parse(JSON.stringify(cells));
    queueMicrotask(() => {
      const after = JSON.parse(JSON.stringify(cells));
      if (JSON.stringify(before) === JSON.stringify(after)) return;
      const sheetIdx = this.activeSheet;
      this.history.push({
        label,
        do: () => { this.sheets[sheetIdx].cells = JSON.parse(JSON.stringify(after)); this.engine.setCells(this.sheets[sheetIdx].cells); this._draw(); },
        undo: undoOverride || (() => { this.sheets[sheetIdx].cells = JSON.parse(JSON.stringify(before)); this.engine.setCells(this.sheets[sheetIdx].cells); this._draw(); }),
      });
      this.autosaver?.schedule();
    });
  }

  _setupRibbon() {
    const ctx = {
      bold: false, italic: false, underline: false, wrap: false,
      fill: '#ffffff', color: '#1f1f1f', numfmt: 'General', align: 'left',
      cmd: (name, val) => this.command(name, val),
    };
    this.ribbon = new Ribbon({ host: this.ribbonHost, config: excelRibbon, context: ctx });
  }

  command(name, val) {
    switch (name) {
      case 'bold': this._toggleCellStyle('bold', val); break;
      case 'italic': this._toggleCellStyle('italic', val); break;
      case 'underline': this._toggleCellStyle('underline', val); break;
      case 'fill': this._setCellStyle('fill', val); break;
      case 'color': this._setCellStyle('color', val); break;
      case 'numfmt': this._setCellStyle('numfmt', val); break;
      case 'align': this._setCellStyle('align', val); break;
      case 'wrap': this._setCellStyle('wrap', val); break;
      case 'insertChart': this._insertChart(val); break;
      case 'autosum': this._insertAutoSum(val); break;
      case 'sort': this._sort(val); break;
      case 'find': this._showFind(); break;
      case 'clearContents': this._clearContents(); break;
      case 'fillDown': this._fillDown(); break;
      case 'removeDuplicates': this._removeDuplicates(); break;
      case 'insertFunction': this._insertFunctionDialog(); break;
      case 'recalcAll': this.engine.recalcAll(); this._draw(); break;
      case 'calcMode': this.engine.calcMode = val; break;
      case 'freeze': this._freeze(); break;
      case 'gridlines': this.gridlinesVisible = val !== false; this._draw(); break;
      case 'headings': case 'formulaBar': break;
      case 'filter': this._toggleFilter(val); break;
      case 'showFormulas': this.showFormulas = val; this._draw(); break;
      case 'style': this._applyStyle(val); break;
      case 'undo': this.history.undo(); this._draw(); break;
      case 'redo': this.history.redo(); this._draw(); break;
      case 'insertLink': this._insertLink(); break;
      case 'format': this._formatCellsDialog(); break;
      case 'condfmt': this._condFormatDialog(); break;
      case 'dataValidation': this._dataValidationDialog(); break;
      case 'pasteSpecial': this._pasteSpecial(); break;
      case 'tracePrecedents': this._tracePrecedents(); break;
      case 'traceDependents': this._traceDependents(); break;
      case 'nameManager': this._nameManagerDialog(); break;
      case 'defineName': this._defineNameDialog(); break;
      case 'textToCols': this._textToColumnsDialog(); break;
      case 'goalSeek': this._goalSeekDialog(); break;
      case 'evaluateFormula': this._evaluateFormulaDialog(); break;

      // Phase 4
      case 'pivot': this._pivotDialog(); break;
      case 'solver': this._solverDialog(); break;
      case 'scenarioManager': this._scenarioManagerDialog(); break;
      case 'dataTable': this._dataTableDialog(); break;
      case 'forecastSheet': this._forecastSheetDialog(); break;
      case 'analysisToolpak': this._analysisDialog(); break;
      case 'powerQuery': this._powerQueryDialog(); break;
      case 'sparkline': this._sparklineDialog(); break;
      case 'slicer': alert('Slicers are configured via the Pivot table.'); break;

      default: console.warn('Unhandled sheets command:', name);
    }
    this.autosaver?.schedule();
  }

  _setCellStyle(key, val) {
    const { r0, r1, c0, c1 } = this._selectionBounds();
    const cells = this._getCells();
    const undo = [];
    for (let r = r0; r <= r1; r++) for (let c = c0; c <= c1; c++) {
      const ref = colName(c) + (r + 1);
      const prev = cells[ref] ? { ...cells[ref] } : null;
      const cell = cells[ref] || {};
      cell.s = { ...(cell.s || {}), [key]: val };
      cells[ref] = cell;
      undo.push({ ref, prev });
    }
    this._snapshot('style ' + key, () => undo.forEach(({ ref, prev }) => { if (prev) cells[ref] = prev; else delete cells[ref]; }));
    this._draw();
    this._updateFormulaBar();
  }
  _toggleCellStyle(key, on) { this._setCellStyle(key, on); }
  _applyStyle(val) {
    const map = { good: { fill: '#C6EFCE', color: '#006100' },
                  bad:  { fill: '#FFC7CE', color: '#9C0006' },
                  neutral: { fill: '#FFEB9C', color: '#9C6500' } };
    const style = map[val]; if (!style) return;
    for (const k in style) this._setCellStyle(k, style[k]);
  }

  _insertAutoSum(fn) {
    const { r0, c0 } = this._selectionBounds();
    const ref = colName(c0) + (r0 + 1);
    let start = r0 - 1;
    while (start >= 0 && this._getCells()[colName(c0) + (start + 1)]) start--;
    start++;
    if (start < r0) {
      const range = `${colName(c0)}${start + 1}:${colName(c0)}${r0}`;
      this._getCells()[ref] = { f: `=${fn}(${range})` };
      this._snapshot('autosum');
      this.engine.setCells(this._getCells());
      this._draw(); this._updateFormulaBar();
    }
  }

  _insertLink() {
    const host = document.getElementById('dialogHost');
    prompt2({
      title: 'Insert Hyperlink', host,
      fields: [{ name: 'url', label: 'URL', value: 'https://' },
               { name: 'text', label: 'Display text', value: '' }],
    }).then(r => {
      if (!r || !r.url) return;
      const ref = this._currentRef();
      const cells = this._getCells();
      cells[ref] = cells[ref] || {};
      cells[ref].v = r.text || r.url;
      cells[ref].s = { ...(cells[ref].s || {}), color: '#0563C1', underline: true };
      this.sheets[this.activeSheet].hyperlinks = this.sheets[this.activeSheet].hyperlinks || {};
      this.sheets[this.activeSheet].hyperlinks[ref] = r.url;
      this._snapshot('insert hyperlink');
      this.engine.setCells(cells);
      this._draw();
    });
  }

  _insertChart(type) {
    if (!window.Chart) {
      const s = document.createElement('script');
      s.src = 'https://cdn.jsdelivr.net/npm/chart.js@4.4.3/dist/chart.umd.min.js';
      s.onload = () => this._insertChart(type);
      document.head.appendChild(s);
      return;
    }
    const { r0, r1, c0, c1 } = this._selectionBounds();
    const cells = this._getCells();
    const labels = [];
    for (let c = c0 + 1; c <= c1; c++) labels.push(String(this.engine.getValue(colName(c) + (r0 + 1)) ?? ''));
    const datasets = [];
    for (let r = r0 + 1; r <= r1; r++) {
      const name = String(this.engine.getValue(colName(c0) + (r + 1)) ?? '');
      const data = [];
      for (let c = c0 + 1; c <= c1; c++) {
        const v = this.engine.getValue(colName(c) + (r + 1));
        data.push(typeof v === 'number' ? v : 0);
      }
      datasets.push({ label: name, data });
    }
    const host = document.getElementById('dialogHost');
    const wrap = document.createElement('div');
    const canvas = document.createElement('canvas');
    canvas.width = 640; canvas.height = 360;
    wrap.appendChild(canvas);
    openDialog({
      host, title: 'Insert Chart', content: wrap,
      buttons: [
        { label: 'Cancel' },
        { label: 'Insert', primary: true, onClick: () => {
            const chart = new Chart(canvas, { type: mapChartType(type), data: { labels, datasets }, options: { responsive: false, animation: false } });
            this.charts.push({ ref: this._currentRef(), chart });
            this._snapshot('insert chart');
          } },
      ],
    });
    setTimeout(() => {
      if (!canvas._chart) {
        canvas._chart = new Chart(canvas, { type: mapChartType(type), data: { labels, datasets }, options: { responsive: false, animation: false } });
      }
    }, 0);
  }

  _sort(dir) {
    const { c0, r0, r1 } = this._selectionBounds();
    const cells = this._getCells();
    const rows = [];
    for (let r = r0; r <= r1; r++) {
      const row = [];
      for (let c = 0; c < 26; c++) row.push(cells[colName(c) + (r + 1)]?.v ?? cells[colName(c) + (r + 1)]?.f ?? '');
      rows.push(row);
    }
    rows.sort((a, b) => {
      const av = a[c0], bv = b[c0];
      if (typeof av === 'number' && typeof bv === 'number') return dir === 'asc' ? av - bv : bv - av;
      return dir === 'asc' ? String(av).localeCompare(String(bv)) : String(bv).localeCompare(String(av));
    });
    for (let r = r0; r <= r1; r++) for (let c = 0; c < 26; c++) {
      const ref = colName(c) + (r + 1);
      const v = rows[r - r0][c];
      if (v === '' || v == null) delete cells[ref];
      else cells[ref] = { v };
    }
    this._snapshot('sort');
    this.engine.setCells(cells);
    this._draw();
  }

  _toggleFilter(on) {
    this.filterOn = on !== false ? !this.filterOn : false;
    if (!this.filterOn) this.filterValues = {};
    this._draw();
    if (this.filterOn) this._showFilterUI();
  }

  _showFilterUI() {
    const host = document.getElementById('dialogHost');
    const { r0, c0 } = this._selectionBounds();
    const col = prompt('Filter column (A, B, C…):', colName(c0));
    if (!col) { this.filterOn = false; this._draw(); return; }
    const cells = this._getCells();
    const unique = new Set();
    for (let r = r0 + 1; r < r0 + 1000; r++) {
      const v = cells[col + (r + 1)]?.v;
      if (v == null) break;
      unique.add(String(v));
    }
    const wrap = document.createElement('div');
    wrap.innerHTML = `<div style="max-height:240px;overflow:auto;display:flex;flex-direction:column;gap:2px;">${[...unique].map(v => `<label><input type="checkbox" value="${escapeAttr(v)}" checked> ${escapeHtml(v)}</label>`).join('')}</div>`;
    openDialog({
      host, title: `Filter column ${col}`, content: wrap,
      buttons: [
        { label: 'Cancel', onClick: () => { this.filterOn = false; this.filterValues = {}; this._draw(); } },
        { label: 'Apply', primary: true, onClick: (body) => {
            const checked = new Set();
            body.querySelectorAll('input[type=checkbox]').forEach(cb => { if (cb.checked) checked.add(cb.value); });
            this.filterValues[col] = checked;
          } },
      ],
    });
  }

  _showFind() {
    const host = document.getElementById('dialogHost');
    const wrap = document.createElement('div');
    wrap.innerHTML = `
      <label>Find: <input id="_sFind" style="width:100%;padding:6px;border:1px solid var(--border);border-radius:4px;"></label>
      <label style="display:block;margin-top:8px;">Replace: <input id="_sReplace" style="width:100%;padding:6px;border:1px solid var(--border);border-radius:4px;"></label>
      <div id="_sMsg" style="margin-top:8px;color:var(--text-muted);font-size:12px;"></div>`;
    openDialog({
      host, title: 'Find and Replace', content: wrap,
      buttons: [
        { label: 'Close' },
        { label: 'Find next', close: false, onClick: (body) => this._findNext(body) },
        { label: 'Replace', primary: true, close: false, onClick: (body) => this._replaceNext(body) },
      ],
    });
  }

  _findNext(body) {
    const q = body.querySelector('#_sFind').value;
    if (!q) return false;
    const cells = this._getCells();
    const refs = Object.keys(cells);
    const startRef = this._currentRef();
    const startIdx = refs.indexOf(startRef);
    for (let i = 1; i <= refs.length; i++) {
      const ref = refs[(startIdx + i) % refs.length];
      const v = this.engine.getDisplayValue(ref);
      if (String(v).toLowerCase().includes(q.toLowerCase())) {
        const m = ref.match(/^([A-Z]+)(\d+)$/);
        this.selection.start = this.selection.end = { r: parseInt(m[2], 10) - 1, c: colIdx(m[1]) };
        this._ensureVisible(this.selection.end);
        this._draw();
        body.querySelector('#_sMsg').textContent = `Found in ${ref}`;
        return false;
      }
    }
    body.querySelector('#_sMsg').textContent = 'No match';
    return false;
  }

  _replaceNext(body) {
    const q = body.querySelector('#_sFind').value;
    const r = body.querySelector('#_sReplace').value;
    if (!q) return false;
    const cells = this._getCells();
    const ref = this._currentRef();
    const v = String(cells[ref]?.v ?? '');
    if (v.toLowerCase().includes(q.toLowerCase())) {
      cells[ref] = { v: v.replace(new RegExp(q, 'gi'), r) };
      this._snapshot('replace');
      this.engine.setCells(cells);
      this._draw();
    }
    return this._findNext(body);
  }

  _clearContents() {
    const { r0, r1, c0, c1 } = this._selectionBounds();
    const cells = this._getCells();
    const undo = [];
    for (let r = r0; r <= r1; r++) for (let c = c0; c <= c1; c++) {
      const ref = colName(c) + (r + 1);
      if (cells[ref]) { undo.push({ ref, prev: cells[ref] }); delete cells[ref]; }
    }
    this._snapshot('clear', () => undo.forEach(({ ref, prev }) => cells[ref] = prev));
    this.engine.setCells(cells);
    this._draw();
  }

  _fillDown() {
    const { r0, r1, c0, c1 } = this._selectionBounds();
    const cells = this._getCells();
    for (let c = c0; c <= c1; c++) {
      const first = cells[colName(c) + (r0 + 1)];
      for (let r = r0 + 1; r <= r1; r++) if (first) cells[colName(c) + (r + 1)] = { ...first };
    }
    this._snapshot('fill down');
    this.engine.setCells(cells);
    this._draw();
  }

  _removeDuplicates() {
    const { r0, r1, c0, c1 } = this._selectionBounds();
    const cells = this._getCells();
    const seen = new Set();
    for (let r = r0; r <= r1; r++) {
      const key = JSON.stringify([...Array(c1 - c0 + 1)].map((_, i) => cells[colName(c0 + i) + (r + 1)]?.v));
      if (seen.has(key)) for (let c = c0; c <= c1; c++) delete cells[colName(c) + (r + 1)];
      else seen.add(key);
    }
    this._snapshot('remove duplicates');
    this.engine.setCells(cells);
    this._draw();
  }

  // ---------- Dialogs ----------
  _insertFunctionDialog() {
    const host = document.getElementById('dialogHost');
    const wrap = document.createElement('div');
    wrap.innerHTML = `
      <label>Search: <input id="_fnSearch" style="width:100%;padding:6px;border:1px solid var(--border);border-radius:4px;"></label>
      <div id="_fnList" style="margin-top:8px;max-height:240px;overflow:auto;border:1px solid var(--border);border-radius:4px;padding:4px;"></div>
      <label style="display:block;margin-top:8px;">Formula: <input id="_fnFormula" style="width:100%;padding:6px;border:1px solid var(--border);border-radius:4px;" placeholder="=SUM()"></label>`;
    const update = () => {
      const list = wrap.querySelector('#_fnList');
      const q = wrap.querySelector('#_fnSearch').value.toUpperCase();
      const fns = (window.__FUNCTIONS__ || []).filter(n => n.includes(q));
      list.innerHTML = fns.slice(0, 40).map(n => `<div class="fn-item" data-fn="${n}" style="padding:3px 6px;cursor:pointer;">${n}</div>`).join('');
      list.querySelectorAll('.fn-item').forEach(el => {
        el.onclick = () => {
          wrap.querySelector('#_fnFormula').value = `=${el.dataset.fn}(`;
          wrap.querySelector('#_fnFormula').focus();
        };
      });
    };
    setTimeout(update, 0);
    wrap.querySelector('#_fnSearch').oninput = update;
    openDialog({
      host, title: 'Insert Function', content: wrap,
      buttons: [
        { label: 'Cancel' },
        { label: 'Insert', primary: true, onClick: (body, close) => {
            const f = body.querySelector('#_fnFormula').value.trim();
            if (!f) return;
            const ref = this._currentRef();
            this._getCells()[ref] = { f };
            this._snapshot('insert function');
            this.engine.setCells(this._getCells());
            this._draw(); this._updateFormulaBar();
            close();
          } },
      ],
    });
  }

  _formatCellsDialog() {
    const host = document.getElementById('dialogHost');
    const wrap = document.createElement('div');
    const cell = this._getCells()[this._currentRef()] || {};
    const s = cell.s || {};
    wrap.innerHTML = `
      <div style="display:grid;grid-template-columns:120px 1fr;gap:8px;align-items:center;">
        <label>Number format</label><input id="_fcNum" value="${escapeAttr(s.numfmt || 'General')}" style="padding:4px;">
        <label>Alignment</label>
        <select id="_fcAlign" style="padding:4px;">
          <option value="left" ${s.align==='left'?'selected':''}>Left</option>
          <option value="center" ${s.align==='center'?'selected':''}>Center</option>
          <option value="right" ${s.align==='right'?'selected':''}>Right</option>
        </select>
        <label>Font</label><input id="_fcFont" value="${escapeAttr(s.font||'Calibri')}" style="padding:4px;">
        <label>Size</label><input id="_fcSize" type="number" value="${s.fontSize||11}" style="padding:4px;">
        <label>Bold</label><input id="_fcBold" type="checkbox" ${s.bold?'checked':''}>
        <label>Italic</label><input id="_fcItalic" type="checkbox" ${s.italic?'checked':''}>
        <label>Underline</label><input id="_fcUnderline" type="checkbox" ${s.underline?'checked':''}>
        <label>Fill color</label><input id="_fcFill" type="color" value="${s.fill || '#ffffff'}">
        <label>Text color</label><input id="_fcColor" type="color" value="${s.color || '#1f1f1f'}">
        <label>Wrap text</label><input id="_fcWrap" type="checkbox" ${s.wrap?'checked':''}>
      </div>
      <div style="margin-top:12px;font-size:12px;color:var(--text-muted);">Preview: <span id="_fcPreview"></span></div>`;
    const updatePreview = () => {
      const n = wrap.querySelector('#_fcNum').value;
      wrap.querySelector('#_fcPreview').textContent = numberFormat(1234.5678, n);
    };
    setTimeout(() => { updatePreview(); wrap.querySelector('#_fcNum').oninput = updatePreview; }, 0);
    openDialog({
      host, title: 'Format Cells', content: wrap,
      buttons: [
        { label: 'Cancel' },
        { label: 'OK', primary: true, onClick: (body) => {
            const style = {
              numfmt: body.querySelector('#_fcNum').value || undefined,
              align: body.querySelector('#_fcAlign').value,
              font: body.querySelector('#_fcFont').value || undefined,
              fontSize: Number(body.querySelector('#_fcSize').value) || undefined,
              bold: body.querySelector('#_fcBold').checked || undefined,
              italic: body.querySelector('#_fcItalic').checked || undefined,
              underline: body.querySelector('#_fcUnderline').checked || undefined,
              fill: body.querySelector('#_fcFill').value,
              color: body.querySelector('#_fcColor').value,
              wrap: body.querySelector('#_fcWrap').checked || undefined,
            };
            const { r0, r1, c0, c1 } = this._selectionBounds();
            const cells = this._getCells();
            for (let r = r0; r <= r1; r++) for (let c = c0; c <= c1; c++) {
              const ref = colName(c) + (r + 1);
              cells[ref] = cells[ref] || {};
              cells[ref].s = { ...(cells[ref].s || {}), ...style };
            }
            this._snapshot('format cells');
            this.engine.setCells(cells);
            this._draw();
          } },
      ],
    });
  }

  _condFormatDialog() {
    const host = document.getElementById('dialogHost');
    const wrap = document.createElement('div');
    wrap.innerHTML = `
      <label>Rule type:
        <select id="_cfType" style="width:100%;padding:6px;">
          <option value="cell">Cell value</option>
          <option value="colorScale">Color scale (3-color)</option>
          <option value="dataBar">Data bar</option>
        </select>
      </label>
      <div style="margin-top:8px;">
        <label>Criteria:
          <select id="_cfCrit" style="padding:4px;">
            <option value=">">greater than</option>
            <option value="<">less than</option>
            <option value=">=">≥</option>
            <option value="<=">≤</option>
            <option value="=">equal to</option>
            <option value="<>">not equal</option>
          </select>
        </label>
        <label>Value: <input id="_cfVal" style="padding:4px;" value="100"></label>
        <label>Fill: <input id="_cfFill" type="color" value="#ffcccc"></label>
        <label>Text: <input id="_cfColor" type="color" value="#9c0006"></label>
      </div>`;
    openDialog({
      host, title: 'Conditional Formatting', content: wrap,
      buttons: [
        { label: 'Cancel' },
        { label: 'Apply', primary: true, onClick: (body) => {
            const t = body.querySelector('#_cfType').value;
            const { r0, r1, c0, c1 } = this._selectionBounds();
            const range = `${colName(c0)}${r0 + 1}:${colName(c1)}${r1 + 1}`;
            const rule = { range, type: t };
            if (t === 'cell') {
              rule.criteria = body.querySelector('#_cfCrit').value;
              rule.value = Number(body.querySelector('#_cfVal').value);
              rule.format = { fill: body.querySelector('#_cfFill').value, color: body.querySelector('#_cfColor').value };
            }
            this.sheets[this.activeSheet].cf = this.sheets[this.activeSheet].cf || [];
            this.sheets[this.activeSheet].cf.push(rule);
            this._snapshot('conditional format');
            this._draw();
          } },
      ],
    });
  }

  _dataValidationDialog() {
    const host = document.getElementById('dialogHost');
    const wrap = document.createElement('div');
    wrap.innerHTML = `
      <label>Allow:
        <select id="_dvType" style="width:100%;padding:6px;">
          <option value="list">List</option>
          <option value="whole">Whole number</option>
          <option value="decimal">Decimal</option>
          <option value="custom">Custom formula</option>
        </select>
      </label>
      <label style="display:block;margin-top:8px;">Source / formula:
        <input id="_dvSource" style="width:100%;padding:6px;border:1px solid var(--border);border-radius:4px;" placeholder="Red,Green,Blue">
      </label>`;
    openDialog({
      host, title: 'Data Validation', content: wrap,
      buttons: [
        { label: 'Cancel' },
        { label: 'Apply', primary: true, onClick: (body) => {
            const { r0, r1, c0, c1 } = this._selectionBounds();
            const range = `${colName(c0)}${r0 + 1}:${colName(c1)}${r1 + 1}`;
            const type = body.querySelector('#_dvType').value;
            const source = body.querySelector('#_dvSource').value;
            const dv = { range, type };
            if (type === 'list') dv.source = source.split(',').map(s => s.trim());
            else if (type === 'custom') dv.formula = source;
            else dv.value = Number(source);
            this.sheets[this.activeSheet].validations = this.sheets[this.activeSheet].validations || [];
            this.sheets[this.activeSheet].validations.push(dv);
            this._snapshot('data validation');
          } },
      ],
    });
  }

  _freeze() {
    const { r0, c0 } = this._selectionBounds();
    this.sheets[this.activeSheet].frozen = { r: r0, c: c0 };
    this._snapshot('freeze panes');
    this._draw();
  }

  _tracePrecedents() {
    const ref = this._currentRef();
    const cell = this._getCells()[ref];
    if (!cell || !cell.f) { alert('Select a formula cell first.'); return; }
    const deps = [...(this.engine._deps.get(ref) || [])];
    alert(`Precedents of ${ref}:\n${deps.join(', ')}`);
  }
  _traceDependents() {
    const ref = this._currentRef();
    const deps = [...(this.engine._revDeps.get(ref) || [])];
    alert(`Dependents of ${ref}:\n${deps.join(', ')}`);
  }

  _nameManagerDialog() {
    const host = document.getElementById('dialogHost');
    const wrap = document.createElement('div');
    const sheet = this.sheets[this.activeSheet];
    sheet.namedRanges = sheet.namedRanges || [];
    wrap.innerHTML = `<div style="max-height:300px;overflow:auto;">
      ${sheet.namedRanges.length === 0 ? '<div style="color:var(--text-muted);">No named ranges yet.</div>' :
        sheet.namedRanges.map((nr, i) => `<div style="padding:6px;border-bottom:1px solid var(--border);">
          <strong>${escapeHtml(nr.name)}</strong> &mdash; ${escapeHtml(nr.refersTo)}
          <button class="nr-del" data-i="${i}" style="float:right;">Delete</button>
        </div>`).join('')}</div>`;
    openDialog({ host, title: 'Name Manager', content: wrap, buttons: [{ label: 'Close' }] });
    setTimeout(() => {
      wrap.querySelectorAll('.nr-del').forEach(b => {
        b.onclick = () => {
          sheet.namedRanges.splice(Number(b.dataset.i), 1);
          this.engine.setNamedRanges(this._getNamedRanges());
          this._snapshot('delete name');
        };
      });
    }, 0);
  }

  _defineNameDialog() {
    const host = document.getElementById('dialogHost');
    const { r0, r1, c0, c1 } = this._selectionBounds();
    const range = `${colName(c0)}${r0 + 1}:${colName(c1)}${r1 + 1}`;
    prompt2({
      title: 'Define Name', host,
      fields: [{ name: 'name', label: 'Name', value: 'MyRange' },
               { name: 'refers', label: 'Refers to', value: range }],
    }).then(r => {
      if (!r || !r.name) return;
      this.sheets[this.activeSheet].namedRanges = this.sheets[this.activeSheet].namedRanges || [];
      this.sheets[this.activeSheet].namedRanges.push({ name: r.name, refersTo: r.refers });
      this.engine.setNamedRanges(this._getNamedRanges());
      this._snapshot('define name');
    });
  }

  _textToColumnsDialog() {
    const host = document.getElementById('dialogHost');
    const wrap = document.createElement('div');
    wrap.innerHTML = `<label>Delimiter:
      <select id="_ttcDelim" style="padding:4px;">
        <option value=",">Comma</option>
        <option value="\t">Tab</option>
        <option value=";">Semicolon</option>
        <option value=" ">Space</option>
      </select>
    </label>`;
    openDialog({
      host, title: 'Text to Columns', content: wrap,
      buttons: [
        { label: 'Cancel' },
        { label: 'OK', primary: true, onClick: (body) => {
            const delim = body.querySelector('#_ttcDelim').value;
            const ref = this._currentRef();
            const cells = this._getCells();
            const v = String(cells[ref]?.v ?? '');
            const parts = v.split(delim);
            const m = ref.match(/^([A-Z]+)(\d+)$/);
            const c0 = colIdx(m[1]);
            const r0 = parseInt(m[2], 10) - 1;
            parts.forEach((p, i) => {
              cells[colName(c0 + i) + (r0 + 1)] = { v: isNaN(Number(p)) ? p : Number(p) };
            });
            this._snapshot('text to columns');
            this.engine.setCells(cells);
            this._draw();
          } },
      ],
    });
  }

  _goalSeekDialog() {
    const host = document.getElementById('dialogHost');
    prompt2({
      title: 'Goal Seek', host,
      fields: [
        { name: 'setCell', label: 'Set cell', value: this._currentRef() },
        { name: 'toValue', label: 'To value', value: '0' },
        { name: 'byChanging', label: 'By changing cell', value: '' },
      ],
    }).then(r => {
      if (!r || !r.byChanging) return;
      const res = WhatIf.goalSeek(this._getCells(), this.sheets, r.setCell, Number(r.toValue), r.byChanging);
      if (res.error) { alert(res.error); return; }
      const cells = this._getCells();
      cells[r.byChanging] = { v: res.value };
      this._snapshot('goal seek');
      this.engine.setCells(cells);
      this._draw();
      alert(`Goal Seek: ${r.byChanging} = ${res.value}`);
    });
  }

  _evaluateFormulaDialog() {
    const ref = this._currentRef();
    const cell = this._getCells()[ref];
    if (!cell || !cell.f) { alert('Select a formula cell.'); return; }
    const host = document.getElementById('dialogHost');
    const wrap = document.createElement('div');
    const val = this.engine.getValue(ref);
    wrap.innerHTML = `<div><code>${escapeHtml(cell.f)}</code> → <strong>${escapeHtml(String(val))}</strong></div>`;
    openDialog({ host, title: `Evaluate Formula — ${ref}`, content: wrap, buttons: [{ label: 'Close' }] });
  }

  _pasteSpecial() {
    navigator.clipboard.readText().then(text => {
      if (!text) return;
      const rows = text.split('\n').map(r => r.split('\t'));
      const { r0, c0 } = this._selectionBounds();
      const cells = this._getCells();
      rows.forEach((row, i) => row.forEach((v, j) => {
        const num = Number(v);
        cells[colName(c0 + j) + (r0 + i + 1)] = { v: isNaN(num) ? v : num };
      }));
      this._snapshot('paste special');
      this.engine.setCells(cells);
      this._draw();
    });
  }

  // ---------- Phase 4 dialogs ----------
  _pivotDialog() {
    const host = document.getElementById('dialogHost');
    const wrap = document.createElement('div');
    wrap.style.cssText = 'min-width:520px;';
    const { r0, r1, c0, c1 } = this._selectionBounds();
    const headers = [];
    for (let c = c0; c <= c1; c++) headers.push(String(this.engine.getValue(colName(c) + (r0 + 1))));
    const rows = [];
    for (let r = r0 + 1; r <= r1; r++) {
      const rec = {};
      for (let ci = c0, hi = 0; ci <= c1; ci++, hi++) rec[headers[hi]] = this.engine.getValue(colName(ci) + (r + 1));
      rows.push(rec);
    }
    const state = { rows: [], cols: [], values: [], filters: [] };
    wrap.innerHTML = `
      <div style="display:grid;grid-template-columns:120px 1fr;gap:12px;">
        <div>
          <div style="font-weight:600;margin-bottom:6px;">Fields (drag)</div>
          <div id="_pvtFields">
            ${headers.map(h => `<div class="pv-field" draggable="true" data-field="${escapeAttr(h)}" style="padding:4px 8px;border:1px solid var(--border);border-radius:3px;margin-bottom:4px;cursor:grab;">${escapeHtml(h)}</div>`).join('')}
          </div>
        </div>
        <div>
          <div class="pv-dropzone" data-zone="rows" style="border:1px dashed var(--border);padding:8px;border-radius:4px;min-height:40px;">
            <strong>Rows</strong>
            <div class="pv-items"></div>
          </div>
          <div class="pv-dropzone" data-zone="cols" style="border:1px dashed var(--border);padding:8px;border-radius:4px;margin-top:6px;min-height:40px;">
            <strong>Columns</strong>
            <div class="pv-items"></div>
          </div>
          <div class="pv-dropzone" data-zone="values" style="border:1px dashed var(--border);padding:8px;border-radius:4px;margin-top:6px;min-height:40px;">
            <strong>Values</strong>
            <div class="pv-items"></div>
          </div>
        </div>
      </div>
      <div id="_pvtPreview" style="margin-top:12px;max-height:260px;overflow:auto;border:1px solid var(--border);border-radius:4px;"></div>`;
    const renderPreview = () => {
      const out = PivotEngine.compute(rows, state);
      let html = '<table style="border-collapse:collapse;width:100%;font-size:12px;">';
      html += '<tr><th style="border:1px solid var(--border);padding:4px;"></th>';
      for (const cv of out.colVals) html += `<th style="border:1px solid var(--border);padding:4px;">${escapeHtml(cv.join(' / '))}</th>`;
      html += `<th style="border:1px solid var(--border);padding:4px;background:#f5f5f5;">Total</th></tr>`;
      for (let i = 0; i < out.rowVals.length; i++) {
        html += `<tr><th style="border:1px solid var(--border);padding:4px;background:#f5f5f5;">${escapeHtml(out.rowVals[i].join(' / '))}</th>`;
        for (let j = 0; j < out.colVals.length; j++) {
          html += `<td style="border:1px solid var(--border);padding:4px;text-align:right;">${formatPivotCell(out.matrix[i][j])}</td>`;
        }
        html += `<td style="border:1px solid var(--border);padding:4px;text-align:right;font-weight:600;">${out.rowTotals[i].toFixed(2)}</td></tr>`;
      }
      html += `<tr><th style="border:1px solid var(--border);padding:4px;background:#f5f5f5;">Total</th>`;
      for (let j = 0; j < out.colVals.length; j++) {
        html += `<td style="border:1px solid var(--border);padding:4px;text-align:right;font-weight:600;">${out.colTotals[j].toFixed(2)}</td>`;
      }
      html += `<td style="border:1px solid var(--border);padding:4px;text-align:right;font-weight:600;">${out.grandTotal.toFixed(2)}</td></tr>`;
      html += '</table>';
      wrap.querySelector('#_pvtPreview').innerHTML = html;
    };
    let dragField = null;
    setTimeout(() => {
      wrap.querySelectorAll('.pv-field').forEach(el => {
        el.ondragstart = (e) => { dragField = el.dataset.field; e.dataTransfer.effectAllowed = 'copy'; };
      });
      wrap.querySelectorAll('.pv-dropzone').forEach(zone => {
        zone.ondragover = (e) => { e.preventDefault(); zone.style.background = '#eef'; };
        zone.ondragleave = () => { zone.style.background = ''; };
        zone.ondrop = (e) => {
          e.preventDefault();
          zone.style.background = '';
          if (!dragField) return;
          const z = zone.dataset.zone;
          if (z === 'values') state.values.push({ field: dragField, agg: 'sum' });
          else state[z].push(dragField);
          zone.querySelector('.pv-items').innerHTML =
            (z === 'values' ? state.values.map(v => `${v.field} (${v.agg})`) : state[z])
            .map(t => `<span style="display:inline-block;background:#eef;padding:2px 6px;border-radius:3px;margin:2px;font-size:11px;">${escapeHtml(String(t))}</span>`).join('');
          renderPreview();
        };
      });
    }, 0);
    openDialog({
      host, title: 'PivotTable from Selection', content: wrap,
      buttons: [
        { label: 'Cancel' },
        { label: 'Insert', primary: true, onClick: () => {
            const out = PivotEngine.compute(rows, state);
            this._writePivotToSheet(out, state);
            this._snapshot('pivot table');
            this._draw();
          } },
      ],
    });
  }

  _writePivotToSheet(out, state) {
    const cells = this._getCells();
    const startR = this.selection.end.r + 2;
    const startC = this.selection.end.c;
    for (let j = 0; j < out.colVals.length; j++) {
      cells[colName(startC + j + 1) + (startR + 1)] = { v: out.colVals[j].join(' / ') };
    }
    cells[colName(startC) + (startR + 1)] = { v: 'Row Labels' };
    for (let i = 0; i < out.rowVals.length; i++) {
      cells[colName(startC) + (startR + i + 2)] = { v: out.rowVals[i].join(' / ') };
      for (let j = 0; j < out.colVals.length; j++) {
        const val = out.matrix[i][j];
        cells[colName(startC + j + 1) + (startR + i + 2)] = { v: Array.isArray(val) ? val.reduce((a, b) => a + b, 0) : val };
      }
    }
    this.engine.setCells(cells);
  }

  _solverDialog() {
    const host = document.getElementById('dialogHost');
    const wrap = document.createElement('div');
    wrap.style.cssText = 'min-width:520px;';
    wrap.innerHTML = `
      <div style="display:grid;grid-template-columns:160px 1fr;gap:8px;align-items:center;">
        <label>Set Objective:</label><input id="_svObj" value="${this._currentRef()}" style="padding:4px;">
        <label>To:</label>
        <select id="_svSense" style="padding:4px;">
          <option value="max">Max</option>
          <option value="min">Min</option>
        </select>
        <label>By Changing:</label><input id="_svVars" placeholder="A1:B5" style="padding:4px;">
        <label>Constraints:</label>
        <div id="_svConstraints">
          <div style="display:flex;gap:4px;margin-bottom:4px;">
            <input placeholder="range" class="sv-crange" style="padding:4px;flex:1;">
            <select class="sv-cop" style="padding:4px;"><option>&lt;=</option><option>&gt;=</option><option>=</option></select>
            <input placeholder="rhs" class="sv-crhs" style="padding:4px;width:80px;">
          </div>
        </div>
        <label>Method:</label>
        <select id="_svMethod" style="padding:4px;">
          <option value="simplex">Simplex LP</option>
          <option value="grg">GRG Nonlinear</option>
          <option value="evolutionary">Evolutionary</option>
        </select>
      </div>
      <div id="_svOut" style="margin-top:12px;color:var(--text-muted);"></div>`;
    openDialog({
      host, title: 'Solver Parameters', content: wrap,
      buttons: [
        { label: 'Cancel' },
        { label: 'Solve', primary: true, close: false, onClick: async (body) => {
            const objRef = body.querySelector('#_svObj').value;
            const sense = body.querySelector('#_svSense').value;
            const varRange = body.querySelector('#_svVars').value;
            const method = body.querySelector('#_svMethod').value;
            const cells = this._getCells();
            const objCell = cells[objRef];
            if (!objCell?.f) { body.querySelector('#_svOut').textContent = 'Objective must be a formula cell.'; return false; }

            const [c0, r0, c1, r1] = parseRange(varRange);
            const variables = [];
            for (let r = r0; r <= r1; r++) for (let c = c0; c <= c1; c++) {
              const ref = colName(c) + (r + 1);
              variables.push({
                name: ref.replace(/[^A-Z0-9]/gi, '_'),
                cell: ref,
                min: -1e6, max: 1e6,
                initial: Number(this.engine.getValue(ref)) || 0,
              });
            }
            const constraints = [];
            body.querySelectorAll('#_svConstraints > div').forEach(row => {
              const rng = row.querySelector('.sv-crange').value.trim();
              const op = row.querySelector('.sv-cop').value;
              const rhs = Number(row.querySelector('.sv-crhs').value);
              if (rng && !isNaN(rhs)) constraints.push({ formula: buildSumExpression(rng), op, rhs });
            });
            const objFormulaClean = objCell.f.replace(/^=/, '').replace(/([A-Z]+)(\d+)/g, (m, c, r) => `${c}${r}`.replace(/[^A-Za-z0-9]/g, ''));

            try {
              const res = await api._fetch('/api/analyze/solver', {
                method: 'POST',
                body: JSON.stringify({
                  method,
                  objective: { cell: objRef, sense, formula: objFormulaClean },
                  variables,
                  constraints,
                }),
              });
              const data = await res.json();
              if (data.error) { body.querySelector('#_svOut').textContent = 'Error: ' + data.error; return false; }
              if (data.status && data.status.toLowerCase().includes('optimal')) {
                for (const v of variables) cells[v.cell] = { v: data.values[v.name] };
                this.engine.setCells(cells);
                this._draw();
                body.querySelector('#_svOut').textContent = `Optimal — objective = ${data.objective}`;
                this._snapshot('solver');
              } else {
                body.querySelector('#_svOut').textContent = `Status: ${data.status || 'Infeasible'}`;
              }
            } catch (e) {
              body.querySelector('#_svOut').textContent = 'Solver error: ' + e.message;
            }
            return false;
          } },
      ],
    });
  }

  _scenarioManagerDialog() {
    const host = document.getElementById('dialogHost');
    const wrap = document.createElement('div');
    wrap.innerHTML = `
      <div>Scenarios are named sets of cell changes.</div>
      <div id="_scList" style="max-height:200px;overflow:auto;margin-top:8px;"></div>
      <button id="_scAdd" style="margin-top:8px;">+ Add Scenario</button>
      <button id="_scSummary" style="margin-top:8px;">Show Summary</button>`;
    const scenarios = this._scenarios;
    const renderList = () => {
      wrap.querySelector('#_scList').innerHTML = scenarios.map((s, i) =>
        `<div style="display:flex;justify-content:space-between;padding:4px 0;border-bottom:1px solid var(--border);">
          <span><strong>${escapeHtml(s.name)}</strong> (${Object.keys(s.changes).length} cells)</span>
          <button data-i="${i}">Delete</button>
        </div>`).join('') || '<div style="color:var(--text-muted);">No scenarios yet.</div>';
      wrap.querySelectorAll('[data-i]').forEach(b => b.onclick = () => { scenarios.splice(Number(b.dataset.i), 1); renderList(); });
    };
    renderList();
    setTimeout(() => {
      wrap.querySelector('#_scAdd').onclick = () => {
        const name = prompt('Scenario name:');
        if (!name) return;
        const changes = {};
        const sel = this._selectionBounds();
        for (let r = sel.r0; r <= sel.r1; r++) for (let c = sel.c0; c <= sel.c1; c++) {
          const ref = colName(c) + (r + 1);
          const cur = this.engine.getValue(ref);
          const newVal = prompt(`${ref} (current: ${cur}):`, String(cur));
          if (newVal !== null) { const num = Number(newVal); changes[ref] = isNaN(num) ? newVal : num; }
        }
        scenarios.push({ name, changes });
        renderList();
      };
      wrap.querySelector('#_scSummary').onclick = () => {
        const resultRef = prompt('Result cell:', this._currentRef());
        if (!resultRef) return;
        const rows = WhatIf.scenariosSummary(this._getCells(), this.sheets, scenarios, [resultRef]);
        alert('Scenario summary:\n' + rows.map(r => `${r.name}: ${r[resultRef]}`).join('\n'));
      };
    }, 0);
    openDialog({ host, title: 'Scenario Manager', content: wrap, buttons: [{ label: 'Close' }] });
  }

  _dataTableDialog() {
    const host = document.getElementById('dialogHost');
    prompt2({
      title: 'Data Table', host,
      fields: [
        { name: 'inputRef', label: 'Input cell', value: '' },
        { name: 'formulaRef', label: 'Result formula cell', value: this._currentRef() },
        { name: 'values', label: 'Values (comma separated)', value: '1,2,3,4,5' },
      ],
    }).then(r => {
      if (!r || !r.inputRef) return;
      const values = r.values.split(',').map(x => Number(x.trim())).filter(x => !isNaN(x));
      const out = WhatIf.oneVariableDataTable(this._getCells(), this.sheets, r.inputRef, r.formulaRef, values);
      const cells = this._getCells();
      const startR = this.selection.end.r;
      const startC = this.selection.end.c;
      values.forEach((v, i) => {
        cells[colName(startC) + (startR + i + 1)] = { v };
        cells[colName(startC + 1) + (startR + i + 1)] = { v: out[i] };
      });
      this.engine.setCells(cells);
      this._snapshot('data table');
      this._draw();
    });
  }

  _forecastSheetDialog() {
    const host = document.getElementById('dialogHost');
    const { r0, r1, c0 } = this._selectionBounds();
    const values = [];
    for (let r = r0; r <= r1; r++) values.push(Number(this.engine.getValue(colName(c0) + (r + 1))) || 0);
    prompt2({
      title: 'Forecast Sheet', host,
      fields: [{ name: 'periods', label: 'Forecast periods', value: '6' }],
    }).then(r => {
      if (!r) return;
      const periods = Number(r.periods);
      const alpha = 0.4, beta = 0.2;
      let level = values[0], trend = values[1] - values[0];
      const forecast = [];
      for (let i = 1; i < values.length; i++) {
        const newLevel = alpha * values[i] + (1 - alpha) * (level + trend);
        const newTrend = beta * (newLevel - level) + (1 - beta) * trend;
        level = newLevel; trend = newTrend;
      }
      for (let i = 0; i < periods; i++) forecast.push(level + trend * (i + 1));
      const cells = this._getCells();
      const outRow = this.selection.end.r + 1;
      cells[colName(c0) + (outRow + 1)] = { v: 'Forecast' };
      forecast.forEach((v, i) => {
        cells[colName(c0 + 1) + (outRow + i + 1)] = { v };
      });
      this.engine.setCells(cells);
      this._snapshot('forecast');
      this._draw();
    });
  }

  _analysisDialog() {
    const host = document.getElementById('dialogHost');
    const wrap = document.createElement('div');
    const tools = [
      ['descriptive', 'Descriptive Statistics'],
      ['histogram', 'Histogram'],
      ['regression', 'Regression'],
      ['correlation', 'Correlation'],
      ['covariance', 'Covariance'],
      ['ttest_paired', 't-Test: Paired Two Sample'],
      ['ttest_2sample', 't-Test: Two-Sample'],
      ['ftest', 'F-Test Two-Sample'],
      ['moving_average', 'Moving Average'],
      ['exp_smoothing', 'Exponential Smoothing'],
      ['rank_percentile', 'Rank and Percentile'],
      ['sampling', 'Sampling'],
      ['fourier', 'Fourier Analysis'],
    ];
    wrap.innerHTML = `
      <label>Tool: <select id="_atTool" style="padding:4px;">${tools.map(([v, l]) => `<option value="${v}">${l}</option>`).join('')}</select></label>
      <label style="display:block;margin-top:8px;">Input range: <input id="_atRange" style="width:100%;padding:4px;"></label>
      <div id="_atParams" style="margin-top:8px;"></div>
      <div id="_atOut" style="margin-top:8px;color:var(--text-muted);"></div>`;
    setTimeout(() => {
      const params = wrap.querySelector('#_atParams');
      const update = () => {
        const tool = wrap.querySelector('#_atTool').value;
        if (['regression', 'ttest_paired', 'ttest_2sample', 'ftest'].includes(tool)) {
          params.innerHTML = `<label>Y range: <input id="_atY" style="width:100%;padding:4px;"></label>
                              <label style="display:block;margin-top:4px;">X range: <input id="_atX" style="width:100%;padding:4px;"></label>`;
        } else if (tool === 'moving_average') {
          params.innerHTML = `<label>Period: <input id="_atPeriod" type="number" value="3" style="padding:4px;"></label>`;
        } else if (tool === 'exp_smoothing') {
          params.innerHTML = `<label>Alpha: <input id="_atAlpha" type="number" value="0.3" step="0.05" style="padding:4px;"></label>`;
        } else if (tool === 'histogram') {
          params.innerHTML = `<label>Bins: <input id="_atBins" type="number" value="10" style="padding:4px;"></label>`;
        } else {
          params.innerHTML = '';
        }
      };
      wrap.querySelector('#_atTool').onchange = update;
      update();
    }, 0);
    openDialog({
      host, title: 'Data Analysis', content: wrap,
      buttons: [
        { label: 'Cancel' },
        { label: 'Run', primary: true, close: false, onClick: async (body) => {
            const tool = body.querySelector('#_atTool').value;
            const range = body.querySelector('#_atRange').value.trim();
            let params = {};
            if (range) {
              const data = this._readRangeValues(range);
              if (['regression', 'ttest_paired', 'ttest_2sample', 'ftest'].includes(tool)) {
                params.y = this._readRangeValues(body.querySelector('#_atY').value);
                params.x = this._readRangeValues(body.querySelector('#_atX').value);
                if (tool !== 'regression') { params.a = params.y; params.b = params.x; delete params.y; delete params.x; }
              } else {
                params.data = data;
              }
            }
            if (tool === 'histogram') params.bins = Number(body.querySelector('#_atBins').value);
            if (tool === 'moving_average') params.period = Number(body.querySelector('#_atPeriod').value);
            if (tool === 'exp_smoothing') params.alpha = Number(body.querySelector('#_atAlpha').value);
            try {
              const res = await api._fetch('/api/analyze/toolpak', { method: 'POST', body: JSON.stringify({ tool, params }) });
              const data = await res.json();
              body.querySelector('#_atOut').innerHTML = `<pre style="font-size:11px;background:#fafafa;padding:8px;border-radius:4px;max-height:220px;overflow:auto;">${escapeHtml(JSON.stringify(data, null, 2))}</pre>`;
            } catch (e) {
              body.querySelector('#_atOut').textContent = 'Error: ' + e.message;
            }
            return false;
          } },
      ],
    });
  }

  _readRangeValues(range) {
    const [c0, r0, c1, r1] = parseRange(range);
    const out = [];
    for (let r = r0; r <= r1; r++) for (let c = c0; c <= c1; c++) out.push(Number(this.engine.getValue(colName(c) + (r + 1))) || 0);
    return out;
  }

  _powerQueryDialog() {
    const host = document.getElementById('dialogHost');
    const wrap = document.createElement('div');
    wrap.style.cssText = 'min-width:600px;';
    wrap.innerHTML = `
      <div style="display:grid;grid-template-columns:200px 1fr;gap:12px;height:400px;">
        <div>
          <div style="font-weight:600;margin-bottom:6px;">Applied Steps</div>
          <div id="_pqSteps"></div>
          <button id="_pqAdd" style="margin-top:8px;">+ Add Step</button>
        </div>
        <div id="_pqPreview" style="overflow:auto;border:1px solid var(--border);border-radius:4px;"></div>
      </div>`;
    const { r0, r1, c0, c1 } = this._selectionBounds();
    const headers = [];
    for (let c = c0; c <= c1; c++) headers.push(String(this.engine.getValue(colName(c) + (r0 + 1))));
    const rows = [];
    for (let r = r0 + 1; r <= r1; r++) {
      const rec = {};
      for (let ci = c0, hi = 0; ci <= c1; ci++, hi++) rec[headers[hi]] = this.engine.getValue(colName(ci) + (r + 1));
      rows.push(rec);
    }
    const state = { steps: [] };
    const render = async () => {
      wrap.querySelector('#_pqSteps').innerHTML = state.steps.map((s, i) =>
        `<div style="padding:4px;border-bottom:1px solid var(--border);font-size:12px;">
          <span style="color:var(--text-muted);">${i+1}.</span> ${escapeHtml(s.label || s.kind)}
          <button data-i="${i}" style="float:right;font-size:10px;">×</button>
        </div>`).join('') || '<div style="color:var(--text-muted);">No steps</div>';
      wrap.querySelectorAll('[data-i]').forEach(b => b.onclick = () => { state.steps.splice(Number(b.dataset.i), 1); render(); });
      try {
        const res = await api._fetch('/api/analyze/query', { method: 'POST', body: JSON.stringify({ table: rows, steps: state.steps }) });
        const data = await res.json();
        const preview = (data.rows || []).slice(0, 50);
        if (!preview.length) { wrap.querySelector('#_pqPreview').innerHTML = '<div style="padding:8px;color:var(--text-muted);">Empty</div>'; return; }
        const cols = Object.keys(preview[0]);
        wrap.querySelector('#_pqPreview').innerHTML = `
          <table style="border-collapse:collapse;width:100%;font-size:11px;">
            <tr>${cols.map(c => `<th style="border:1px solid var(--border);padding:3px 6px;background:#f5f5f5;">${escapeHtml(c)}</th>`).join('')}</tr>
            ${preview.map(row => `<tr>${cols.map(c => `<td style="border:1px solid var(--border);padding:3px 6px;">${escapeHtml(String(row[c] ?? ''))}</td>`).join('')}</tr>`).join('')}
          </table>`;
      } catch (e) {
        wrap.querySelector('#_pqPreview').innerHTML = '<div style="padding:8px;color:#c00;">' + escapeHtml(e.message) + '</div>';
      }
    };
    render();
    setTimeout(() => {
      wrap.querySelector('#_pqAdd').onclick = () => {
        const kind = prompt('Step kind:\nfilter_rows, choose_columns, remove_columns, rename_column, change_type, replace_value, fill_down, fill_up, split_column, merge_columns, group_by, sort, pivot, unpivot, custom_column, limit:');
        if (!kind) return;
        const json = prompt('Parameters (JSON):', '{}');
        if (json === null) return;
        try {
          const params = JSON.parse(json);
          state.steps.push({ kind, ...params, label: kind });
          render();
        } catch (e) { alert('Invalid JSON'); }
      };
    }, 0);
    openDialog({
      host, title: 'Get & Transform (Power Query)', content: wrap,
      buttons: [
        { label: 'Cancel' },
        { label: 'Load', primary: true, onClick: async () => {
            const res = await api._fetch('/api/analyze/query', { method: 'POST', body: JSON.stringify({ table: rows, steps: state.steps }) });
            const data = await res.json();
            const cells = this._getCells();
            const startR = r1 + 2;
            const outRows = data.rows || [];
            if (!outRows.length) return;
            const cols = Object.keys(outRows[0]);
            cols.forEach((c, ci) => cells[colName(c0 + ci) + (startR + 1)] = { v: c });
            outRows.forEach((row, ri) => cols.forEach((c, ci) => cells[colName(c0 + ci) + (startR + ri + 2)] = { v: row[c] }));
            this.engine.setCells(cells);
            this._snapshot('power query load');
            this._draw();
          } },
      ],
    });
  }

  _sparklineDialog() {
    const host = document.getElementById('dialogHost');
    const wrap = document.createElement('div');
    wrap.innerHTML = `
      <label>Data range: <input id="_spData" style="width:100%;padding:4px;"></label>
      <label style="display:block;margin-top:8px;">Location cell: <input id="_spCell" value="${this._currentRef()}" style="padding:4px;"></label>
      <label style="display:block;margin-top:8px;">Type:
        <select id="_spType"><option>line</option><option>column</option><option>winloss</option></select>
      </label>`;
    openDialog({
      host, title: 'Sparklines', content: wrap,
      buttons: [
        { label: 'Cancel' },
        { label: 'Insert', primary: true, onClick: (body) => {
            const values = this._readRangeValues(body.querySelector('#_spData').value.trim());
            const cell = body.querySelector('#_spCell').value.trim();
            const type = body.querySelector('#_spType').value;
            const cells = this._getCells();
            cells[cell] = cells[cell] || {};
            cells[cell].sparkline = { type, values };
            this.engine.setCells(cells);
            this._snapshot('insert sparkline');
            this._draw();
          } },
      ],
    });
  }

  _setupSheetTabs() {
    document.getElementById('addSheet')?.addEventListener('click', () => {
      this.sheets.push({ name: `Sheet${this.sheets.length + 1}`, cells: {}, colWidths: {}, rowHeights: {}, merges: [], frozen: {}, cf: [], validations: [], charts: [], namedRanges: [], tables: [] });
      this.activeSheet = this.sheets.length - 1;
      this.engine.setSheets(this.sheets);
      this.engine.setCells(this.sheets[this.activeSheet].cells);
      this._updateSheetTabs();
      this._draw();
      this._snapshot('add sheet');
    });
  }

  _updateSheetTabs() {
    const host = document.getElementById('sheetTabs');
    [...host.querySelectorAll('.sheet-tab')].forEach(n => n.remove());
    this.sheets.forEach((s, i) => {
      const b = document.createElement('button');
      b.className = 'sheet-tab' + (i === this.activeSheet ? ' active' : '');
      b.textContent = s.name;
      b.onclick = () => {
        this.activeSheet = i;
        this.engine.setSheets(this.sheets);
        this.engine.setCells(s.cells);
        this._updateSheetTabs();
        this._draw();
      };
      b.oncontextmenu = (e) => {
        e.preventDefault();
        showContextMenu(document.getElementById('contextMenu'), e.clientX, e.clientY, [
          { label: 'Rename', action: async () => {
              const r = await prompt2({ title: 'Rename Sheet', host: document.getElementById('dialogHost'), fields: [{ name: 'name', label: 'Name', value: s.name }] });
              if (r?.name) { s.name = r.name; this._updateSheetTabs(); }
          }},
          { label: 'Duplicate', action: () => {
              const copy = JSON.parse(JSON.stringify(s));
              copy.name = s.name + ' (2)';
              this.sheets.splice(i + 1, 0, copy);
              this.engine.setSheets(this.sheets);
              this._updateSheetTabs();
              this._snapshot('duplicate sheet');
          }},
          { label: 'Delete', action: () => {
              if (this.sheets.length > 1 && confirm(`Delete "${s.name}"?`)) {
                this.sheets.splice(i, 1);
                this.activeSheet = 0;
                this.engine.setSheets(this.sheets);
                this.engine.setCells(this.sheets[0].cells);
                this._updateSheetTabs(); this._draw();
              }
          }},
        ]);
      };
      host.insertBefore(b, document.getElementById('addSheet'));
    });
  }

  _setupStatusbar() {
    const zoomRange = document.getElementById('zoomRange');
    const zoomLabel = document.getElementById('zoomLabel');
    zoomRange?.addEventListener('input', (e) => {
      const v = e.target.value;
      zoomLabel.textContent = v + '%';
      this.canvas.style.transformOrigin = '0 0';
      this.canvas.style.transform = `scale(${v / 100})`;
    });
  }

  _setupShortcuts() {
    const sc = new Shortcuts({
      'ctrl+s': (e) => { e.preventDefault(); this.saveNow(); },
      'ctrl+z': (e) => { e.preventDefault(); this.history.undo(); this._draw(); },
      'ctrl+y': (e) => { e.preventDefault(); this.history.redo(); this._draw(); },
      'ctrl+b': () => this.command('bold', true),
      'ctrl+i': () => this.command('italic', true),
      'ctrl+u': () => this.command('underline', true),
      'ctrl+f': (e) => { e.preventDefault(); this._showFind(); },
      'ctrl+h': (e) => { e.preventDefault(); this._showFind(); },
      'ctrl+`': (e) => { e.preventDefault(); this.showFormulas = !this.showFormulas; this._draw(); },
      'f2': () => this._startEdit(this.selection.end.r, this.selection.end.c, null, true),
      'delete': () => this.command('clearContents'),
      'f9': () => this.command('recalcAll'),
    });
    sc.bind();
  }

  _setupContextMenu() { /* inline */ }

  _gridContextMenu(e) {
    e.preventDefault();
    const host = document.getElementById('contextMenu');
    showContextMenu(host, e.clientX, e.clientY, [
      { label: 'Cut', shortcut: 'Ctrl+X', action: () => document.execCommand('cut') },
      { label: 'Copy', shortcut: 'Ctrl+C', action: () => document.execCommand('copy') },
      { label: 'Paste', shortcut: 'Ctrl+V', action: () => document.execCommand('paste') },
      { label: 'Paste Special…', action: () => this.command('pasteSpecial') },
      { sep: true },
      { label: 'Clear Contents', action: () => this.command('clearContents') },
      { label: 'Format Cells…', action: () => this.command('format') },
      { label: 'Data Validation…', action: () => this.command('dataValidation') },
      { label: 'Conditional Formatting…', action: () => this.command('condfmt') },
      { sep: true },
      { label: 'Insert Function…', action: () => this.command('insertFunction') },
      { label: 'Trace Precedents', action: () => this.command('tracePrecedents') },
      { label: 'Trace Dependents', action: () => this.command('traceDependents') },
      { sep: true },
      { label: 'Sort A → Z', action: () => this.command('sort', 'asc') },
      { label: 'Sort Z → A', action: () => this.command('sort', 'desc') },
      { label: 'Filter…', action: () => this.command('filter') },
    ]);
  }

  _setupAutosave() {
    this.autosaver = new AutoSaver({
      getId: () => this.docId,
      getModel: () => this._serialize(),
      save: async (id, model) => { if (id) await api.updateDoc(id, this.titleEl.value, model); },
    });
    this.autosaver.onStatus(s => { const el = document.getElementById('saveStatus'); if (el) el.textContent = s; });
  }

  async saveNow() {
    const model = this._serialize();
    if (!this.docId) {
      try {
        const c = await api.createDoc('sheets', this.titleEl.value, model);
        this.docId = c.id; history.replaceState(null, '', `?id=${this.docId}`);
      } catch (e) { console.warn('save failed', e); }
    } else {
      try { await api.updateDoc(this.docId, this.titleEl.value, model); } catch (e) { console.warn(e); }
    }
    await storage.put(this.docId || 'draft-sheets', model);
  }

  _serialize() {
    return {
      meta: { title: this.titleEl.value },
      sheets: this.sheets.map(s => ({
        name: s.name, cells: s.cells,
        colWidths: s.colWidths || {}, rowHeights: s.rowHeights || {},
        merges: s.merges || [], cf: s.cf || [],
        validations: s.validations || [], charts: s.charts || [],
        frozen: s.frozen || {}, hyperlinks: s.hyperlinks || {},
        comments: s.comments || {}, namedRanges: s.namedRanges || [],
        tables: s.tables || [],
      })),
      namedRanges: [],
      schemaVersion: 4,
    };
  }

  async _loadDoc() {
    try {
      const d = await api.getDoc(this.docId);
      this.titleEl.value = d.name || 'Untitled';
      if (d.data?.sheets?.length) {
        this.sheets = d.data.sheets;
        this.activeSheet = 0;
        this.engine.setSheets(this.sheets);
        this.engine.setCells(this.sheets[0].cells);
        this.engine.setNamedRanges(this._getNamedRanges());
        this.engine.setTables(this._getTables());
      }
    } catch (e) {
      const j = await storage.get(this.docId);
      if (j?.data?.sheets) {
        this.sheets = j.data.sheets;
        this.engine.setSheets(this.sheets);
        this.engine.setCells(this.sheets[0].cells);
      }
    }
  }

  _setupBackstage() {
    const host = document.getElementById('backstage');
    this.backstage = new Backstage({
      host,
      title: () => this.titleEl.value,
      onSave: () => this.saveNow(),
      onExport: async (fmt) => {
        const blob = await api.exportDoc('sheets', fmt, this._serialize(), this.titleEl.value || 'spreadsheet');
        await api.downloadBlob(blob, `${this.titleEl.value || 'spreadsheet'}.${fmt}`);
      },
    });
    window.addEventListener('ribbon:backstage', () => this.backstage.open('home'));
    document.getElementById('exportBtn')?.addEventListener('click', () => this.backstage.open('export'));
  }

  _setupTellMe() {
    new TellMe({
      ribbonConfig: excelRibbon,
      host: document.getElementById('tellMeResults') || document.body,
      onRun: (cmd) => this.command(cmd.id, cmd.value),
    });
  }
}

// ---------- helpers ----------
function colName(c) {
  let s = ''; c++;
  while (c > 0) { const m = (c - 1) % 26; s = String.fromCharCode(65 + m) + s; c = Math.floor((c - 1) / 26); }
  return s;
}
function colIdx(name) {
  let n = 0;
  for (const ch of name.toUpperCase()) n = n * 26 + (ch.charCodeAt(0) - 64);
  return n - 1;
}
function css(varName) { return getComputedStyle(document.documentElement).getPropertyValue(varName).trim(); }
function escapeHtml(s) { return String(s ?? '').replace(/[&<>"']/g, c => ({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' }[c])); }
function escapeAttr(s) { return escapeHtml(s).replace(/"/g, '&quot;'); }

function parseRange(range) {
  range = (range || '').replace(/\$/g, '');
  const m = range.match(/^([A-Z]+)(\d+):([A-Z]+)(\d+)$/);
  if (!m) {
    const m2 = range.match(/^([A-Z]+)(\d+)$/);
    if (!m2) return [0, 0, 0, 0];
    const c = colIdx(m2[1]), r = parseInt(m2[2], 10) - 1;
    return [c, r, c, r];
  }
  return [colIdx(m[1]), parseInt(m[2], 10) - 1, colIdx(m[3]), parseInt(m[4], 10) - 1];
}

function buildSumExpression(range) {
  const [c0, r0, c1, r1] = parseRange(range);
  const refs = [];
  for (let r = r0; r <= r1; r++) for (let c = c0; c <= c1; c++) {
    refs.push(`${colName(c)}${r + 1}`.replace(/[^A-Za-z0-9]/g, '_'));
  }
  return refs.join(' + ');
}

function formatPivotCell(cell) {
  if (Array.isArray(cell)) return cell.map(v => Number(v).toFixed(2)).join(', ');
  return Number(cell).toFixed(2);
}

function mapChartType(t) {
  return { column: 'bar', bar: 'bar', line: 'line', pie: 'pie', scatter: 'scatter', area: 'line', doughnut: 'doughnut', radar: 'radar' }[t] || 'bar';
}

function drawSparkline(ctx, x, y, w, h, spec) {
  const vals = spec.values;
  if (!vals.length) return;
  const min = Math.min(...vals), max = Math.max(...vals);
  const scale = max === min ? 1 : h / (max - min);
  const step = w / Math.max(vals.length - 1, 1);
  ctx.save();
  ctx.strokeStyle = spec.color || '#217346';
  ctx.lineWidth = 1.4;
  if (spec.type === 'line') {
    ctx.beginPath();
    vals.forEach((v, i) => {
      const px = x + i * step;
      const py = y + h - (v - min) * scale;
      if (i === 0) ctx.moveTo(px, py); else ctx.lineTo(px, py);
    });
    ctx.stroke();
  } else if (spec.type === 'column') {
    vals.forEach((v, i) => {
      const bh = (v - min) * scale + 1;
      ctx.fillStyle = spec.color || '#217346';
      ctx.fillRect(x + i * step, y + h - bh, Math.max(1, step - 1), bh);
    });
  } else if (spec.type === 'winloss') {
    vals.forEach((v, i) => {
      ctx.fillStyle = v >= 0 ? (spec.color || '#217346') : '#d24726';
      ctx.fillRect(x + i * step, y, Math.max(1, step - 1), h);
    });
  }
  ctx.restore();
}

function inferSeries(values) {
  if (!values.length) return { kind: 'number', start: 0, step: 1 };
  if (typeof values[0] === 'number') {
    if (values.length === 1) return { kind: 'number', start: values[0], step: 1 };
    return { kind: 'number', start: values[0], step: values[1] - values[0] };
  }
  const uniq = [...new Set(values)];
  return { kind: 'text', values: uniq };
}

function evaluateCF(cfRules, engine, cells, r, c) {
  for (const rule of cfRules || []) {
    if (!_refInRange(rule.range, r, c)) continue;
    if (rule.type === 'cell') {
      const v = engine.getValue(colName(c) + (r + 1));
      const num = Number(v);
      const target = Number(rule.value);
      const ok = rule.criteria === '>'  ? num > target
              : rule.criteria === '<'  ? num < target
              : rule.criteria === '>=' ? num >= target
              : rule.criteria === '<=' ? num <= target
              : rule.criteria === '='  ? num === target
              : rule.criteria === '<>' ? num !== target
              : false;
      if (ok) return rule.format || {};
    } else if (rule.type === 'colorScale' || rule.type === 'dataBar') {
      return { fill: rule.color || '#c6efce' };
    }
  }
  return null;
}

function _refInRange(range, r, c) {
  const m = range.replace(/\$/g, '').match(/^([A-Z]+)(\d+):([A-Z]+)(\d+)$/);
  if (!m) {
    const single = range.replace(/\$/g, '').match(/^([A-Z]+)(\d+)$/);
    if (!single) return false;
    return colIdx(single[1]) === c && (parseInt(single[2], 10) - 1) === r;
  }
  const c0 = colIdx(m[1]), r0 = parseInt(m[2], 10) - 1;
  const c1 = colIdx(m[3]), r1 = parseInt(m[4], 10) - 1;
  return c >= Math.min(c0, c1) && c <= Math.max(c0, c1) && r >= Math.min(r0, r1) && r <= Math.max(r0, r1);
}