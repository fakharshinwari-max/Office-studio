/** Pivot table engine. */
export class PivotEngine {
  static compute(rows, spec) {
    const { rows: rowFields = [], cols: colFields = [], values = [] } = spec;
    const filtered = this._filter(rows, spec.filters || []);
    const rowKey = (r) => rowFields.map(f => r[f]).join('\u0001');
    const colKey = (r) => colFields.map(f => r[f]).join('\u0001');
    const rowSet = new Set();
    const colSet = new Set();
    const buckets = new Map();

    for (const r of filtered) {
      const rk = rowKey(r), ck = colKey(r);
      rowSet.add(rk); colSet.add(ck);
      const k = rk + '\u0002' + ck;
      if (!buckets.has(k)) buckets.set(k, []);
      buckets.get(k).push(r);
    }

    const rowVals = [...rowSet].map(k => k.split('\u0001'));
    const colVals = [...colSet].map(k => k.split('\u0001'));

    const matrix = rowVals.map(rv =>
      colVals.map(cv => {
        const k = rv.join('\u0001') + '\u0002' + cv.join('\u0001');
        const recs = buckets.get(k) || [];
        return values.map(v => this._aggregate(recs.map(r => Number(r[v.field]) || 0), v.agg));
      })
    );

    const rowTotals = matrix.map(row =>
      row.reduce((sum, cell) => sum + cell.reduce((a, b) => a + (typeof b === 'number' ? b : 0), 0), 0)
    );

    const colTotals = colVals.map((_, ci) =>
      rowVals.reduce((sum, __, ri) => sum + matrix[ri][ci].reduce((a, b) => a + (typeof b === 'number' ? b : 0), 0), 0)
    );

    const grandTotal = colTotals.reduce((a, b) => a + b, 0);
    return { rowVals, colVals, matrix, rowTotals, colTotals, grandTotal };
  }

  static _aggregate(nums, agg) {
    if (!nums.length) return 0;
    switch (agg) {
      case 'sum':     return nums.reduce((a, b) => a + b, 0);
      case 'count':   return nums.length;
      case 'average': return nums.reduce((a, b) => a + b, 0) / nums.length;
      case 'min':     return Math.min(...nums);
      case 'max':     return Math.max(...nums);
      case 'product': return nums.reduce((a, b) => a * b, 1);
      case 'stddev': {
        const m = nums.reduce((a, b) => a + b, 0) / nums.length;
        return Math.sqrt(nums.reduce((a, b) => a + (b - m) ** 2, 0) / (nums.length - 1));
      }
      case 'var': {
        const m = nums.reduce((a, b) => a + b, 0) / nums.length;
        return nums.reduce((a, b) => a + (b - m) ** 2, 0) / (nums.length - 1);
      }
      case 'distinct': return new Set(nums).size;
    }
    return 0;
  }

  static _filter(rows, filters) {
    for (const f of filters) {
      rows = rows.filter(r => {
        const v = r[f.field];
        if (f.op === '=')  return v == f.value;
        if (f.op === '!=') return v != f.value;
        if (f.op === '>')  return Number(v) > Number(f.value);
        if (f.op === '<')  return Number(v) < Number(f.value);
        if (f.op === 'contains') return String(v).includes(String(f.value));
        return true;
      });
    }
    return rows;
  }
}