/** What-if analysis: Goal Seek, Scenarios, Data Tables. */
import { FormulaEngine } from './formula-engine.js';

export const WhatIf = {
  goalSeek(cells, sheets, setCellRef, targetValue, byChangingRef) {
    const evalAt = (x) => {
      const snapshot = JSON.parse(JSON.stringify(cells));
      snapshot[byChangingRef] = { v: x };
      const e = new FormulaEngine(snapshot, sheets);
      return Number(e.getValue(setCellRef));
    };
    let lo = -1e9, hi = 1e9;
    let flo = evalAt(lo) - targetValue;
    let fhi = evalAt(hi) - targetValue;
    if (flo * fhi > 0) {
      lo = -1e12; hi = 1e12;
      flo = evalAt(lo) - targetValue;
      fhi = evalAt(hi) - targetValue;
      if (flo * fhi > 0) return { error: 'No sign change found' };
    }
    for (let i = 0; i < 100; i++) {
      const mid = (lo + hi) / 2;
      const fm = evalAt(mid) - targetValue;
      if (Math.abs(fm) < 1e-8) return { value: mid, iterations: i };
      if (fm * flo < 0) { hi = mid; fhi = fm; }
      else { lo = mid; flo = fm; }
    }
    return { value: (lo + hi) / 2, iterations: 100 };
  },

  oneVariableDataTable(cells, sheets, inputRef, formulaRef, values) {
    const out = [];
    for (const v of values) {
      const snapshot = JSON.parse(JSON.stringify(cells));
      snapshot[inputRef] = { v };
      const e = new FormulaEngine(snapshot, sheets);
      out.push(Number(e.getValue(formulaRef)));
    }
    return out;
  },

  twoVariableDataTable(cells, sheets, rowInputRef, colInputRef, formulaRef, rowValues, colValues) {
    const matrix = [];
    for (const rv of rowValues) {
      const row = [];
      for (const cv of colValues) {
        const snapshot = JSON.parse(JSON.stringify(cells));
        snapshot[rowInputRef] = { v: rv };
        snapshot[colInputRef] = { v: cv };
        const e = new FormulaEngine(snapshot, sheets);
        row.push(Number(e.getValue(formulaRef)));
      }
      matrix.push(row);
    }
    return matrix;
  },

  scenariosSummary(cells, sheets, scenarios, resultCells) {
    const rows = [];
    for (const s of scenarios) {
      const snapshot = JSON.parse(JSON.stringify(cells));
      for (const [ref, v] of Object.entries(s.changes)) snapshot[ref] = { v };
      const e = new FormulaEngine(snapshot, sheets);
      const row = { name: s.name };
      for (const rc of resultCells) row[rc] = e.getValue(rc);
      rows.push(row);
    }
    return rows;
  },
};