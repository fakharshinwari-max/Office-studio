/**
 * Sheets formula engine — tokenizer, parser, evaluator with dependency graph.
 * Tier-1 functions: ~160.
 */

const ERR = {
  DIV0: '#DIV/0!',
  REF: '#REF!',
  NAME: '#NAME?',
  VALUE: '#VALUE!',
  NUM: '#NUM!',
  NA: '#N/A',
  NULL: '#NULL!',
  SPILL: '#SPILL!',
  CALC: '#CALC!',
};

export class FormulaEngine {
  constructor(cells = {}, sheets = []) {
    this.cells = cells;
    this.sheets = sheets;
    this.calcMode = 'auto';
    this._cache = new Map();       // normalized formula -> compiled fn
    this._valueCache = new Map();  // ref -> last computed value
    this._visiting = new Set();    // circular reference detection
    this._deps = new Map();        // ref -> Set of refs it depends on
    this._revDeps = new Map();     // ref -> Set of refs that depend on it
  }

  setCells(cells) { this.cells = cells; this._valueCache.clear(); this.rebuildDeps(); }
  setSheets(sheets) { this.sheets = sheets; }

  rebuildDeps() {
    this._deps.clear(); this._revDeps.clear();
    for (const ref in this.cells) {
      const c = this.cells[ref];
      if (c.f) {
        try {
          const refs = extractRefs(c.f);
          this._deps.set(ref, new Set(refs));
          for (const r of refs) {
            if (!this._revDeps.has(r)) this._revDeps.set(r, new Set());
            this._revDeps.get(r).add(ref);
          }
        } catch {}
      }
    }
  }

  recalcAll() { this._valueCache.clear(); for (const ref in this.cells) this.getValue(ref); }

  getValue(ref) {
    if (this._valueCache.has(ref)) return this._valueCache.get(ref);
    const cell = this.cells[ref];
    if (!cell) { this._valueCache.set(ref, 0); return 0; }
    if (cell.f) {
      if (this._visiting.has(ref)) {
        this._valueCache.set(ref, ERR.REF);
        return ERR.REF;
      }
      this._visiting.add(ref);
      try {
        const v = this._evalFormula(cell.f, ref);
        this._valueCache.set(ref, v);
        return v;
      } catch (e) {
        this._valueCache.set(ref, e.code || ERR.VALUE);
        return e.code || ERR.VALUE;
      } finally {
        this._visiting.delete(ref);
      }
    }
    const v = cell.v ?? 0;
    this._valueCache.set(ref, v);
    return v;
  }

  getDisplayValue(ref) {
    const v = this.getValue(ref);
    const cell = this.cells[ref];
    if (cell?.s?.numfmt) {
      return tryNumberFormat(v, cell.s.numfmt);
    }
    if (typeof v === 'number') {
      if (Number.isInteger(v)) return v;
      return parseFloat(v.toFixed(10));
    }
    return v;
  }

  _evalFormula(f, selfRef) {
    const ast = this._parseCached(f);
    const scope = { engine: this, selfRef };
    return evaluate(ast, scope);
  }

  _parseCached(f) {
    const key = f.replace(/\s+/g, '');
    if (this._cache.has(key)) return this._cache.get(key);
    const ast = parseFormula(f);
    this._cache.set(key, ast);
    return ast;
  }
}

// ---------------- Tokenizer ----------------
function tokenize(src) {
  const out = [];
  let i = 0;
  const isDigit = c => c >= '0' && c <= '9';
  const isAlpha = c => (c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') || c === '_' || c === '$';
  while (i < src.length) {
    const c = src[i];
    if (c === ' ' || c === '\t') { i++; continue; }
    if (isDigit(c) || (c === '.' && isDigit(src[i+1]))) {
      let j = i;
      while (j < src.length && (isDigit(src[j]) || src[j] === '.' || src[j] === 'e' || src[j] === 'E' || ((src[j] === '+' || src[j] === '-') && (src[j-1] === 'e' || src[j-1] === 'E')))) j++;
      out.push({ t: 'num', v: parseFloat(src.slice(i, j)) });
      i = j; continue;
    }
    if (c === '"') {
      let j = i + 1, v = '';
      while (j < src.length && src[j] !== '"') { v += src[j]; j++; }
      out.push({ t: 'str', v });
      i = j + 1; continue;
    }
    if (isAlpha(c)) {
      let j = i;
      while (j < src.length && (isAlpha(src[j]) || isDigit(src[j]) || src[j] === '.')) j++;
      const word = src.slice(i, j);
      out.push({ t: 'ident', v: word });
      i = j; continue;
    }
    if (c === '<' && src[i+1] === '=') { out.push({t:'op', v:'<='}); i += 2; continue; }
    if (c === '>' && src[i+1] === '=') { out.push({t:'op', v:'>='}); i += 2; continue; }
    if (c === '<' && src[i+1] === '>') { out.push({t:'op', v:'<>'}); i += 2; continue; }
    if ('+-*/^&%=<>(),:!'.includes(c)) { out.push({t:'op', v:c}); i++; continue; }
    // Unknown char
    i++;
  }
  return out;
}

// ---------------- Parser (recursive descent) ----------------
function parseFormula(f) {
  const src = f.startsWith('=') ? f.slice(1) : f;
  const toks = tokenize(src);
  let pos = 0;
  const peek = () => toks[pos];
  const eat = (v) => { const t = toks[pos]; if (!t || (v && t.v !== v)) throw { code: ERR.VALUE, msg: 'Expected ' + v }; pos++; return t; };

  // grammar: expr -> cmp ; cmp -> concat (('=' | '<' | '>') concat)* ; concat -> addsub ('&' addsub)*
  //          addsub -> muldiv (('+' | '-') muldiv)* ; muldiv -> unary (('*' | '/') unary)*
  //          unary -> '-' unary | pow ; pow -> postfix ('^' unary)* ; postfix -> primary ('%')*
  //          primary -> num | str | funccall | ref | '(' expr ')'
  function expr() {
    let left = concat();
    while (peek() && peek().t === 'op' && '=<>'.includes(peek().v[0])) {
      const op = eat().v; const right = concat();
      left = { type: 'binop', op, left, right };
    }
    return left;
  }
  function concat() {
    let left = addsub();
    while (peek() && peek().v === '&') { eat('&'); const right = addsub(); left = { type: 'binop', op: '&', left, right }; }
    return left;
  }
  function addsub() {
    let left = muldiv();
    while (peek() && (peek().v === '+' || peek().v === '-')) {
      const op = eat().v; const right = muldiv(); left = { type: 'binop', op, left, right };
    }
    return left;
  }
  function muldiv() {
    let left = unary();
    while (peek() && (peek().v === '*' || peek().v === '/')) {
      const op = eat().v; const right = unary(); left = { type: 'binop', op, left, right };
    }
    return left;
  }
  function unary() {
    if (peek() && peek().v === '-') { eat('-'); return { type: 'unary', op: '-', expr: unary() }; }
    if (peek() && peek().v === '+') { eat('+'); return unary(); }
    return pow();
  }
  function pow() {
    let left = postfix();
    if (peek() && peek().v === '^') { eat('^'); const right = unary(); left = { type: 'binop', op: '^', left, right }; }
    return left;
  }
  function postfix() {
    let n = primary();
    while (peek() && peek().v === '%') { eat('%'); n = { type: 'percent', expr: n }; }
    return n;
  }
  function primary() {
    const t = peek();
    if (!t) throw { code: ERR.VALUE, msg: 'Unexpected end' };
    if (t.t === 'num') { pos++; return { type: 'num', value: t.v }; }
    if (t.t === 'str') { pos++; return { type: 'str', value: t.v }; }
    if (t.v === '(') {
      eat('(');
      const e = expr();
      eat(')');
      return e;
    }
    if (t.t === 'ident') {
      pos++;
      // function call?
      if (peek() && peek().v === '(') {
        eat('(');
        const args = [];
        if (!(peek() && peek().v === ')')) {
          args.push(expr());
          while (peek() && peek().v === ',') { eat(','); args.push(expr()); }
        }
        eat(')');
        return { type: 'call', name: t.v.toUpperCase(), args };
      }
      // Sheet reference: SheetName!A1 or A1:B2
      if (peek() && peek().v === '!') {
        eat('!');
        const sheetName = t.v;
        const refT = peek();
        if (refT && refT.t === 'ident') {
          pos++;
          let endRef = refT.v;
          if (peek() && peek().v === ':') {
            eat(':');
            const e2 = peek();
            if (e2 && e2.t === 'ident') { pos++; endRef = endRef + ':' + e2.v; }
          }
          return { type: 'ref', sheet: sheetName, ref: endRef };
        }
      }
      // plain ref A1
      let ref = t.v;
      if (peek() && peek().v === ':') {
        eat(':');
        const e2 = peek();
        if (e2 && e2.t === 'ident') { pos++; ref = ref + ':' + e2.v; }
      }
      // TRUE/FALSE
      if (ref.toUpperCase() === 'TRUE') return { type: 'bool', value: true };
      if (ref.toUpperCase() === 'FALSE') return { type: 'bool', value: false };
      return { type: 'ref', ref };
    }
    throw { code: ERR.VALUE, msg: 'Unexpected token ' + JSON.stringify(t) };
  }

  const ast = expr();
  if (pos !== toks.length) throw { code: ERR.VALUE, msg: 'Unexpected tokens' };
  return ast;
}

// ---------------- Evaluator ----------------
function evaluate(ast, scope) {
  switch (ast.type) {
    case 'num': return ast.value;
    case 'str': return ast.value;
    case 'bool': return ast.value;
    case 'unary': return -toNum(evaluate(ast.expr, scope));
    case 'percent': return toNum(evaluate(ast.expr, scope)) / 100;
    case 'binop': return evalBinop(ast.op, evaluate(ast.left, scope), evaluate(ast.right, scope));
    case 'ref': return resolveRef(ast, scope);
    case 'call': return callFunction(ast.name, ast.args.map(a => evaluate(a, scope)), ast, scope);
  }
}

function evalBinop(op, a, b) {
  switch (op) {
    case '+': return toNum(a) + toNum(b);
    case '-': return toNum(a) - toNum(b);
    case '*': return toNum(a) * toNum(b);
    case '/': { const d = toNum(b); return d === 0 ? ERR.DIV0 : toNum(a) / d; }
    case '^': return Math.pow(toNum(a), toNum(b));
    case '&': return String(a) + String(b);
    case '=': return looseEq(a, b);
    case '<>': return !looseEq(a, b);
    case '<': return compare(a, b) < 0;
    case '>': return compare(a, b) > 0;
    case '<=': return compare(a, b) <= 0;
    case '>=': return compare(a, b) >= 0;
  }
}

function toNum(v) {
  if (typeof v === 'number') return v;
  if (typeof v === 'boolean') return v ? 1 : 0;
  if (v == null || v === '') return 0;
  const n = Number(v);
  if (!isNaN(n)) return n;
  throw { code: ERR.VALUE };
}

function looseEq(a, b) {
  if (typeof a === 'number' && typeof b === 'number') return a === b;
  if (typeof a === 'string' && typeof b === 'string') return a.toLowerCase() === b.toLowerCase();
  if (typeof a === 'boolean' || typeof b === 'boolean') return toNum(a) === toNum(b);
  const an = Number(a), bn = Number(b);
  if (!isNaN(an) && !isNaN(bn)) return an === bn;
  return String(a).toLowerCase() === String(b).toLowerCase();
}

function compare(a, b) {
  const an = Number(a), bn = Number(b);
  if (!isNaN(an) && !isNaN(bn)) return an - bn;
  return String(a).toLowerCase() < String(b).toLowerCase() ? -1 :
         String(a).toLowerCase() > String(b).toLowerCase() ? 1 : 0;
}

function resolveRef(ast, scope) {
  const engine = scope.engine;
  const ref = ast.ref;
  if (ref.includes(':')) {
    const [a, b] = ref.split(':');
    return expandRange(engine, a, b, ast.sheet);
  }
  const sheet = ast.sheet;
  if (sheet) {
    const s = engine.sheets.find(x => x.name === sheet);
    if (!s) throw { code: ERR.REF };
    return s.cells[ref]?.v ?? 0;
  }
  return engine.getValue(ref);
}

function expandRange(engine, a, b, sheet) {
  const cells = sheet
    ? (engine.sheets.find(x => x.name === sheet)?.cells || {})
    : engine.cells;
  const aM = a.match(/^([A-Z$]+)(\d+)$/);
  const bM = b.match(/^([A-Z$]+)(\d+)$/);
  if (!aM || !bM) throw { code: ERR.REF };
  const c0 = colIdx(aM[1].replace(/\$/g,''));
  const r0 = parseInt(aM[2], 10) - 1;
  const c1 = colIdx(bM[1].replace(/\$/g,''));
  const r1 = parseInt(bM[2], 10) - 1;
  const out = [];
  for (let r = Math.min(r0, r1); r <= Math.max(r0, r1); r++) {
    for (let c = Math.min(c0, c1); c <= Math.max(c0, c1); c++) {
      const ref = colName(c) + (r + 1);
      const cell = cells[ref];
      out.push(cell ? engine.getValue(ref) : 0);
    }
  }
  return out;
}

function extractRefs(f) {
  const toks = tokenize(f.startsWith('=') ? f.slice(1) : f);
  const refs = new Set();
  for (const t of toks) {
    if (t.t === 'ident' && /^[A-Z]+\d+$/i.test(t.v)) refs.add(t.v.toUpperCase());
  }
  return [...refs];
}

// ---------------- Function library (Tier-1 subset) ----------------
function callFunction(name, args, ast, scope) {
  // Flatten ranges passed as args
  const A = args;
  const flat = (x) => Array.isArray(x) ? x.flat(Infinity) : [x];
  const nums = () => A.flatMap(flat).filter(v => typeof v === 'number' && !isNaN(v));
  const anyNums = () => A.flatMap(flat).filter(v => typeof v === 'number' && !isNaN(v) || (typeof v === 'string' && !isNaN(Number(v)))).map(Number);

  switch (name) {
    // Math
    case 'SUM': return nums().reduce((a, b) => a + b, 0);
    case 'PRODUCT': return nums().reduce((a, b) => a * b, 1);
    case 'SUMSQ': return nums().reduce((a, b) => a + b * b, 0);
    case 'ABS': return Math.abs(toNum(A[0]));
    case 'SIGN': return Math.sign(toNum(A[0]));
    case 'INT': return Math.floor(toNum(A[0]));
    case 'ROUND': {
      const n = toNum(A[0]), d = toNum(A[1] || 0);
      const m = Math.pow(10, d);
      return Math.round((n + Number.EPSILON) * m) / m;
    }
    case 'ROUNDDOWN': { const n = toNum(A[0]), d = toNum(A[1] || 0); const m = Math.pow(10, d); return Math.floor(n * m) / m; }
    case 'ROUNDUP':   { const n = toNum(A[0]), d = toNum(A[1] || 0); const m = Math.pow(10, d); return Math.ceil(n * m) / m; }
    case 'TRUNC':     { const n = toNum(A[0]); return n < 0 ? Math.ceil(n) : Math.floor(n); }
    case 'MOD':       { const a = toNum(A[0]), b = toNum(A[1]); return b === 0 ? ERR.DIV0 : ((a % b) + b) % b; }
    case 'POWER':     return Math.pow(toNum(A[0]), toNum(A[1]));
    case 'SQRT':      { const n = toNum(A[0]); return n < 0 ? ERR.NUM : Math.sqrt(n); }
    case 'EXP':       return Math.exp(toNum(A[0]));
    case 'LN':        return Math.log(toNum(A[0]));
    case 'LOG':       return Math.log(toNum(A[0])) / Math.log(A[1] != null ? toNum(A[1]) : 10);
    case 'LOG10':     return Math.log10(toNum(A[0]));
    case 'PI':        return Math.PI;
    case 'RAND':      return Math.random();
    case 'RANDBETWEEN': { const a = Math.ceil(toNum(A[0])), b = Math.floor(toNum(A[1])); return Math.floor(Math.random() * (b - a + 1)) + a; }
    case 'CEILING':   { const n = toNum(A[0]), s = toNum(A[1] || 1); return Math.ceil(n / s) * s; }
    case 'FLOOR':     { const n = toNum(A[0]), s = toNum(A[1] || 1); return Math.floor(n / s) * s; }
    case 'GCD':       return nums().reduce((a, b) => gcd(a, b));
    case 'LCM':       return nums().reduce((a, b) => (a * b) / gcd(a, b));
    case 'FACT':      return factorial(toNum(A[0]));
    case 'COMBIN':    return factorial(toNum(A[0])) / (factorial(toNum(A[1])) * factorial(toNum(A[0]) - toNum(A[1])));
    case 'DEGREES':   return toNum(A[0]) * 180 / Math.PI;
    case 'RADIANS':   return toNum(A[0]) * Math.PI / 180;
    case 'SIN':       return Math.sin(toNum(A[0]));
    case 'COS':       return Math.cos(toNum(A[0]));
    case 'TAN':       return Math.tan(toNum(A[0]));
    case 'ASIN':      return Math.asin(toNum(A[0]));
    case 'ACOS':      return Math.acos(toNum(A[0]));
    case 'ATAN':      return Math.atan(toNum(A[0]));
    case 'ATAN2':     return Math.atan2(toNum(A[0]), toNum(A[1]));
    case 'SINH':      return Math.sinh(toNum(A[0]));
    case 'COSH':      return Math.cosh(toNum(A[0]));
    case 'TANH':      return Math.tanh(toNum(A[0]));
    case 'EVEN':      return evenOdd(toNum(A[0]), true);
    case 'ODD':       return evenOdd(toNum(A[0]), false);
    case 'MROUND':    { const n = toNum(A[0]), m = toNum(A[1]); return Math.round(n / m) * m; }
    case 'SUMPRODUCT': {
      const rows = A.map(x => Array.isArray(x) ? x : [x]);
      const len = rows[0].length;
      let s = 0;
      for (let i = 0; i < len; i++) {
        let p = 1;
        for (const r of rows) { const v = r[i]; p *= (typeof v === 'number' ? v : Number(v) || 0); }
        s += p;
      }
      return s;
    }
    case 'SUMIF': {
      const range = Array.isArray(A[0]) ? A[0] : [A[0]];
      const crit = A[1];
      const sumRange = A[2] !== undefined ? (Array.isArray(A[2]) ? A[2] : [A[2]]) : range;
      const test = compileCriteria(crit);
      let s = 0;
      for (let i = 0; i < range.length; i++) {
        if (test(range[i])) s += Number(sumRange[i]) || 0;
      }
      return s;
    }
    case 'SUMIFS': {
      const sumRange = Array.isArray(A[0]) ? A[0] : [A[0]];
      let s = 0;
      for (let i = 0; i < sumRange.length; i++) {
        let ok = true;
        for (let k = 1; k < A.length; k += 2) {
          const range = Array.isArray(A[k]) ? A[k] : [A[k]];
          const t = compileCriteria(A[k+1]);
          if (!t(range[i])) { ok = false; break; }
        }
        if (ok) s += Number(sumRange[i]) || 0;
      }
      return s;
    }
    case 'COUNT': return nums().length;
    case 'COUNTA': return A.flatMap(flat).filter(v => v !== '' && v != null).length;
    case 'COUNTBLANK': return A.flatMap(flat).filter(v => v === '' || v == null).length;
    case 'COUNTIF': {
      const range = Array.isArray(A[0]) ? A[0] : [A[0]];
      const t = compileCriteria(A[1]);
      return range.filter(t).length;
    }
    case 'COUNTIFS': {
      const range0 = Array.isArray(A[0]) ? A[0] : [A[0]];
      let cnt = 0;
      for (let i = 0; i < range0.length; i++) {
        let ok = true;
        for (let k = 0; k < A.length; k += 2) {
          const range = Array.isArray(A[k]) ? A[k] : [A[k]];
          const t = compileCriteria(A[k+1]);
          if (!t(range[i])) { ok = false; break; }
        }
        if (ok) cnt++;
      }
      return cnt;
    }

    // Statistical
    case 'AVERAGE': { const n = nums(); return n.length ? n.reduce((a,b)=>a+b,0) / n.length : ERR.DIV0; }
    case 'AVERAGEA': { const n = anyNums(); return n.length ? n.reduce((a,b)=>a+b,0) / n.length : ERR.DIV0; }
    case 'AVERAGEIF': {
      const range = Array.isArray(A[0]) ? A[0] : [A[0]];
      const t = compileCriteria(A[1]);
      const avgRange = A[2] !== undefined ? (Array.isArray(A[2]) ? A[2] : [A[2]]) : range;
      let sum = 0, cnt = 0;
      for (let i = 0; i < range.length; i++) if (t(range[i])) { sum += Number(avgRange[i]) || 0; cnt++; }
      return cnt ? sum / cnt : ERR.DIV0;
    }
    case 'AVERAGEIFS': {
      const avgRange = Array.isArray(A[0]) ? A[0] : [A[0]];
      let sum = 0, cnt = 0;
      for (let i = 0; i < avgRange.length; i++) {
        let ok = true;
        for (let k = 1; k < A.length; k += 2) {
          const range = Array.isArray(A[k]) ? A[k] : [A[k]];
          const t = compileCriteria(A[k+1]);
          if (!t(range[i])) { ok = false; break; }
        }
        if (ok) { sum += Number(avgRange[i]) || 0; cnt++; }
      }
      return cnt ? sum / cnt : ERR.DIV0;
    }
    case 'MIN': { const n = nums(); return n.length ? Math.min(...n) : 0; }
    case 'MAX': { const n = nums(); return n.length ? Math.max(...n) : 0; }
    case 'MINA': { const n = anyNums(); return n.length ? Math.min(...n) : 0; }
    case 'MAXA': { const n = anyNums(); return n.length ? Math.max(...n) : 0; }
    case 'MINIFS': case 'MAXIFS': {
      const valRange = Array.isArray(A[0]) ? A[0] : [A[0]];
      const collect = [];
      for (let i = 0; i < valRange.length; i++) {
        let ok = true;
        for (let k = 1; k < A.length; k += 2) {
          const range = Array.isArray(A[k]) ? A[k] : [A[k]];
          const t = compileCriteria(A[k+1]);
          if (!t(range[i])) { ok = false; break; }
        }
        if (ok && typeof valRange[i] === 'number') collect.push(valRange[i]);
      }
      if (!collect.length) return 0;
      return name === 'MINIFS' ? Math.min(...collect) : Math.max(...collect);
    }
    case 'MEDIAN': {
      const n = nums().sort((a, b) => a - b);
      if (!n.length) return ERR.NUM;
      const m = Math.floor(n.length / 2);
      return n.length % 2 ? n[m] : (n[m-1] + n[m]) / 2;
    }
    case 'MODE': case 'MODE.SNGL': {
      const n = nums();
      const c = new Map();
      let best = null, bestCnt = 0;
      for (const v of n) { const k = c.get(v) || 0; c.set(v, k + 1); if (k + 1 > bestCnt) { bestCnt = k + 1; best = v; } }
      return bestCnt > 1 ? best : ERR.NA;
    }
    case 'STDEV': case 'STDEV.S': return stdev(nums(), 1);
    case 'STDEV.P': return stdev(nums(), 0);
    case 'VAR': case 'VAR.S': return variance(nums(), 1);
    case 'VAR.P': return variance(nums(), 0);
    case 'LARGE': { const n = nums().sort((a,b)=>b-a); const k = toNum(A[A.length-1]); return n[k-1] ?? ERR.NUM; }
    case 'SMALL': { const n = nums().sort((a,b)=>a-b); const k = toNum(A[A.length-1]); return n[k-1] ?? ERR.NUM; }
    case 'RANK': case 'RANK.EQ': {
      const n = toNum(A[0]); const range = anyNums(); const order = A[2] != null ? toNum(A[2]) : 0;
      const sorted = [...range].sort((a,b)=> order ? a-b : b-a);
      return sorted.indexOf(n) + 1;
    }
    case 'PERCENTILE': case 'PERCENTILE.INC': {
      const n = nums().sort((a,b)=>a-b);
      const p = toNum(A[1]);
      return percentileInc(n, p);
    }
    case 'QUARTILE': case 'QUARTILE.INC': {
      const n = nums().sort((a,b)=>a-b);
      const q = toNum(A[1]);
      return percentileInc(n, q / 4);
    }
    case 'CORREL': case 'PEARSON': {
      const x = Array.isArray(A[0]) ? A[0] : [A[0]];
      const y = Array.isArray(A[1]) ? A[1] : [A[1]];
      return correlation(x.map(Number), y.map(Number));
    }
    case 'SLOPE': {
      const y = Array.isArray(A[0]) ? A[0] : [A[0]];
      const x = Array.isArray(A[1]) ? A[1] : [A[1]];
      const { m } = linreg(x.map(Number), y.map(Number));
      return m;
    }
    case 'INTERCEPT': {
      const y = Array.isArray(A[0]) ? A[0] : [A[0]];
      const x = Array.isArray(A[1]) ? A[1] : [A[1]];
      const { m, b } = linreg(x.map(Number), y.map(Number));
      return b;
    }
    case 'ABSENT': return '';

    // Logical
    case 'TRUE': return true;
    case 'FALSE': return false;
    case 'IF': return truthy(A[0]) ? (A[1] ?? true) : (A[2] ?? false);
    case 'IFS': {
      for (let i = 0; i < A.length; i += 2) if (truthy(A[i])) return A[i+1];
      return ERR.NA;
    }
    case 'IFERROR': return isErr(A[0]) ? A[1] : A[0];
    case 'IFNA': return A[0] === ERR.NA ? A[1] : A[0];
    case 'AND': return A.flatMap(flat).every(truthy);
    case 'OR': return A.flatMap(flat).some(truthy);
    case 'XOR': { const t = A.flatMap(flat).filter(truthy).length; return t % 2 === 1; }
    case 'NOT': return !truthy(A[0]);
    case 'SWITCH': {
      const e = A[0];
      for (let i = 1; i < A.length - 1; i += 2) if (looseEq(e, A[i])) return A[i+1];
      return A.length % 2 === 0 ? A[A.length - 1] : ERR.NA;
    }

    // Lookup & Reference
    case 'INDEX': {
      const range = Array.isArray(A[0]) ? A[0] : [A[0]];
      const row = toNum(A[1] || 1), col = toNum(A[2] || 1);
      const cols = A[3] ? toNum(A[3]) : range.length;
      return range[(row - 1) * cols + (col - 1)];
    }
    case 'MATCH': {
      const lookup = A[0];
      const arr = Array.isArray(A[1]) ? A[1] : [A[1]];
      const type = A[2] != null ? toNum(A[2]) : 1;
      for (let i = 0; i < arr.length; i++) if (looseEq(arr[i], lookup)) return i + 1;
      return ERR.NA;
    }
    case 'VLOOKUP': {
      const lookup = A[0];
      const table = A[1];
      const col = toNum(A[2]) - 1;
      const approx = A[3] !== false;
      const rows = Array.isArray(table[0]) ? table : chunk(table, 1);
      for (const r of rows) if (looseEq(r[0], lookup)) return r[col];
      return ERR.NA;
    }
    case 'HLOOKUP': {
      const lookup = A[0];
      const table = Array.isArray(A[1][0]) ? A[1] : [A[1]];
      const row = toNum(A[2]) - 1;
      for (let c = 0; c < table[0].length; c++) if (looseEq(table[0][c], lookup)) return table[row][c];
      return ERR.NA;
    }
    case 'XLOOKUP': {
      const lookup = A[0];
      const lookupArr = Array.isArray(A[1]) ? A[1] : [A[1]];
      const returnArr = Array.isArray(A[2]) ? A[2] : [A[2]];
      const notFound = A[3];
      for (let i = 0; i < lookupArr.length; i++) if (looseEq(lookupArr[i], lookup)) return returnArr[i];
      return notFound !== undefined ? notFound : ERR.NA;
    }
    case 'XMATCH': {
      const lookup = A[0];
      const arr = Array.isArray(A[1]) ? A[1] : [A[1]];
      for (let i = 0; i < arr.length; i++) if (looseEq(arr[i], lookup)) return i + 1;
      return ERR.NA;
    }
    case 'CHOOSE': {
      const idx = toNum(A[0]);
      return A[idx];
    }
    case 'ROW': return 1; // Phase 4: parse ref
    case 'COLUMN': return 1;
    case 'ROWS': return A[0]?.length || 0;
    case 'COLUMNS': return 1;
    case 'TRANSPOSE': {
      const a = A[0];
      if (!Array.isArray(a)) return a;
      return a;
    }
    case 'UNIQUE': {
      const arr = A[0].flat();
      return [...new Set(arr)];
    }
    case 'SORT': {
      const arr = [...A[0]].sort((a, b) => compare(a, b));
      return A[1] === -1 ? arr.reverse() : arr;
    }
    case 'FILTER': {
      const arr = A[0];
      const cond = A[1];
      return arr.filter((_, i) => truthy(cond[i]));
    }
    case 'SEQUENCE': {
      const rows = toNum(A[0]); const cols = toNum(A[1] || 1);
      const start = toNum(A[2] || 1); const step = toNum(A[3] || 1);
      const out = [];
      for (let r = 0; r < rows; r++) for (let c = 0; c < cols; c++) out.push(start + (r * cols + c) * step);
      return out;
    }

    // Text
    case 'CONCAT': case 'CONCATENATE': return A.flatMap(flat).join('');
    case 'TEXTJOIN': {
      const delim = A[0];
      const ignore = A[1];
      const vals = A.slice(2).flatMap(flat);
      const filtered = ignore ? vals.filter(v => v !== '' && v != null) : vals;
      return filtered.join(delim);
    }
    case 'LEFT': return String(A[0]).slice(0, toNum(A[1] || 1));
    case 'RIGHT': return String(A[0]).slice(-toNum(A[1] || 1));
    case 'MID': return String(A[0]).substr(toNum(A[1]) - 1, toNum(A[2]));
    case 'LEN': return String(A[0] ?? '').length;
    case 'TRIM': return String(A[0] ?? '').replace(/\s+/g, ' ').trim();
    case 'UPPER': return String(A[0] ?? '').toUpperCase();
    case 'LOWER': return String(A[0] ?? '').toLowerCase();
    case 'PROPER': return String(A[0] ?? '').replace(/\b\w/g, c => c.toUpperCase());
    case 'REPT': return String(A[0] ?? '').repeat(toNum(A[1]));
    case 'SUBSTITUTE': return String(A[0] ?? '').split(A[1]).join(A[2]);
    case 'REPLACE': {
      const s = String(A[0] ?? ''); const start = toNum(A[1]) - 1;
      const len = toNum(A[2]); const repl = String(A[3]);
      return s.slice(0, start) + repl + s.slice(start + len);
    }
    case 'FIND': case 'SEARCH': {
      const idx = String(A[1]).indexOf(String(A[0]));
      return idx < 0 ? ERR.VALUE : idx + 1;
    }
    case 'EXACT': return String(A[0]) === String(A[1]);
    case 'TEXT': return tryNumberFormat(A[0], String(A[1]));
    case 'VALUE': { const n = Number(A[0]); return isNaN(n) ? ERR.VALUE : n; }
    case 'CHAR': return String.fromCharCode(toNum(A[0]));
    case 'CODE': return String(A[0]).charCodeAt(0);
    case 'TEXTBEFORE': { const s = String(A[0]); const d = String(A[1]); const i = s.indexOf(d); return i < 0 ? ERR.NA : s.slice(0, i); }
    case 'TEXTAFTER': { const s = String(A[0]); const d = String(A[1]); const i = s.indexOf(d); return i < 0 ? ERR.NA : s.slice(i + d.length); }
    case 'TEXTSPLIT': { const s = String(A[0]); const d = String(A[1]); return s.split(d); }
    case 'TEXTJOIN': {
      const delim = A[0];
      const ignore = A[1];
      const vals = A.slice(2).flatMap(flat);
      return (ignore ? vals.filter(v => v !== '') : vals).join(delim);
    }
    case 'DOLLAR': return tryNumberFormat(A[0], `"$"#,##0.00`);
    case 'FIXED': return tryNumberFormat(A[0], `#,##0.${'0'.repeat(toNum(A[1] || 2))}`);

    // Date/Time
    case 'NOW': return excelSerial(new Date());
    case 'TODAY': {
      const d = new Date(); d.setHours(0, 0, 0, 0);
      return excelSerial(d);
    }
    case 'DATE': {
      const y = toNum(A[0]), m = toNum(A[1]), d = toNum(A[2]);
      return excelSerial(new Date(y, m - 1, d));
    }
    case 'YEAR':  return new Date(excelDate(A[0])).getFullYear();
    case 'MONTH': return new Date(excelDate(A[0])).getMonth() + 1;
    case 'DAY':   return new Date(excelDate(A[0])).getDate();
    case 'HOUR':  return new Date(excelDate(A[0])).getHours();
    case 'MINUTE':return new Date(excelDate(A[0])).getMinutes();
    case 'SECOND':return new Date(excelDate(A[0])).getSeconds();
    case 'WEEKDAY': {
      const wd = new Date(excelDate(A[0])).getDay();
      return wd === 0 ? 7 : wd;
    }
    case 'DAYS': {
      return toNum(A[0]) - toNum(A[1]);
    }
    case 'EOMONTH': {
      const d = new Date(excelDate(A[0])); const m = toNum(A[1]);
      const r = new Date(d.getFullYear(), d.getMonth() + m + 1, 0);
      return excelSerial(r);
    }
    case 'EDATE': {
      const d = new Date(excelDate(A[0])); const m = toNum(A[1]);
      const r = new Date(d.getFullYear(), d.getMonth() + m, d.getDate());
      return excelSerial(r);
    }

    // Financial
    case 'PMT': {
      const rate = toNum(A[0]), nper = toNum(A[1]), pv = toNum(A[2]), fv = toNum(A[3] || 0), type = toNum(A[4] || 0);
      if (rate === 0) return -(pv + fv) / nper;
      const pvif = Math.pow(1 + rate, nper);
      return -(rate * (pv * pvif + fv)) / ((pvif - 1) * (1 + rate * type));
    }
    case 'PV': {
      const rate = toNum(A[0]), nper = toNum(A[1]), pmt = toNum(A[2]), fv = toNum(A[3] || 0), type = toNum(A[4] || 0);
      if (rate === 0) return -pmt * nper - fv;
      return -(pmt * (1 + rate * type) * (Math.pow(1 + rate, nper) - 1) / rate + fv) / Math.pow(1 + rate, nper);
    }
    case 'FV': {
      const rate = toNum(A[0]), nper = toNum(A[1]), pmt = toNum(A[2]), pv = toNum(A[3] || 0), type = toNum(A[4] || 0);
      if (rate === 0) return -(pv + pmt * nper);
      return -(pv * Math.pow(1 + rate, nper) + pmt * (1 + rate * type) * (Math.pow(1 + rate, nper) - 1) / rate);
    }
    case 'NPV': {
      const rate = toNum(A[0]);
      const vals = A.slice(1).flatMap(flat).map(Number);
      return vals.reduce((acc, v, i) => acc + v / Math.pow(1 + rate, i + 1), 0);
    }
    case 'IRR': {
      const vals = A[0].map(Number);
      return irr(vals);
    }
    case 'RATE': {
      // Simple numeric solve
      const nper = toNum(A[0]), pmt = toNum(A[1]), pv = toNum(A[2]), fv = toNum(A[3] || 0);
      return 0.05; // placeholder — Phase 4 exact
    }

    // Info
    case 'ISBLANK': return A[0] === '' || A[0] == null;
    case 'ISNUMBER': return typeof A[0] === 'number' && !isNaN(A[0]);
    case 'ISTEXT': return typeof A[0] === 'string';
    case 'ISLOGICAL': return typeof A[0] === 'boolean';
    case 'ISERROR': return isErr(A[0]);
    case 'ISERR': return isErr(A[0]) && A[0] !== ERR.NA;
    case 'ISNA': return A[0] === ERR.NA;
    case 'ISEVEN': return toNum(A[0]) % 2 === 0;
    case 'ISODD': return Math.abs(toNum(A[0]) % 2) === 1;
    case 'NA': return ERR.NA;
    case 'N': return typeof A[0] === 'number' ? A[0] : (A[0] === true ? 1 : 0);
    case 'TYPE': {
      const v = A[0];
      if (typeof v === 'number') return 1;
      if (typeof v === 'string') return 2;
      if (typeof v === 'boolean') return 4;
      if (isErr(v)) return 16;
      return 1;
    }
    case 'ERROR.TYPE': {
      const map = { '#NULL!':1,'#DIV/0!':2,'#VALUE!':3,'#REF!':4,'#NAME?':5,'#NUM!':6,'#N/A':7 };
      return map[A[0]] || ERR.NA;
    }

    // Database (basic)
    case 'DSUM': {
      const db = A[0]; const field = A[1]; const crit = A[2];
      // Very basic: return sum of the field across rows that match the criteria range
      return 0; // Phase 4
    }

    default:
      throw { code: ERR.NAME, msg: `Unknown function ${name}` };
  }
}

// ---------------- Utilities ----------------
function truthy(v) {
  if (typeof v === 'boolean') return v;
  if (typeof v === 'number') return v !== 0;
  if (typeof v === 'string') return v !== '' && v.toLowerCase() !== 'false';
  return !!v;
}
function isErr(v) { return typeof v === 'string' && v.startsWith('#') && v.endsWith('!') || v === '#N/A' || v === '#NAME?'; }
function gcd(a, b) { a = Math.abs(a); b = Math.abs(b); while (b) { [a,b] = [b, a % b]; } return a; }
function factorial(n) { let r = 1; for (let i = 2; i <= n; i++) r *= i; return r; }
function evenOdd(n, even) {
  if (even) return Math.ceil(Math.abs(n) / 2) * 2 * (n < 0 ? -1 : 1);
  return (Math.ceil((Math.abs(n) - 1) / 2) * 2 + 1) * (n < 0 ? -1 : 1);
}
function variance(arr, sample) {
  if (arr.length < (sample ? 2 : 1)) return ERR.DIV0;
  const mean = arr.reduce((a, b) => a + b, 0) / arr.length;
  const sq = arr.reduce((a, b) => a + (b - mean) ** 2, 0);
  return sq / (arr.length - (sample ? 1 : 0));
}
function stdev(arr, sample) { const v = variance(arr, sample); return typeof v === 'number' ? Math.sqrt(v) : v; }
function percentileInc(arr, p) {
  if (!arr.length) return ERR.NUM;
  if (p < 0 || p > 1) return ERR.NUM;
  const idx = (arr.length - 1) * p;
  const lo = Math.floor(idx), hi = Math.ceil(idx);
  if (lo === hi) return arr[lo];
  return arr[lo] + (arr[hi] - arr[lo]) * (idx - lo);
}
function correlation(x, y) {
  const n = Math.min(x.length, y.length);
  const mx = x.slice(0, n).reduce((a,b)=>a+b,0) / n;
  const my = y.slice(0, n).reduce((a,b)=>a+b,0) / n;
  let sxy = 0, sx = 0, sy = 0;
  for (let i = 0; i < n; i++) { const dx = x[i]-mx, dy = y[i]-my; sxy += dx*dy; sx += dx*dx; sy += dy*dy; }
  return sxy / Math.sqrt(sx * sy);
}
function linreg(x, y) {
  const n = Math.min(x.length, y.length);
  const mx = x.slice(0, n).reduce((a,b)=>a+b,0) / n;
  const my = y.slice(0, n).reduce((a,b)=>a+b,0) / n;
  let num = 0, den = 0;
  for (let i = 0; i < n; i++) { num += (x[i]-mx) * (y[i]-my); den += (x[i]-mx) ** 2; }
  const m = num / den;
  const b = my - m * mx;
  return { m, b };
}
function irr(vals) {
  let r = 0.1;
  for (let iter = 0; iter < 100; iter++) {
    const f = vals.reduce((acc, v, i) => acc + v / Math.pow(1 + r, i), 0);
    const df = vals.reduce((acc, v, i) => acc - i * v / Math.pow(1 + r, i + 1), 0);
    const step = f / df;
    r -= step;
    if (Math.abs(step) < 1e-7) break;
  }
  return r;
}
function chunk(arr, n) {
  const out = [];
  for (let i = 0; i < arr.length; i += n) out.push(arr.slice(i, i + n));
  return out;
}
function colIdx(name) {
  let n = 0;
  for (const ch of name.toUpperCase()) n = n * 26 + (ch.charCodeAt(0) - 64);
  return n - 1;
}
function colName(c) {
  let s = ''; c++;
  while (c > 0) { const m = (c - 1) % 26; s = String.fromCharCode(65 + m) + s; c = Math.floor((c - 1) / 26); }
  return s;
}
function excelSerial(d) {
  const epoch = new Date(Date.UTC(1899, 11, 30));
  return (d.getTime() - epoch.getTime()) / (24 * 3600 * 1000);
}
function excelDate(serial) {
  const epoch = new Date(Date.UTC(1899, 11, 30));
  return new Date(epoch.getTime() + serial * 24 * 3600 * 1000);
}
function compileCriteria(crit) {
  if (typeof crit !== 'string') return v => looseEq(v, crit);
  const m = crit.match(/^(<=|>=|<>|=|<|>)?(.*)$/);
  const op = m[1] || '=';
  let val = m[2];
  const num = Number(val);
  if (!isNaN(num) && val !== '') val = num;
  const wildcard = val.toString().includes('*') || val.toString().includes('?');
  const re = wildcard ? new RegExp('^' + val.toString().replace(/[.+^${}()|[\]\\]/g, '\\$&').replace(/\*/g, '.*').replace(/\?/g, '.') + '$', 'i') : null;
  return v => {
    if (re) return re.test(String(v));
    switch (op) {
      case '=': return looseEq(v, val);
      case '<>': return !looseEq(v, val);
      case '<': return compare(v, val) < 0;
      case '>': return compare(v, val) > 0;
      case '<=': return compare(v, val) <= 0;
      case '>=': return compare(v, val) >= 0;
    }
    return false;
  };
}
function tryNumberFormat(v, fmt) {
  if (typeof v !== 'number') return v;
  const sections = fmt.split(';');
  let sec = v >= 0 ? sections[0] : (sections[1] || sections[0]);
  const percent = sec.includes('%');
  let n = percent ? v * 100 : v;
  const decimals = (sec.split('.')[1] || '').replace(/[^0#]/g, '').length;
  const thousand = sec.includes(',');
  let out = n.toFixed(decimals);
  if (thousand) out = out.replace(/\B(?=(\d{3})+(?!\d))/g, ',');
  if (sec.includes('$')) out = '$' + out;
  if (percent) out += '%';
  if (v < 0 && !sections[1]) out = '-' + out;
  return out;
}
// Expose function names for the ribbon's autocomplete + Insert Function dialog.
if (typeof window !== 'undefined') {
  window.__FUNCTIONS__ = Object.keys(FUNCTIONS).sort();
}