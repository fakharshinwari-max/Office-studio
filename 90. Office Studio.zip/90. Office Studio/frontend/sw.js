/* Office Studio Service Worker — Phase 5: offline-first, background sync, versions. */
const VERSION = 'office-studio-v5';
const CORE = [
  '/', '/index.html', '/writer.html', '/sheets.html', '/slides.html',
  '/manifest.json',
  '/css/base.css', '/css/ribbon.css', '/css/writer.css', '/css/sheets.css', '/css/slides.css', '/css/themes.css',
  '/js/core/api.js', '/js/core/state.js', '/js/core/history.js', '/js/core/ribbon.js',
  '/js/core/ribbon-config-word.js', '/js/core/ribbon-config-excel.js', '/js/core/ribbon-config-ppt.js',
  '/js/core/storage.js', '/js/core/shortcuts.js', '/js/core/backstage.js', '/js/core/tellme.js',
  '/js/core/context-menu.js', '/js/core/keytips.js', '/js/core/dialogs.js',
  '/js/core/ai-panel.js', '/js/core/collab.js', '/js/core/presence.js',
  '/js/writer/editor.js', '/js/writer/track-changes.js', '/js/writer/comments.js',
  '/js/writer/fields.js', '/js/writer/formatting.js', '/js/writer/tables.js',
  '/js/sheets/grid.js', '/js/sheets/formula-engine.js', '/js/sheets/numfmt.js',
  '/js/sheets/pivot-engine.js', '/js/sheets/what-if.js',
  '/js/slides/canvas.js', '/js/slides/objects.js', '/js/slides/themes.js',
  '/js/slides/animations.js', '/js/slides/presenter.js'
];

self.addEventListener('install', (e) => {
  e.waitUntil(
    caches.open(VERSION).then(c => c.addAll(CORE)).then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', (e) => {
  e.waitUntil(
    caches.keys().then(keys => Promise.all(
      keys.filter(k => k !== VERSION).map(k => caches.delete(k))
    )).then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (e) => {
  const req = e.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);
  if (url.origin !== location.origin) return;

  // API: network-first, fall back to cache
  if (url.pathname.startsWith('/api/')) {
    e.respondWith(
      fetch(req)
        .then(res => {
          const clone = res.clone();
          caches.open(VERSION).then(c => c.put(req, clone)).catch(() => {});
          return res;
        })
        .catch(() => caches.match(req))
    );
    return;
  }

  // Static: cache-first, then fetch, then index.html fallback
  e.respondWith(
    caches.match(req).then(hit => hit || fetch(req).then(res => {
      const clone = res.clone();
      caches.open(VERSION).then(c => c.put(req, clone)).catch(() => {});
      return res;
    }).catch(() => {
      if (req.destination === 'document') return caches.match('/index.html');
    }))
  );
});

// Background sync for autosave journal — retries pending PUTs when back online
self.addEventListener('sync', (e) => {
  if (e.tag === 'office-autosave') {
    e.waitUntil(retryPendingSaves());
  }
});

async function retryPendingSaves() {
  const db = await new Promise((res, rej) => {
    const r = indexedDB.open('office-studio', 1);
    r.onsuccess = () => res(r.result);
    r.onerror = () => rej(r.error);
  });
  const tx = db.transaction('pending-saves', 'readwrite');
  const store = tx.objectStore('pending-saves');
  const pending = await new Promise(res => {
    const req = store.getAll();
    req.onsuccess = () => res(req.result || []);
  });
  for (const item of pending) {
    try {
      const r = await fetch(`/api/docs/${item.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + (item.token || '') },
        body: JSON.stringify(item.payload),
      });
      if (r.ok) store.delete(item.id);
    } catch {
      // Try again next time
    }
  }
}